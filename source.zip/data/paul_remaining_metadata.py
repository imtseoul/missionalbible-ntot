"""NA28-selected Pauline comparisons."""
from complete_metadata import build_rows
from paul_remaining_rows import ROWS
from paul_remaining_source_specs import SELECTIONS, NOTES, BOUNDARIES
def build(existing):
    return build_rows(existing, ROWS, selections=SELECTIONS, notes=NOTES, boundaries=BOUNDARIES)
