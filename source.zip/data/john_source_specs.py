"""Chapter sources for selected Johannine quotations and allusions."""
SELECTIONS={
'genesis-28':('Gen.28','gen',28,'창세기 28장',22),
'psalm-81':('Psa.81','psa',82,'시편 82편',8),
'isaiah-54':('Isa.54','isa',54,'이사야 54장',17),
'psalm-34':('Psa.34','psa',35,'시편 35편',28),
'psalm-24':('Psa.24','psa',25,'시편 25편',22),
'psalm-79':('Psa.79','psa',80,'시편 80편',19),
}
NT_COUNTS=[51,25,36,54,47,71,53,59,41,42,57,50,38,31,27,33,26,40,42,31,25]
EXTRA_OT=[]

OVERRIDES={
'psalm-79':dict(ot_offset=-1,unmapped_lxx=[1],superscription_verses=[1]),
'isaiah-54':dict(ot_map_overrides={10:[9,10]}),
}

NOTES={
'isaiah-54': [('10절의 끝문장','마지막의 Κύριε는 ‘주여’라는 부름말입니다. Ἵλεώς σοι는 ‘당신께 자비가 있기를’로 옮길 수 있으나 앞선 하나님의 발화와 어떻게 이어지는지는 불분명합니다.'),('칠십인역의 문구','6절은 버림받은 아내처럼 부른 것이 아니라는 부정문입니다. 15절은 이방에서 온 이들이 다가와 머무는 일을, 16절은 파괴하려고 창조하지 않았다는 말을 담고 있습니다.')],
}
