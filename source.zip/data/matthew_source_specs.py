"""Full chapters newly needed for selected Matthew comparisons."""
SELECTIONS={
'exodus-21':('Exo.21','exo',21,'출애굽기 21장',36),
'deuteronomy-15':('Deu.15','deu',15,'신명기 15장',23),
'deuteronomy-19':('Deu.19','deu',19,'신명기 19장',21),
'1samuel-21':('1Sa.21','1sa',21,'사무엘상 21장',15),
'2samuel-5':('2Sa.5','2sa',5,'사무엘하 5장',25),
'psalm-36':('Psa.36','psa',37,'시편 37편',40),
'psalm-41':('Psa.41','psa',42,'시편 42편',11),
'psalm-47':('Psa.47','psa',48,'시편 48편',14),
'isaiah-7':('Isa.7','isa',7,'이사야 7장',25),
'isaiah-9':('Isa.9','isa',9,'이사야 9장',21),
'isaiah-13':('Isa.13','isa',13,'이사야 13장',22),
'isaiah-14':('Isa.14','isa',14,'이사야 14장',32),
'isaiah-34':('Isa.34','isa',34,'이사야 34장',17),
'isaiah-62':('Isa.62','isa',62,'이사야 62장',12),
'jeremiah-6':('Jer.6','jer',6,'예레미야 6장',30),
'daniel-9':('Dan.9','dan',9,'다니엘 9장',27),
'daniel-11':('Dan.11','dan',11,'다니엘 11장',45),
'hosea-11':('Hos.11','hos',11,'호세아 11장',12),
'micah-5':('Mic.5','mic',5,'미가 5장',15),
'micah-7':('Mic.7','mic',7,'미가 7장',20),
'jonah-2':('Jon.2','jnh',2,'요나 2장',10),
'zechariah-11':('Zec.11','zec',11,'스가랴 11장',17),
}
NT_COUNTS=[25,23,17,25,48,34,29,34,38,42,30,50,58,36,39,28,27,35,30,34,46,46,39,51,46,75,66,20]
EXTRA_OT=[]
