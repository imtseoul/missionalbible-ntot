"""Matthew comparisons with source references and edition-aware chapter mapping."""
from copy import deepcopy
from pathlib import Path
import json
from matthew_source_specs import SELECTIONS
from matthew_rows import ROWS
from matthew_notes import NOTES,BOUNDARIES
ARCHIVE='https://archive.org/details/ntg-28-nestle-aland-institute-for-new-testament-textual-research/page/n{}/mode/1up'

def nums(value):
    result=[]
    for part in value.split(','):
        start,*end=part.split('-');result.extend(range(int(start),int(end[0] if end else start)+1))
    return result

def build(existing):
    text=json.loads((Path(__file__).parent/'texts.json').read_text())['lxx'];result={}
    for row in ROWS.strip().splitlines():
        slug,key,nref,ls,page,sot,snt,kind,lead,note=row.split('|');ch,ns=nref.split(':');ch=int(ch);page=int(page);nv=nums(ns);lv=nums(ls)
        if key in SELECTIONS:
            prefix,_,_,otitle,_=SELECTIONS[key]
            title=('시편 '+key.split('-')[1]+'편') if key.startswith('psalm-') else otitle
            c=dict(title=title,other='개역한글 '+otitle,source_refs=sorted([r for r in text if r.startswith(prefix+':')],key=lambda r:int(r.split(':')[1])))
            if key in ['psalm-41','psalm-47']:c.update(ot_offset=-1,unmapped_lxx=[1],superscription_verses=[1])
            if key=='exodus-21':c['ot_map_overrides']={16:[17],17:[16]}
            if key=='isaiah-9':c['ot_map_overrides']={14:[14,15]}
            if key=='jeremiah-6':c['ot_map_overrides']={7:[7,8]}
            if key=='daniel-9':c['ot_map_overrides']={26:[25,26],27:[25,27]}
            if key in ['daniel-9','daniel-11']:c['lxx_text_form']='Old Greek (not Theodotion)'
            if key=='jonah-2':c.update(ot_offset=16,other='개역한글 요나 1–2장')
            if key in BOUNDARIES:c['boundary_notes']=BOUNDARIES[key]
        else:
            old=next(v for k,v in existing.items() if v.get('lxx_chapter_id',k)==key)
            c={f:deepcopy(old[f]) for f in ['title','other','source_refs','source_status','textual_notes','ot_offset','unmapped_lxx','superscription_verses','ot_map_overrides','ot_chapter_id','lxx_text_form','boundary_notes'] if f in old}
            if key=='joel-3':c['ot_offset']=27
        c.update(lxx_chapter_id=key,ot_chapter_id=c.get('ot_chapter_id',key),nt_book='Matthew',nt_chapter=ch,nt=f'마태복음 {ch}:{ns.replace("-","–").replace(",",", ")}',nt_range=[min(nv),max(nv)],nt_selected=nv,lxx_range=[min(lv),max(lv)],lxx_selected=lv,kind=kind,lead=lead,description=note,ot_ref=c['title'].removesuffix('장').removesuffix('편')+':'+ls,source_entry={'ot':sot,'nt':snt},na28_verified={'page':page,'url':ARCHIVE.format(page+113),'typography':'not_transcribed','method':'reference_pairs_checked_in_OCR_of_primary_scan'})
        c['notes']=[('대조의 성격',note)]+NOTES.get(key,[])+[('장 경계',b) for b in c.get('boundary_notes',[])]
        result[slug]=c
    groups=[['mt2-bethlehem','mt2-shepherd'],['mt4-worship','mt4-serve'],['mt5-eye','mt5-fracture','mt5-justice'],['mt11-healing','mt11-good-news'],['mt11-messenger','mt11-before'],['mt12-david','mt12-bread'],['mt21-king','mt21-zion'],['mt21-prayer','mt21-den'],['mt24-desolation','mt24-sanctuary','mt24-abomination'],['mt24-darkness','mt24-stars'],['mt24-clouds','mt24-mourning'],['mt24-gather','mt24-trumpet'],['mt26-blood','mt26-covenant','mt26-many'],['mt26-right-hand','mt26-clouds'],['mt27-silver','mt27-potter']]
    for group in groups:
        for key in group:result[key]['related']=[x for x in group if x!=key]
    return result
