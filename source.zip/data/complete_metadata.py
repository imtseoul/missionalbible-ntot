"""Shared metadata construction for the final canonical expansion."""
from copy import deepcopy
from pathlib import Path
import importlib,json
ARCHIVE='https://archive.org/details/ntg-28-nestle-aland-institute-for-new-testament-textual-research/page/n{}/mode/1up'
MODULES=['john','paul_remaining','pastorals','catholic','revelation','completion']
NAMES={'John':'요한복음','2Corinthians':'고린도후서','Galatians':'갈라디아서','Ephesians':'에베소서','Philippians':'빌립보서','Colossians':'골로새서','1Thessalonians':'데살로니가전서','2Thessalonians':'데살로니가후서','1Timothy':'디모데전서','2Timothy':'디모데후서','Titus':'디도서','Philemon':'빌레몬서','James':'야고보서','1Peter':'베드로전서','2Peter':'베드로후서','1John':'요한일서','2John':'요한이서','3John':'요한삼서','Jude':'유다서','Revelation':'요한계시록'}
FIELDS=['title','other','source_refs','source_status','textual_notes','ot_offset','unmapped_lxx','superscription_verses','ot_map_overrides','ot_chapter_id','lxx_text_form','boundary_notes']
def nums(value):
 result=[]
 for part in value.split(','):
  start,*end=part.split('-');result.extend(range(int(start),int(end[0] if end else start)+1))
 return result

def build_rows(existing,rows,default_book=None,selections=None,notes=None,boundaries=None):
 specs={};overrides={};chapter_notes={};chapter_boundaries={}
 for module in MODULES:
  mod=importlib.import_module(module+'_source_specs')
  specs.update(mod.SELECTIONS);overrides.update(getattr(mod,'OVERRIDES',{}));chapter_notes.update(getattr(mod,'NOTES',{}));chapter_boundaries.update(getattr(mod,'BOUNDARIES',{}))
 specs.update(selections or {});chapter_notes.update(notes or {});chapter_boundaries.update(boundaries or {});text=json.loads((Path(__file__).parent/'texts.json').read_text())['lxx'];result={}
 for row in rows.strip().splitlines():
  if not row.strip() or row.lstrip().startswith('#'):continue
  fields=row.split('|');book=default_book
  if len(fields)==11:book,*fields=fields
  assert book in NAMES,(book,row)
  slug,key,nref,ls,page,sot,snt,kind,lead,note=fields;ch,ns=nref.split(':');ch=int(ch);page=int(page);nv=nums(ns);lv=nums(ls)
  old=next((v for k,v in existing.items() if v.get('lxx_chapter_id',k)==key),None)
  if old:c={f:deepcopy(old[f]) for f in FIELDS if f in old}
  else:
   prefix,_,_,otitle,_=specs[key];title=('시편 '+key.split('-')[1]+'편') if key.startswith('psalm-') else otitle
   if key=='jeremiah-28':title='예레미야 28장'
   c=dict(title=title,other='개역한글 '+otitle,source_refs=sorted([r for r in text if r.startswith(prefix+':')],key=lambda r:int(r.split(':')[1])))
   assert c['source_refs'],key
   missing=[n for n,r in enumerate(c['source_refs'],1) if not text[r]]
   if missing:
    c['source_status']={n:'absent_in_selected_swete_text' for n in missing}
    c['textual_notes']={n:'선택한 Swete 본문에는 이 절의 문장이 없습니다.' for n in missing}
   if key.startswith('daniel-'):c['lxx_text_form']='Old Greek (not Theodotion)'
  c.update(deepcopy(overrides.get(key,{})))
  if key in chapter_boundaries:c['boundary_notes']=chapter_boundaries[key]
  c.update(lxx_chapter_id=key,ot_chapter_id=c.get('ot_chapter_id',key),nt_book=book,nt_chapter=ch,nt=f'{NAMES[book]} {ch}:{ns.replace("-","–").replace(",",", ")}',nt_range=[min(nv),max(nv)],nt_selected=nv,lxx_range=[min(lv),max(lv)],lxx_selected=lv,kind=kind,lead=lead,description=note,ot_ref=c['title'].removesuffix('장').removesuffix('편')+':'+ls,source_entry={'ot':sot,'nt':snt},na28_verified={'page':page,'url':ARCHIVE.format(page+113),'typography':'not_transcribed','method':'reference_pairs_checked_in_OCR_of_primary_scan'})
  c['notes']=[('대조의 성격',note)]+chapter_notes.get(key,[])+[('장 경계',b) for b in c.get('boundary_notes',[])]
  assert slug not in result,('duplicate comparison',slug)
  result[slug]=c
 return result
