"""Catholic Epistles metadata with full chapter mappings."""
from complete_metadata import build_rows
from catholic_rows import ROWS

def build(existing):
    result=build_rows(existing,ROWS)
    result['2jn12-face']['na28_verified']['method']='visual_check_of_primary_scan'
    groups=[['jas2-believed','jas2-isaac'],['jas2-rahab','jas2-rahab-saved'],['jas5-wages','jas5-worker','jas5-judgment'],['1pet2-chosen','1pet2-rejected','1pet2-stumbling'],['1pet2-people','1pet2-proclaim','1pet2-possession'],['1pet2-mercy','1pet2-my-people'],['1pet2-sinless','1pet2-wounds','1pet2-sheep','1pet2-shepherd'],['1pet3-unafraid','1pet3-sanctify'],['1pet5-lion','1pet5-roaming'],['2pet2-balaam','2pet2-donkey'],['2pet3-new','2pet3-remain'],['jude9-rebuke','jude9-michael'],['jude23-fire','jude23-garment','jude23-brand']]
    for group in groups:
        for key in group:result[key]['related']=[x for x in group if x!=key]
    return result
