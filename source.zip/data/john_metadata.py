"""Johannine comparison metadata."""
from complete_metadata import build_rows
from john_rows import ROWS
def build(existing):
    return build_rows(existing,ROWS,default_book='John')
