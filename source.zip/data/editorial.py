"""Korean translations and manually selected phrase correspondences.
Translation status: AI-assisted research draft, not independently reviewed.
"""
TRANSLATIONS = {
'joel-3': [
'그 뒤에 이런 일이 있을 것이다. 내가 내 영을 모든 육체 위에 부을 것이다. 너희의 아들들과 딸들은 예언할 것이고, 너희의 노인들은 꿈을 꾸며, 너희의 젊은이들은 환상을 볼 것이다.',
'그날들에 내 남종들과 여종들 위에도 내 영을 부을 것이다.',
'내가 하늘에 이적들을 보일 것이며, 땅 위에는 피와 불과 연기 기둥을 보일 것이다.',
'주의 크고 현저한 날이 오기 전에 해는 어둠으로, 달은 피로 바뀔 것이다.',
'누구든지 주의 이름을 부르는 이는 구원받을 것이다. 주께서 말씀하신 대로 시온 산과 예루살렘에는 구원받는 이가 있을 것이며, 주께서 부르신, 기쁜 소식을 전하는 이들이 있을 것이다.'
],
'psalm-15': [
'다윗의 비문. 주여, 나를 지켜 주소서. 내가 주께 소망을 두었습니다.',
'나는 주께 말씀드렸습니다. “주는 나의 주님이십니다.”',
'그의 땅에 있는 거룩한 이들에게, 그가 자신의 모든 뜻을 그들 가운데서 놀랍게 이루셨습니다.',
'그들의 연약함이 많아졌고, 그 뒤에 그들은 서둘렀습니다. 나는 피로 이루어진 그들의 모임들을 결코 모으지 않으며, 내 입술로 그들의 이름들을 결코 기억하지 않겠습니다.',
'주는 내 유산과 내 잔의 몫이십니다. 주는 내 유산을 내게 돌려주시는 분이십니다.',
'측량줄이 내게 가장 좋은 곳에 떨어졌습니다. 참으로 내 유산은 내게 가장 좋습니다.',
'나를 깨닫게 하신 주를 찬송하겠습니다. 밤에도 내 콩팥이 나를 가르쳤습니다.',
'나는 주를 언제나 내 앞에 모셨습니다. 내가 흔들리지 않도록 그가 내 오른편에 계십니다.',
'그러므로 내 마음이 기뻐하고 내 혀가 크게 즐거워했습니다. 더욱이 내 육체도 소망 가운데 머물 것입니다.',
'주께서 내 영혼을 하데스에 버려두지 않으시며, 주의 거룩한 이가 썩음을 보게 하지 않으실 것이기 때문입니다.',
'주께서 내게 생명의 길들을 알려 주셨습니다. 주의 얼굴 앞에서 나를 기쁨으로 채우실 것입니다. 주의 오른편에는 즐거움이 영원히 있습니다.'
],
'psalm-109': [
'다윗의 시편. 주께서 내 주께 말씀하셨습니다. “내가 네 원수들을 네 발의 발판으로 삼을 때까지 내 오른편에 앉아라.”',
'주께서 시온에서 권능의 홀을 내보내실 것입니다. 네 원수들 한가운데서 다스려라.',
'네 권능의 날에, 거룩한 이들의 광채 가운데 통치권이 너와 함께 있다. 새벽별보다 앞서 태에서 내가 너를 낳았다.',
'주께서 맹세하셨고 마음을 바꾸지 않으실 것입니다. “너는 멜기세덱의 서열을 따라 영원한 제사장이다.”',
'네 오른편의 주께서 자신의 진노의 날에 왕들을 부수셨습니다.',
'그가 민족들 가운데 심판하시고, 시체로 가득 채우며, 넓은 땅에서 머리들을 부수실 것입니다.',
'그가 길에서 시냇물을 마실 것입니다. 그러므로 머리를 높이 드실 것입니다.'
]}

CHAPTERS = {
'joel-3': {'title':'요엘 3장','other':'개역한글 요엘 2:28–32','nt':'사도행전 2:17–21','nt_range':[17,21],'lxx_range':[1,5],'source_refs':[f'Joe.2:{i}' for i in range(28,33)],'ot_ref':'Joel 3:1–5 (LXX) / 2:28–32 (KRV)','lead':'내 영을 모든 육체 위에','description':'베드로가 오순절의 사건을 요엘의 말씀으로 설명합니다.','notes':[
('장·절 번호','여기서는 네 장으로 나누는 칠십인역 번호를 사용합니다. 요엘 3:1–5는 개역한글 및 사용한 Swete 전자자료의 2:28–32에 해당합니다.'),
('그 뒤에 → 말세에','요엘의 μετὰ ταῦτα(그 뒤에)가 사도행전에서는 ἐν ταῖς ἐσχάταις ἡμέραις(마지막 날들에)로 제시됩니다. 사도행전에는 λέγει ὁ θεός(하나님이 말씀하신다)도 들어 있습니다.'),
('순서와 확장','사도행전은 젊은이와 노인의 순서를 바꾸며, 2:18에 “저희가 예언할 것이요”를 덧붙입니다. 2:19에는 “위로”, “아래로”, “징조”가 함께 나타납니다.'),
('인용 뒤의 문맥','요엘 3:5의 시온·예루살렘과 부르심에 관한 문장은 사도행전 2:21의 인용 범위 밖에 있습니다. 끝의 εὐαγγελιζόμενοι는 이 그리스어 본문을 따라 “기쁜 소식을 전하는 이들”로 옮겼습니다.'),
('번역어','ἐπιφανῆ는 “현저한”으로 옮겼습니다. 개역한글 사도행전은 같은 표현을 “영화로운”으로 옮깁니다.') ]},
'psalm-15': {'title':'시편 15편','other':'개역한글 시편 16편','nt':'사도행전 2:25–28','nt_range':[25,28],'lxx_range':[8,11],'source_refs':[f'Psa.15:{i}' for i in range(1,12)],'ot_ref':'Psalm 15:8–11 (LXX) / 16:8–11 (KRV)','lead':'내 육체도 소망 가운데','description':'다윗의 시가 예수의 부활을 설명하는 문맥에 놓입니다.','notes':[
('시편 번호','칠십인역 시편 15편은 개역한글 시편 16편에 해당합니다.'),
('혀와 입술','시편 15:9와 사도행전 2:26의 그리스어는 모두 ἡ γλῶσσά μου(내 혀)입니다. 개역한글 신약의 “내 입술”과 칠십인역 번역의 “내 혀”를 같은 표현으로 연결했습니다.'),
('표기 차이','시편 15:10의 ἐνκαταλείψεις와 SBLGNT 사도행전 2:27의 ἐγκαταλείψεις는 철자가 다릅니다. 화면에는 각 판본의 철자를 보존합니다.'),
('인용이 멈추는 곳','사도행전 2:28은 시편 15:11의 “주의 오른편에는 즐거움이 영원히 있습니다”를 인용하지 않습니다.'),
('어려운 표현','3–4절은 그리스어 표현의 난점을 남긴 직역 초안입니다. 7절의 “콩팥”은 내적 판단을 가리키는 신체 표현입니다. Swete의 2절은 “주는 나의 주님이십니다”에서 끝나며 다른 칠십인역 판본과 길이가 다를 수 있습니다.') ]},
'psalm-109': {'title':'시편 109편','other':'개역한글 시편 110편','nt':'사도행전 2:34–35','nt_range':[34,35],'lxx_range':[1,1],'source_refs':[f'Psa.109:{i}' for i in range(1,8)],'ot_ref':'Psalm 109:1 (LXX) / 110:1 (KRV)','lead':'내 오른편에 앉아라','description':'주님의 오른편에 앉으라는 말씀이 예수의 높아지심을 설명합니다.','notes':[
('시편 번호','칠십인역 시편 109편은 개역한글 시편 110편에 해당합니다.'),
('두 번의 κύριος','ὁ κύριος와 τῷ κυρίῳ μου를 각각 “주께서”와 “내 주께”로 옮겼습니다. 본문에서 반복되는 단어를 그대로 볼 수 있습니다.'),
('절 구분','개역한글 2:35의 “너는 내 우편에 앉았으라”에 대응하는 그리스어는 SBLGNT 2:34에 있습니다. 이 표현에는 그리스어 절 번호를 별도로 표시합니다.'),
('인용 뒤의 문맥','시편 전체에는 통치, 출생, 멜기세덱의 서열에 따른 제사장직, 심판의 언어가 이어집니다.'),
('번역어','3절의 ἀρχή는 “통치권”, τῶν ἁγίων는 “거룩한 이들”로 옮긴 초안입니다. 6절의 πτῶμα는 단수 “시체”이며, 한국어에서는 수를 특정하지 않았습니다.') ]}
}

# Each endpoint: Korean verse, exact Korean phrase, Greek verse, exact Greek phrase.
PAIRS = { 'joel-3': [
('j-time',(17,'말세에',17,'ἐν ταῖς ἐσχάταις ἡμέραις'),(1,'그 뒤에',1,'μετὰ ταῦτα'),'변형'),
('j-spirit',(17,'내가 내 영으로 모든 육체에게 부어 주리니',17,'ἐκχεῶ ἀπὸ τοῦ πνεύματός μου ἐπὶ πᾶσαν σάρκα'),(1,'내가 내 영을 모든 육체 위에 부을 것이다',1,'ἐκχεῶ ἀπὸ τοῦ πνεύματός μου ἐπὶ πᾶσαν σάρκα'),'같은 표현'),
('j-children',(17,'너희의 자녀들은 예언할 것이요',17,'προφητεύσουσιν οἱ υἱοὶ ὑμῶν καὶ αἱ θυγατέρες ὑμῶν'),(1,'너희의 아들들과 딸들은 예언할 것이고',1,'προφητεύσουσιν οἱ υἱοὶ ὑμῶν καὶ αἱ θυγατέρες ὑμῶν'),'같은 표현'),
('j-young',(17,'너희의 젊은이들은 환상을 보고',17,'οἱ νεανίσκοι ὑμῶν ὁράσεις ὄψονται'),(1,'너희의 젊은이들은 환상을 볼 것이다',1,'οἱ νεανίσκοι ὑμῶν ὁράσεις ὄψονται'),'순서 이동'),
('j-old',(17,'너희의 늙은이들은 꿈을 꾸리라',17,'οἱ πρεσβύτεροι ὑμῶν ἐνυπνίοις ἐνυπνιασθήσονται'),(1,'너희의 노인들은 꿈을 꾸며',1,'οἱ πρεσβύτεροι ὑμῶν ἐνύπνια ἐνυπνιασθήσονται'),'형태 변화·순서 이동'),
('j-servants',(18,'내 남종과 여종들에게',18,'ἐπὶ τοὺς δούλους μου καὶ ἐπὶ τὰς δούλας μου'),(2,'내 남종들과 여종들 위에도',2,'ἐπὶ τοὺς δούλους μου καὶ ἐπὶ τὰς δούλας'),'변형'),
('j-day',(18,'그 때에',18,'ἐν ταῖς ἡμέραις ἐκείναις'),(2,'그날들에',2,'ἐν ταῖς ἡμέραις ἐκείναις'),'같은 표현'),
('j-pour',(18,'부어 주리니',18,'ἐκχεῶ'),(2,'부을 것이다',2,'ἐκχεῶ'),'같은 표현'),
('j-spirit2',(18,'내 영으로',18,'ἀπὸ τοῦ πνεύματός μου'),(2,'내 영을',2,'ἀπὸ τοῦ πνεύματός μου'),'같은 표현'),
('j-fire',(19,'피와 불과 연기로다',19,'αἷμα καὶ πῦρ καὶ ἀτμίδα καπνοῦ'),(3,'피와 불과 연기 기둥을',3,'αἷμα καὶ πῦρ καὶ ἀτμίδα καπνοῦ'),'같은 표현'),
('j-great',(20,'주의 크고 영화로운 날이',20,'ἡμέραν κυρίου τὴν μεγάλην καὶ ἐπιφανῆ'),(4,'주의 크고 현저한 날이',4,'ἡμέραν Κυρίου τὴν μεγάλην καὶ ἐπιφανῆ'),'같은 표현'),
('j-save',(21,'누구든지 주의 이름을 부르는 자는 구원을 얻으리라',21,'πᾶς ὃς ἐὰν ἐπικαλέσηται τὸ ὄνομα κυρίου σωθήσεται'),(5,'누구든지 주의 이름을 부르는 이는 구원받을 것이다',5,'πᾶς ὃς ἂν ἐπικαλέσηται τὸ ὄνομα Κυρίου σωθήσεται'),'형태 변화')
], 'psalm-15': [
('p-see',(25,'내가 항상 내 앞에 계신 주를 뵈웠음이여',25,'Προορώμην τὸν κύριον ἐνώπιόν μου διὰ παντός'),(8,'나는 주를 언제나 내 앞에 모셨습니다',8,'προορώμην τὸν κύριον ἐνώπιόν μου διὰ παντός'),'같은 표현'),
('p-right',(25,'그가 내 우편에 계시도다',25,'ἐκ δεξιῶν μού ἐστιν'),(8,'그가 내 오른편에 계십니다',8,'ἐκ δεξιῶν μού ἐστιν'),'같은 표현'),
('p-shake',(25,'나로 요동치 않게 하기 위하여',25,'ἵνα μὴ σαλευθῶ'),(8,'내가 흔들리지 않도록',8,'ἵνα μὴ σαλευθῶ'),'같은 표현'),
('p-heart',(26,'내 마음이 기뻐하였고',26,'ηὐφράνθη ἡ καρδία μου'),(9,'내 마음이 기뻐하고',9,'ηὐφράνθη ἡ καρδία μου'),'같은 표현'),
('p-tongue',(26,'내 입술도 즐거워하였으며',26,'ἠγαλλιάσατο ἡ γλῶσσά μου'),(9,'내 혀가 크게 즐거워했습니다',9,'ἠγαλλιάσατο ἡ γλῶσσά μου'),'같은 표현'),
('p-flesh',(26,'육체는 희망에 거하리니',26,'ἡ σάρξ μου κατασκηνώσει ἐπ’ ἐλπίδι'),(9,'내 육체도 소망 가운데 머물 것입니다',9,'ἡ σάρξ μου κατασκηνώσει ἐπ᾽ ἐλπίδι'),'같은 표현'),
('p-hades',(27,'내 영혼을 음부에 버리지 아니하시며',27,'οὐκ ἐγκαταλείψεις τὴν ψυχήν μου εἰς ᾅδην'),(10,'내 영혼을 하데스에 버려두지 않으시며',10,'οὐκ ἐνκαταλείψεις τὴν ψυχήν μου εἰς ᾅδην'),'철자 차이'),
('p-holy',(27,'주의 거룩한 자로 썩음을 당치 않게 하실 것임이로다',27,'οὐδὲ δώσεις τὸν ὅσιόν σου ἰδεῖν διαφθοράν'),(10,'주의 거룩한 이가 썩음을 보게 하지 않으실 것이기 때문입니다',10,'οὐδὲ δώσεις τὸν ὅσιόν σου ἰδεῖν διαφθοράν'),'같은 표현'),
('p-life',(28,'생명의 길로',28,'ὁδοὺς ζωῆς'),(11,'생명의 길들을',11,'ὁδοὺς ζωῆς'),'같은 표현'),
('p-joy',(28,'주의 앞에서 나로 기쁨이 충만하게 하시리로다',28,'πληρώσεις με εὐφροσύνης μετὰ τοῦ προσώπου σου'),(11,'주의 얼굴 앞에서 나를 기쁨으로 채우실 것입니다',11,'πληρώσεις με εὐφροσύνης μετὰ τοῦ προσώπου σου'),'같은 표현')
], 'psalm-109': [
('q-lord',(34,'주께서 내 주에게 말씀하시기를',34,'Εἶπεν ὁ κύριος τῷ κυρίῳ μου'),(1,'주께서 내 주께 말씀하셨습니다',1,'Εἶπεν ὁ κύριος τῷ κυρίῳ μου'),'같은 표현'),
('q-seat',(35,'너는 내 우편에 앉았으라',34,'Κάθου ἐκ δεξιῶν μου'),(1,'내 오른편에 앉아라',1,'Κάθου ἐκ δεξιῶν μου'),'같은 표현'),
('q-feet',(35,'내가 네 원수로 네 발등상 되게 하기까지',35,'ἕως ἂν θῶ τοὺς ἐχθρούς σου ὑποπόδιον τῶν ποδῶν σου'),(1,'내가 네 원수들을 네 발의 발판으로 삼을 때까지',1,'ἕως ἂν θῶ τοὺς ἐχθρούς σου ὑποπόδιον τῶν ποδῶν σου'),'같은 표현')
]}

# Chapter context and comparison metadata are separate from the NT text store.
for _chapter in CHAPTERS.values():
    _chapter['nt_chapter']=2
    _chapter['kind']='직접 인용'
from expansion import TRANSLATIONS as MORE_TRANSLATIONS, CHAPTERS as MORE_CHAPTERS, PAIRS as MORE_PAIRS
TRANSLATIONS.update(MORE_TRANSLATIONS)
CHAPTERS.update(MORE_CHAPTERS)
PAIRS.update(MORE_PAIRS)
from acts_6_8 import TRANSLATIONS as ACTS_TRANSLATIONS
from acts_6_8_metadata import CHAPTERS as ACTS_CHAPTERS
from acts_6_8_pairs import PAIRS as ACTS_PAIRS
TRANSLATIONS.update(ACTS_TRANSLATIONS)
CHAPTERS.update(ACTS_CHAPTERS)
PAIRS.update(ACTS_PAIRS)
from acts_9_28 import TRANSLATIONS as FINAL_TRANSLATIONS
from acts_9_28_metadata import CHAPTERS as FINAL_CHAPTERS
from acts_9_28_pairs import PAIRS as FINAL_PAIRS
TRANSLATIONS.update(FINAL_TRANSLATIONS)
CHAPTERS.update(FINAL_CHAPTERS)
PAIRS.update(FINAL_PAIRS)
CHAPTERS['psalm-68']['superscription_verses']=[1]
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:(item[1]['nt_chapter'],item[1]['nt_range'][0])))
from luke_translations import TRANSLATIONS as LUKE_TRANSLATIONS
from luke_metadata import build as build_luke, ARCHIVE as NA28_ARCHIVE
from luke_pairs import PAIRS as LUKE_PAIRS
_LUKE_CHAPTERS=build_luke(CHAPTERS)
TRANSLATIONS.update(LUKE_TRANSLATIONS)
CHAPTERS.update(_LUKE_CHAPTERS)
PAIRS.update({key:LUKE_PAIRS.get(key,[]) for key in _LUKE_CHAPTERS})
CHAPTERS['jonah-1']['na28_verified']={'page':867,'url':NA28_ARCHIVE.format(980),'typography':'roman (allusion)','method':'visual_check_of_primary_scan'}
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:(0 if item[1].get('nt_book')=='Luke' else 1,item[1]['nt_chapter'],item[1]['nt_range'][0])))
from hebrews_translations import TRANSLATIONS as HEBREWS_TRANSLATIONS
from hebrews_metadata import build as build_hebrews
from hebrews_pairs import PAIRS as HEBREWS_PAIRS
_HEBREWS_CHAPTERS=build_hebrews(CHAPTERS)
TRANSLATIONS.update(HEBREWS_TRANSLATIONS)
CHAPTERS.update(_HEBREWS_CHAPTERS)
PAIRS.update({key:HEBREWS_PAIRS.get(key,[]) for key in _HEBREWS_CHAPTERS})
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:({'Luke':0,'Acts':1,'Hebrews':2}[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))

from romans_translations import TRANSLATIONS as ROMANS_TRANSLATIONS
from romans_metadata import build as build_romans
from romans_pairs import PAIRS as ROMANS_PAIRS
_ROMANS_CHAPTERS=build_romans(CHAPTERS)
TRANSLATIONS.update(ROMANS_TRANSLATIONS)
CHAPTERS.update(_ROMANS_CHAPTERS)
PAIRS.update({key:ROMANS_PAIRS.get(key,[]) for key in _ROMANS_CHAPTERS})
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:({'Luke':0,'Acts':1,'Romans':2,'Hebrews':3}[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))

from corinthians_translations import TRANSLATIONS as CORINTHIANS_TRANSLATIONS
from corinthians_metadata import build as build_corinthians
from corinthians_pairs import PAIRS as CORINTHIANS_PAIRS
_CORINTHIANS_CHAPTERS=build_corinthians(CHAPTERS)
TRANSLATIONS.update(CORINTHIANS_TRANSLATIONS)
CHAPTERS.update(_CORINTHIANS_CHAPTERS)
PAIRS.update({key:CORINTHIANS_PAIRS.get(key,[]) for key in _CORINTHIANS_CHAPTERS})
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:({'Luke':0,'Acts':1,'Romans':2,'1Corinthians':3,'Hebrews':4}[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))

from matthew_translations import TRANSLATIONS as MATTHEW_TRANSLATIONS
from matthew_metadata import build as build_matthew
from matthew_pairs import PAIRS as MATTHEW_PAIRS
_MATTHEW_CHAPTERS=build_matthew(CHAPTERS)
TRANSLATIONS.update(MATTHEW_TRANSLATIONS)
CHAPTERS.update(_MATTHEW_CHAPTERS)
PAIRS.update({key:MATTHEW_PAIRS.get(key,[]) for key in _MATTHEW_CHAPTERS})
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:({'Matthew':0,'Luke':1,'Acts':2,'Romans':3,'1Corinthians':4,'Hebrews':5}[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))

from mark_translations import TRANSLATIONS as MARK_TRANSLATIONS
from mark_metadata import build as build_mark
from mark_pairs import PAIRS as MARK_PAIRS
_MARK_CHAPTERS=build_mark(CHAPTERS)
TRANSLATIONS.update(MARK_TRANSLATIONS)
CHAPTERS.update(_MARK_CHAPTERS)
PAIRS.update({key:MARK_PAIRS.get(key,[]) for key in _MARK_CHAPTERS})
CHAPTERS=dict(sorted(CHAPTERS.items(),key=lambda item:({'Matthew':0,'Mark':1,'Luke':2,'Acts':3,'Romans':4,'1Corinthians':5,'Hebrews':6}[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))

# Complete canonical coverage; retain earlier comparison IDs and source mappings.
from canonical_expansion import expand as _expand_canon
CHAPTERS=_expand_canon(CHAPTERS,TRANSLATIONS,PAIRS)

from comparison_readings import READINGS as _READINGS
for _slug,_reading in _READINGS.items():
    _chapter=CHAPTERS[_slug]
    _chapter['description']=_reading['summary']
    _expanded=[(n['title'],n['text']) for n in _reading['notes']]
    _chapter['notes']=[('대조의 성격',_reading['summary'])]+_expanded+[
        (title,body) for title,body in _chapter['notes']
        if title!='대조의 성격' and body not in {text for _,text in _expanded}]
