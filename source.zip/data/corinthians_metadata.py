"""Selected 1 Corinthians comparisons; reference links checked against NA28 appendix III."""
from copy import deepcopy
from pathlib import Path
import json
from corinthians_source_specs import SELECTIONS
from corinthians_translations import TRANSLATIONS
from corinthians_rows import ROWS
from corinthians_notes import NOTES,BOUNDARIES
ARCHIVE='https://archive.org/details/ntg-28-nestle-aland-institute-for-new-testament-textual-research/page/n{}/mode/1up'

def build(existing):
    text=json.loads((Path(__file__).parent/'texts.json').read_text())['lxx'];result={}
    def nums(s):
        out=[]
        for part in s.split(','):
            a,*b=part.split('-');out.extend(range(int(a),int(b[0] if b else a)+1))
        return out
    for row in ROWS.strip().splitlines():
        slug,key,nref,ls,page,sot,snt,kind,lead,note=row.split('|');ch,ns=nref.split(':');ch=int(ch);page=int(page);nv=nums(ns);lv=nums(ls)
        if key in SELECTIONS:
            prefix,_,_,otitle,_=SELECTIONS[key]
            title=('시편 '+key.split('-')[1]+'편') if key.startswith('psalm-') else otitle
            c=dict(title=title,other='개역한글 '+otitle,source_refs=[r for r in text if r.startswith(prefix+':')])
            absent=[n for n,v in enumerate(TRANSLATIONS[key],1) if v is None]
            if absent:c.update(source_status={n:'absent_in_selected_swete_text' for n in absent},textual_notes={n:'선택한 Swete 전자자료의 이 절에는 본문이 없습니다.' for n in absent})
            if key=='numbers-16':c['ot_map_overrides']={37:[37,38]}
            if key=='isaiah-64':c['ot_map_overrides']={10:[10,11]}
            if key=='daniel-2':c['lxx_text_form']='Old Greek (not Theodotion)'
            if key=='leviticus-7':c['ot_offset']=40
            if key in ['leviticus-6','leviticus-7']:c['other']='개역한글 레위기 6–7장'
            if key=='psalm-113':c['other']='개역한글 시편 114–115편'
            if key in BOUNDARIES:c['boundary_notes']=BOUNDARIES[key]
        else:
            old=next(v for k,v in existing.items() if v.get('lxx_chapter_id',k)==key)
            c={f:deepcopy(old[f]) for f in ['title','other','source_refs','source_status','textual_notes','ot_offset','unmapped_lxx','superscription_verses','ot_map_overrides','lxx_text_form','boundary_notes'] if f in old}
            # Original Joel comparison uses a slug-specific fallback in the renderer.
            if key=='joel-3':c['ot_offset']=27
        c.update(lxx_chapter_id=key,ot_chapter_id=('leviticus-6' if key=='leviticus-7' else key),nt_book='1Corinthians',nt_chapter=ch,nt=f'고린도전서 {ch}:{ns.replace("-","–").replace(",",", ")}',nt_range=[min(nv),max(nv)],nt_selected=nv,lxx_range=[min(lv),max(lv)],lxx_selected=lv,kind=kind,lead=lead,description=note,ot_ref=c['title'].removesuffix('장').removesuffix('편')+':'+ls,source_entry={'ot':sot,'nt':snt},na28_verified={'page':page,'url':ARCHIVE.format(page+113),'typography':'not_transcribed','method':'reference_pairs_checked_in_OCR_of_primary_scan'})
        c['notes']=[('대조의 성격',note)]+NOTES.get(key,[])+[('장 경계',b) for b in c.get('boundary_notes',[])]
        result[slug]=c
    extra={
      'c10-immorality':('사망자 수','민수기 25:9는 이만 사천 명, 고린도전서 10:8은 하루에 이만 삼천 명입니다. 두 본문은 사망자 수와 시간을 한정하는 표현에서 차이가 납니다.'),
      'c10-serpents':('시험의 대상','SBLGNT 고린도전서 10:9는 Χριστόν(그리스도)을 읽습니다. 민수기 21:5의 비방 대상은 하나님과 모세이며 6절에서 뱀을 보내시는 분은 주님입니다.'),
      'c15-sins':('인용 범위','고린도전서 15:3의 성경대로라는 복음 요약과 이사야 53장을 비교합니다.'),
    }
    for slug,note in extra.items():result[slug]['notes'].insert(1,note)
    for slug in ['c10-rock','c10-water','c10-streams']:
        result[slug]['notes'].insert(1,('따르는 반석','고린도전서 10:4는 따르는 신령한 반석을 그리스도로 해석합니다. 이 구약 본문들에는 반석이 따라왔다는 문장이 없습니다.'))
    for slug in ['c2-unheard','c2-unseen','c2-heart']:
        result[slug]['notes'].insert(1,('여러 배경 본문','고린도전서 2:9의 전체 문장은 이사야 한 절의 축자 인용이 아닙니다. NA28이 연결하는 이사야 52·64·65장을 나란히 비교합니다.'))
    groups=[['c1-wisdom','c1-counsel','c1-egypt','c1-scribe','c1-foolish'],['c1-boast','c1-hannah'],['c2-unheard','c2-unseen','c2-heart'],['c2-mind','c2-council'],['c10-rock','c10-water','c10-streams'],['c10-manna','c10-fed','c10-bread'],['c10-altar','c10-peace'],['c10-demons','c10-demon-psalm','c10-sacrifice'],['c11-blood','c11-new-covenant','c11-covenant-blood'],['c14-god-among','c14-revealer','c14-with-you']]
    for group in groups:
        for key in group:result[key]['related']=[x for x in group if x!=key]
    return result
