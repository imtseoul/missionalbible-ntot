"""Canonical New Testament order and source book identifiers."""

# key, route slug, Korean name, short name, BSK code, MorphGNT file, publisher file,
# chapter verse slots (Korean Revised Version numbering).
_ROWS = [
    ('Matthew','matthew','마태복음','마','mat','61-Mt','Matt',[25,23,17,25,48,34,29,34,38,42,30,50,58,36,39,28,27,35,30,34,46,46,39,51,46,75,66,20]),
    ('Mark','mark','마가복음','막','mrk','62-Mk','Mark',[45,28,35,41,43,56,37,38,50,52,33,44,37,72,47,20]),
    ('Luke','luke','누가복음','눅','luk','63-Lk','Luke',[80,52,38,44,39,49,50,56,62,42,54,59,35,35,32,31,37,43,48,47,38,71,56,53]),
    ('John','john','요한복음','요','jhn','64-Jn','John',[51,25,36,54,47,71,53,59,41,42,57,50,38,31,27,33,26,40,42,31,25]),
    ('Acts','acts','사도행전','행','act','65-Ac','Acts',[26,47,26,37,42,15,60,40,43,48,30,25,52,28,41,40,34,28,41,38,40,30,35,27,27,32,44,31]),
    ('Romans','romans','로마서','롬','rom','66-Ro','Rom',[32,29,31,25,21,23,25,39,33,21,36,21,14,23,33,27]),
    ('1Corinthians','1corinthians','고린도전서','고전','1co','67-1Co','1Cor',[31,16,23,21,13,20,40,13,27,33,34,31,13,40,58,24]),
    ('2Corinthians','2corinthians','고린도후서','고후','2co','68-2Co','2Cor',[24,17,18,18,21,18,16,24,15,18,33,21,13]),
    ('Galatians','galatians','갈라디아서','갈','gal','69-Ga','Gal',[24,21,29,31,26,18]),
    ('Ephesians','ephesians','에베소서','엡','eph','70-Eph','Eph',[23,22,21,32,33,24]),
    ('Philippians','philippians','빌립보서','빌','php','71-Php','Phil',[30,30,21,23]),
    ('Colossians','colossians','골로새서','골','col','72-Col','Col',[29,23,25,18]),
    ('1Thessalonians','1thessalonians','데살로니가전서','살전','1th','73-1Th','1Thess',[10,20,13,18,28]),
    ('2Thessalonians','2thessalonians','데살로니가후서','살후','2th','74-2Th','2Thess',[12,17,18]),
    ('1Timothy','1timothy','디모데전서','딤전','1ti','75-1Ti','1Tim',[20,15,16,16,25,21]),
    ('2Timothy','2timothy','디모데후서','딤후','2ti','76-2Ti','2Tim',[18,26,17,22]),
    ('Titus','titus','디도서','딛','tit','77-Tit','Titus',[16,15,15]),
    ('Philemon','philemon','빌레몬서','몬','phm','78-Phm','Phlm',[25]),
    ('Hebrews','hebrews','히브리서','히','heb','79-Heb','Heb',[14,18,19,16,14,20,28,13,28,39,40,29,25]),
    ('James','james','야고보서','약','jas','80-Jas','Jas',[27,26,18,17,20]),
    ('1Peter','1peter','베드로전서','벧전','1pe','81-1Pe','1Pet',[25,25,22,19,14]),
    ('2Peter','2peter','베드로후서','벧후','2pe','82-2Pe','2Pet',[21,22,18]),
    ('1John','1john','요한일서','요일','1jn','83-1Jn','1John',[10,29,24,21,21]),
    ('2John','2john','요한이서','요이','2jn','84-2Jn','2John',[13]),
    ('3John','3john','요한삼서','요삼','3jn','85-3Jn','3John',[15]),
    ('Jude','jude','유다서','유','jud','86-Jud','Jude',[25]),
    ('Revelation','revelation','요한계시록','계','rev','87-Re','Rev',[20,29,22,11,14,17,17,13,21,11,19,17,18,20,8,21,18,24,21,15,27,21]),
]

BOOKS = {
    key: dict(slug=slug, name=name, short=short, code=code,
              file='nt-chapters.json' if key == 'Acts' else f'nt-{slug}.json',
              morph_file=f'{morph}-morphgnt.txt', publisher_file=f'{publisher}.txt',
              source_counts=list(counts), counts=list(counts))
    for key, slug, name, short, code, morph, publisher, counts in _ROWS
}

# SBLGNT gives the last clause of Korean 12:17 its own verse, 12:18.
BOOKS['Revelation']['counts'][11] = 18

EXISTING_BOOKS = {'Matthew','Mark','Luke','Acts','Romans','1Corinthians','Hebrews'}
REMAINING_BOOKS = {key: value for key, value in BOOKS.items() if key not in EXISTING_BOOKS}
