"""Whole-chapter contexts for Revelation's selected allusions."""
from complete_metadata import build_rows
from revelation_rows import ROWS

def build(existing):
    result=build_rows(existing,ROWS,default_book='Revelation')
    groups=[['rv1-clouds','rv1-mourning'],['rv1-robe','rv1-hair','rv1-waters'],['rv4-crystal','rv4-creatures','rv4-holy'],['rv5-lion','rv5-root','rv5-lamb'],['rv6-sackcloth','rv6-dark-sky','rv6-stars','rv6-hide'],['rv7-hunger','rv7-shepherd','rv7-tears'],['rv10-oath','rv10-living','rv10-creator'],['rv12-serpent','rv12-offspring'],['rv13-sea-beast','rv13-composite','rv13-mouth'],['rv19-mouth','rv19-iron','rv19-press'],['rv21-glory','rv21-nations','rv21-gates'],['rv22-river','rv22-eden','rv22-leaves']]
    for group in groups:
        for key in group:result[key]['related']=[x for x in group if x!=key]
    return result
