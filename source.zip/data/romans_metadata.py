"""Selected Romans comparisons; reference links checked against NA28 appendix III."""
from copy import deepcopy
from pathlib import Path
import json
from romans_source_specs import SELECTIONS
from romans_translations import TRANSLATIONS
from romans_rows import ROWS
from romans_notes import NOTES,BOUNDARIES
ARCHIVE='https://archive.org/details/ntg-28-nestle-aland-institute-for-new-testament-textual-research/page/n{}/mode/1up'

def build(existing):
    text=json.loads((Path(__file__).parent/'texts.json').read_text())['lxx'];result={}
    def nums(s):
        out=[]
        for part in s.split(','):
            a,*b=part.split('-');out.extend(range(int(a),int(b[0] if b else a)+1))
        return out
    for row in ROWS.strip().splitlines():
        slug,key,nref,ls,page,sot,snt,kind,lead,note=row.split('|');ch,ns=nref.split(':');ch=int(ch);page=int(page);nv=nums(ns);lv=nums(ls)
        if key in SELECTIONS:
            prefix,_,_,otitle,_=SELECTIONS[key]
            title=('시편 '+key.split('-')[1]+'편') if key.startswith('psalm-') else otitle
            c=dict(title=title,other='개역한글 '+otitle,source_refs=[r for r in text if r.startswith(prefix+':')])
            absent=[n for n,v in enumerate(TRANSLATIONS[key],1) if v is None]
            if absent:c.update(source_status={n:'absent_in_selected_swete_text' for n in absent},textual_notes={n:'선택한 Swete 전자자료의 이 절에는 본문이 없습니다.' for n in absent})
            if key in ['psalm-5','psalm-17','psalm-18','psalm-35','psalm-43','psalm-61','psalm-139']:
                c.update(ot_offset=-1,unmapped_lxx=[1],superscription_verses=[1])
            if key=='psalm-50':c.update(ot_offset=-2,unmapped_lxx=[1,2],superscription_verses=[1,2])
            if key=='psalm-9':c.update(ot_offset=-21,unmapped_lxx=list(range(1,22)),superscription_verses=[1])
            if key=='psalm-115':c['ot_offset']=9
            if key=='psalm-18':c['ot_map_overrides']={6:[4,5]}
            if key=='job-41':c.update(ot_offset=9,ot_map_overrides={1:[9,10],2:[10,11]})
            if key=='numbers-15':c['ot_map_overrides']={14:[14,15]}
            if key=='isaiah-1':c['ot_map_overrides']={13:[12,13],14:[13,14]}
            if key=='isaiah-10':c['ot_map_overrides']={29:[28,29]}
            if key=='isaiah-28':c['ot_map_overrides']={2:[2,3],28:[27,28]}
            if key=='isaiah-51':c['ot_map_overrides']={11:[10,11]}
            if key=='ezekiel-36':c['ot_map_overrides']={30:[29,30]}
            if key in BOUNDARIES:c['boundary_notes']=BOUNDARIES[key]
        else:
            old=next(v for k,v in existing.items() if v.get('lxx_chapter_id',k)==key)
            c={f:deepcopy(old[f]) for f in ['title','other','source_refs','source_status','textual_notes','ot_offset','unmapped_lxx','superscription_verses','ot_map_overrides','lxx_text_form','boundary_notes'] if f in old}
            # Original Joel comparison uses a slug-specific fallback in the renderer.
            if key=='joel-3':c['ot_offset']=27
        c.update(lxx_chapter_id=key,ot_chapter_id=key,nt_book='Romans',nt_chapter=ch,nt=f'로마서 {ch}:{ns.replace("-","–").replace(",",", ")}',nt_range=[min(nv),max(nv)],nt_selected=nv,lxx_range=[min(lv),max(lv)],lxx_selected=lv,kind=kind,lead=lead,description=note,ot_ref=c['title'].removesuffix('장').removesuffix('편')+':'+ls,source_entry={'ot':sot,'nt':snt},na28_verified={'page':page,'url':ARCHIVE.format(page+113),'typography':'not_transcribed','method':'reference_pairs_checked_in_OCR_of_primary_scan'})
        c['notes']=[('대조의 성격',note)]+NOTES.get(key,[])+[('장 경계',b) for b in c.get('boundary_notes',[])]
        result[slug]=c
    extra={
      'rm5-many':('의롭게 함의 구문','선택한 이사야 53:11은 많은 이들을 잘 섬기는 의인을 의롭다고 인정한다는 구문입니다. 한 사람의 순종으로 많은 이가 의인이 된다는 로마서 5:19와 주어·목적어 구조가 같지 않습니다.'),
      'rm1-faith':('믿음의 소유격','칠십인역 하박국 2:4는 “나의 믿음·신실함으로”라고 읽으며 로마서 1:17에는 μου가 없습니다. 히브리서 10:38의 “나의 의인”과도 구별합니다.'),
      'rm11-reject':('세 절의 배열','NA28의 예레미야 31:37은 채택한 Swete 38:35입니다. 이 장의 35–37절 배열은 한글 구약과 달라 각각 연결하였습니다.'),
      'rm11-irrevocable':('번역과 암시의 범위','개역한글은 후회하지 않음을 말하지만 선택한 칠십인역 23:19의 동사는 실수함·위협받음으로 옮겼습니다. 여기서는 약속의 확실성이라는 맥락을 대조합니다.'),
      'rm9-stumble':('부정 구문의 차이','선택한 이사야 8:14는 돌의 걸림에 부딪치지 않을 것이라는 부정 구문을 포함합니다. 로마서는 걸림돌과 걸려 넘어지는 바위라는 명사구를 이사야 28장에 결합합니다.'),
      'rm13-commandments':('계명의 배열','Swete 출애굽기 20:13·14·15는 한글 구약 20:14·15·13에 대응합니다. 로마서는 간음·살인·도둑질·탐욕의 순서로 열거하며 SBLGNT에는 거짓 증언 계명이 없습니다.'),
      'rm12-repay':('보복의 문장','선택한 신명기 32:35는 보복의 날에 내가 갚겠다고 읽고 로마서는 원수 갚음이 내 것이라고 시작합니다.'),
    }
    for slug,note in extra.items():result[slug]['notes'].insert(1,note)
    groups=[['rm2-name','rm2-nations'],['rm3-none','rm3-throat','rm3-poison','rm3-mouth','rm3-path','rm3-fear'],['rm9-formed','rm9-potter','rm9-clay'],['rm9-people','rm9-children'],['rm9-remnant','rm9-finish'],['rm9-stumble','rm9-stone'],['rm10-heart','rm10-near'],['rm11-eyes','rm11-stupor','rm11-dull'],['rm11-deliverer','rm11-zion','rm11-remove','rm11-covenant'],['rm14-knee','rm14-live'],['rm15-praise','rm15-rejoice','rm15-nations','rm15-root']]
    for group in groups:
        present=[x for x in group if x in result]
        for key in present:result[key]['related']=[x for x in present if x!=key]
    return result
