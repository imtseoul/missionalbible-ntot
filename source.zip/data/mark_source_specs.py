"""Full chapter sources newly required by selected Mark comparisons."""
SELECTIONS={
'leviticus-2':('Lev.2','lev',2,'레위기 2장',16),
'2kings-1':('2Ki.1','2ki',1,'열왕기하 1장',18),
'joel-4':('Joe.3','jol',3,'요엘 3장',21),
'psalm-106':('Psa.106','psa',107,'시편 107편',43),
'psalm-40':('Psa.40','psa',41,'시편 41편',13),
'job-9':('Job.9','job',9,'욥기 9장',35),
'1samuel-22':('1Sa.22','1sa',22,'사무엘상 22장',23),
'ezekiel-17':('Eze.17','ezk',17,'에스겔 17장',24),
'numbers-27':('Num.27','num',27,'민수기 27장',23),
'amos-8':('Amo.8','amo',8,'아모스 8장',14),
'isaiah-43':('Isa.43','isa',43,'이사야 43장',28),
'ezekiel-12':('Eze.12','ezk',12,'에스겔 12장',28),
}
NT_COUNTS=[45,28,35,41,43,56,37,38,50,52,33,44,37,72,47,20]
EXTRA_OT=[]
