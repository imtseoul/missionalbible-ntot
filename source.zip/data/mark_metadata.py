"""Mark comparisons with source references and edition-aware chapter mapping."""
from copy import deepcopy
from pathlib import Path
import json
from mark_source_specs import SELECTIONS
from mark_rows import ROWS
from mark_notes import NOTES,BOUNDARIES
ARCHIVE='https://archive.org/details/ntg-28-nestle-aland-institute-for-new-testament-textual-research/page/n{}/mode/1up'

def nums(value):
    result=[]
    for part in value.split(','):
        start,*end=part.split('-');result.extend(range(int(start),int(end[0] if end else start)+1))
    return result

def build(existing):
    text=json.loads((Path(__file__).parent/'texts.json').read_text())['lxx'];result={}
    for row in ROWS.strip().splitlines():
        slug,key,nref,ls,page,sot,snt,kind,lead,note=row.split('|');ch,ns=nref.split(':');ch=int(ch);page=int(page);nv=nums(ns);lv=nums(ls)
        if key in SELECTIONS:
            prefix,_,_,otitle,_=SELECTIONS[key]
            title=('시편 '+key.split('-')[1]+'편') if key.startswith('psalm-') else otitle
            c=dict(title=title,other='개역한글 '+otitle,source_refs=sorted([r for r in text if r.startswith(prefix+':')],key=lambda r:int(r.split(':')[1])))
            if key=='psalm-40':c.update(ot_offset=-1,unmapped_lxx=[1],superscription_verses=[1])
            if key=='joel-4':c['title']='요엘 4장'
            if key=='ezekiel-12':c['ot_map_overrides']={5:[4,5]}
            if key in BOUNDARIES:c['boundary_notes']=BOUNDARIES[key]
        else:
            old=next(v for k,v in existing.items() if v.get('lxx_chapter_id',k)==key)
            c={f:deepcopy(old[f]) for f in ['title','other','source_refs','source_status','textual_notes','ot_offset','unmapped_lxx','superscription_verses','ot_map_overrides','ot_chapter_id','lxx_text_form','boundary_notes'] if f in old}
            if key=='joel-3':c['ot_offset']=27
        c.update(lxx_chapter_id=key,ot_chapter_id=c.get('ot_chapter_id',key),nt_book='Mark',nt_chapter=ch,nt=f'마가복음 {ch}:{ns.replace("-","–").replace(",",", ")}',nt_range=[min(nv),max(nv)],nt_selected=nv,lxx_range=[min(lv),max(lv)],lxx_selected=lv,kind=kind,lead=lead,description=note,ot_ref=c['title'].removesuffix('장').removesuffix('편')+':'+ls,source_entry={'ot':sot,'nt':snt},na28_verified={'page':page,'url':ARCHIVE.format(page+113),'typography':'not_transcribed','method':'reference_pairs_checked_in_OCR_of_primary_scan'})
        c['notes']=[('대조의 성격',note)]+NOTES.get(key,[])+[('장 경계',b) for b in c.get('boundary_notes',[])]
        result[slug]=c
    groups=[['mk1-messenger','mk1-before','mk1-way'],['mk1-son','mk1-servant'],['mk2-bread','mk2-abiathar'],['mk4-tree','mk4-birds'],['mk4-storm','mk4-calm','mk4-fear'],['mk6-shepherd','mk6-scattered'],['mk6-sea','mk6-pass','mk6-mountain','mk6-i-am'],['mk7-parents','mk7-curse'],['mk10-created','mk10-one-flesh','mk10-divorce','mk10-heart'],['mk10-commandments','mk10-defraud'],['mk11-prayer','mk11-den'],['mk13-desolation','mk13-abomination'],['mk13-darkness','mk13-stars'],['mk14-blood','mk14-covenant','mk14-many'],['mk14-right-hand','mk14-clouds']]
    for group in groups:
        for key in group:result[key]['related']=[x for x in group if x!=key]
    return result
