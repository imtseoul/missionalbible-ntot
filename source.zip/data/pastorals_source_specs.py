"""Additional Swete chapter sources for Thessalonian and Pastoral selections."""
SELECTIONS = {
    'ezekiel-37': ('Eze.37', 'ezk', 37, '에스겔 37장', 28),
    'isaiah-2': ('Isa.2', 'isa', 2, '이사야 2장', 22),
    'ezekiel-28': ('Eze.28', 'ezk', 28, '에스겔 28장', 26),
    'genesis-9': ('Gen.9', 'gen', 9, '창세기 9장', 29),
    'exodus-7': ('Exo.7', 'exo', 7, '출애굽기 7장', 25),
    'deuteronomy-7': ('Deu.7', 'deu', 7, '신명기 7장', 26),
    'deuteronomy-33': ('Deu.33', 'deu', 33, '신명기 33장', 29),
    'psalm-48': ('Psa.48', 'psa', 49, '시편 49편', 20),
    'psalm-129': ('Psa.129', 'psa', 130, '시편 130편', 8),
    'proverbs-28': ('Pro.28', 'pro', 28, '잠언 28장', 28),
    'ezekiel-18': ('Eze.18', 'ezk', 18, '에스겔 18장', 32),
    'jeremiah-11': ('Jer.11', 'jer', 11, '예레미야 11장', 23),
}
OVERRIDES = {
    'psalm-48': {'ot_offset': -1, 'unmapped_lxx': [1], 'superscription_verses': [1]},
    'proverbs-28': {'boundary_notes': ['Swete 17절 뒤에는 아들을 훈계하고 법을 어기는 민족에게 순종하지 말라는 문장이 이어집니다. 개역한글 17절에는 이 문장들이 없습니다.']},
    'jeremiah-11': {'boundary_notes': ['Swete에는 7절의 문장이 없으며, 8절은 그들이 행하지 않았다는 짧은 문장입니다.']},
    'isaiah-2': {'boundary_notes': ['Swete의 이사야 2장은 21절로 끝납니다. 개역한글 22절의 사람을 의지하지 말라는 문장은 이 본문에 없습니다.']},
    'ezekiel-28': {'ot_map_overrides': {14: [13,14], 26: [25,26]}, 'boundary_notes': ['창조된 날이라는 말은 Swete 14절과 개역한글 13절에 걸립니다. 야곱에게 준 땅에 산다는 문장은 Swete 26절과 개역한글 25절에 있습니다.']},
}
