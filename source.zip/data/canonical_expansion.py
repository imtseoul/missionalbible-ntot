"""Integrate the final twenty books without replacing earlier comparisons."""
import importlib
from nt_books import BOOKS
GROUPS=[('john','John'),('paul_remaining',None),('pastorals',None),('catholic',None),('revelation','Revelation')]
def expand(chapters,translations,pairs):
    for module in ['completion','completion_psalm',*[name for name,_ in GROUPS]]:
        new=importlib.import_module(module+'_translations').TRANSLATIONS
        for key,value in new.items():
            assert key not in translations or translations[key]==value,('conflicting translation',key)
            translations[key]=value
    for module,book in GROUPS:
        builder=importlib.import_module(module+'_metadata').build
        added=builder(chapters)
        newpairs=importlib.import_module(module+'_pairs').PAIRS
        assert not (chapters.keys() & added.keys()),('comparison id collision',module)
        assert not (newpairs.keys()-added.keys()),('unregistered phrase pairs',module,newpairs.keys()-added.keys())
        chapters.update(added);pairs.update({key:newpairs.get(key,[]) for key in added})
    order={book:n for n,book in enumerate(BOOKS)}
    return dict(sorted(chapters.items(),key=lambda item:(order[item[1].get('nt_book','Acts')],item[1]['nt_chapter'],item[1]['nt_range'][0])))
