"""Metadata for selected Thessalonian and Pastoral quotations and allusions."""
from complete_metadata import build_rows
from pastorals_rows import ROWS

def build(existing):
    return build_rows(existing, ROWS)
