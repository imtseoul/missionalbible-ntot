"""Accessible static detail pages with progressive reading controls."""
import hashlib
import html
import json

E = html.escape


def span_numbers(numbers):
    return ', '.join(str(n) for n in sorted(set(numbers)))


def reference(title, numbers):
    return title.removesuffix('장').removesuffix('편').strip() + ':' + span_numbers(numbers)


def render_reader(comp, chapter, book, neighbors, chapter_navigation):
    slug = comp['id']
    nt_title = f'{book["name"]} {comp["nt_chapter"]}장'
    titles = {'nt': nt_title, 'lxx': comp['lxx_title'], 'ot': comp['ot_chapter']['title']}
    editions = {'nt': '개역한글', 'lxx': '칠십인역 한국어 번역', 'ot': '개역한글'}
    greek_editions = {'nt': 'SBLGNT', 'lxx': 'Swete'}
    rows = {'nt': chapter['verses'], 'lxx': comp['verses'], 'ot': comp['ot_chapter']['verses']}
    chosen = {'nt': set(comp['nt_selected_verses']), 'lxx': set(comp['lxx_selected_verses'])}
    for pair in comp['pairs']:
        for side in ('nt', 'lxx'):
            chosen[side].update([pair[side]['ko_verse'], pair[side]['grc_verse']])
    chosen['ot'] = {m['ot_verse'] for m in comp['lxx_ot_verse_map'] if m['lxx_verse'] in chosen['lxx']}
    groups = comp['verse_comparisons']
    group_by_pair = {pid: group for group in groups for pid in group['pair_ids']}
    aligned = {(side, row['verse']): row['grc_html'] for group in groups for side in ('nt', 'lxx') for row in group[side]}

    def note_id(text):
        return 'note-' + hashlib.sha256(text.encode()).hexdigest()[:12]

    notes = {}
    for group in groups:
        for note in group['notes']:
            item = notes.setdefault(note['text'], {'title': note['title'], 'groups': []})
            if group['id'] not in item['groups']:
                item['groups'].append(group['id'])
    general_notes = list({note['text']: note for note in comp['notes'] if note['text'] not in notes}.values())

    def verse_status(row, side):
        messages = []
        if row.get('textual_note'):
            messages.append(row['textual_note'])
        if side == 'nt':
            ko = row.get('ko_status', '')
            if ko.startswith('content_in_'):
                messages.append('개역한글 결합 본문: ' + ko.rsplit('_', 1)[-1] + '절')
            if not row.get('grc'):
                messages.append('SBLGNT 본문 없음')
        return ''.join(f'<p class="reader-verse-note">{E(message)}</p>' for message in messages)

    def korean(row, side, annotated):
        text = row.get('ko')
        if text is None:
            return '<span class="reader-absence">본문 없음</span>'
        if not text:
            return '<span class="reader-absence">해당 절의 본문 상태 안내 참고</span>'
        if not annotated or side == 'ot':
            return E(text)
        pieces = []
        for pair in comp['pairs']:
            endpoint = pair[side]
            if endpoint['ko_verse'] == row['verse']:
                phrase = endpoint['ko_phrase']
                start = text.index(phrase)
                pieces.append((start, start + len(phrase), pair))
        result = ''
        end = 0
        for start, stop, pair in sorted(pieces):
            group = group_by_pair[pair['id']]
            result += E(text[end:start])
            result += (f'<a class="reader-phrase" href="#analysis-{group["id"]}" '
                       f'data-pair="{pair["id"]}" data-side="{side}" data-group="{group["id"]}" '
                       f'aria-controls="reader-analysis" aria-expanded="false">{E(text[start:stop])}</a>')
            end = stop
        return result + E(text[end:])

    def verse(row, side, excerpt=False):
        number = row['verse']
        ident = f'quote-{side}-{number}' if excerpt else f'{side}-{number}'
        label = comp['ot_chapter'].get('verse_refs', {}).get(str(number), str(number)) if side == 'ot' else str(number)
        classes = 'reader-verse' if excerpt else 'verse reader-full-verse'
        marked = set(comp[side + '_selected_verses']) if side != 'ot' else chosen['ot']
        if number in marked:
            classes += ' quoted'
        ref = reference(titles[side], [number])
        if side == 'ot' and ':' in label:
            ref = titles[side].rsplit(' ', 1)[0] + ' ' + label
        content = f'<article class="{classes}" id="{ident}" data-verse="{number}" data-ref="{E(ref)}">'
        content += f'<a class="reader-verse-number" href="#{ident}" aria-label="{E(ref)}">{E(label)}</a><div class="reader-verse-body">'
        content += f'<p class="reader-ko">{korean(row, side, excerpt)}</p>'
        if side != 'ot' and row.get('grc'):
            greek = aligned.get((side, number), E(row['grc'])) if excerpt else E(row['grc'])
            expanded = ' open' if excerpt else ''
            content += (f'<details class="reader-original"{expanded}><summary>헬라어 원문 · {greek_editions[side]}</summary>'
                        f'<p class="reader-greek" lang="grc">{greek}</p></details>')
        content += verse_status(row, side)
        if side == 'lxx':
            mapped = [m['ot_verse'] for m in comp['lxx_ot_verse_map'] if m['lxx_verse'] == number]
            if mapped:
                content += '<p class="reader-mapping">구약 개역한글: ' + ', '.join(
                    f'<a href="#ot-{n}">{E(comp["ot_chapter"].get("verse_refs", {}).get(str(n), str(n)))}절</a>' for n in mapped) + '</p>'
        return content + '</div></article>'

    def excerpt(side):
        content = f'<section class="reader-excerpt-column" data-copy-side="{side}" data-edition="{editions[side]}">'
        content += f'<header><h2>{E(titles[side])}</h2><p>{editions[side]}</p></header>'
        content += ''.join(verse(row, side, True) for row in rows[side] if row['verse'] in chosen[side])
        if not chosen[side]:
            content += '<p class="reader-verse-note">이 구절의 절 대응은 판본과 문맥 안내에서 확인할 수 있습니다.</p>'
        return content + '</section>'

    index = next(i for i, item in enumerate(neighbors) if item['id'] == slug)
    def adjacent(offset, label):
        pos = index + offset
        if 0 <= pos < len(neighbors):
            item = neighbors[pos]
            return f'<a href="{item["url"]}" rel="{"prev" if offset < 0 else "next"}">{label}<span>{E(item["lxx_title"])}</span></a>'
        return f'<span class="reader-nav-disabled">{label}<span>{"첫 대조" if offset < 0 else "마지막 대조"}</span></span>'

    body = f'<main id="main" class="reader-page" data-slug="{slug}" data-nt-chapter="{comp["nt_chapter"]}">'
    body += '<div class="reader-navigation">' + chapter_navigation + '</div>'
    body += f'<header class="reader-title"><h1>{E(comp["nt_ref"])}<span><span class="reader-title-divider" aria-hidden="true"> · </span>{E(comp["lxx_title"])}</span></h1><p>{E(comp["kind"])}</p></header>'
    body += '<div class="reader-tools"><details id="reader-preferences" class="reader-settings reader-js-control"><summary>보기 설정</summary><div>'
    body += '<label><input id="reader-greek" type="checkbox" checked> 헬라어 표시</label><label><input id="reader-ot" type="checkbox"> 구약 개역한글 표시</label>'
    body += '<label>글자 크기 <select id="reader-font"><option value="normal">기본</option><option value="large">크게</option><option value="xlarge">더 크게</option></select></label></div></details>'
    body += '<button class="reader-js-control" type="button" id="reader-copy">본문 복사</button><button class="reader-js-control" type="button" id="reader-share">링크 복사</button>'
    body += '<a href="#full-context">장 전체 읽기</a></div>'
    body += '<p id="reader-status" class="reader-status" role="status" aria-live="polite"></p><label class="reader-copy-fallback" hidden>복사할 내용<textarea readonly rows="5"></textarea></label>'
    body += '<p class="reader-hint">밑줄 친 표현을 선택하면 아래에서 해설을 펼쳐 읽을 수 있습니다.</p>'
    body += '<p class="reader-greek-legend">헬라어 대조: <span class="grc-shared">같은 말</span> · <span class="grc-changed">다른 말·어순</span></p>'
    body += '<div class="reader-excerpts">' + excerpt('nt') + excerpt('lxx') + '</div>'
    body += '<details id="reader-ot-excerpts" class="reader-disclosure"><summary>구약 개역한글 함께 읽기</summary>' + excerpt('ot') + '</details>'

    body += '<section id="reader-analysis" class="reader-analysis"><h2>차이와 문맥</h2>'
    summaries = list(dict.fromkeys(group['summary'] for group in groups if group['summary']))
    body += ''.join(f'<p class="reader-summary">{E(summary)}</p>' for summary in summaries if summary not in notes)
    for group in groups:
        body += f'<span class="reader-analysis-anchor" id="analysis-{group["id"]}" data-group-anchor="{group["id"]}" tabindex="-1"></span>'
    for text, item in notes.items():
        expanded = ' open' if text in summaries else ''
        body += (f'<details id="{note_id(text)}" class="reader-note" data-groups="{" ".join(item["groups"])}"{expanded}>'
                 f'<summary>{E(item["title"])}</summary><div><p>{E(text)}</p><button type="button" class="reader-close reader-js-control">해설 닫기</button></div></details>')
    body += '</section>'

    body += '<details id="reader-word-analysis" class="reader-disclosure"><summary>표현과 어순 자세히 보기</summary><div class="reader-word-analysis"><p class="reader-word-legend">헬라어의 같은 말은 실선, 다른 말과 어순은 점선으로 표시합니다.</p>'
    for group in groups:
        caption = reference(nt_title, [r['verse'] for r in group['nt']]) + ' · ' + reference(titles['lxx'], [r['verse'] for r in group['lxx']])
        body += f'<h3>{E(caption)}</h3><table class="reader-focus-table"><caption>{"핵심 표현의 뜻" if group["focus_text_kind"] == "gloss" else "핵심 표현"}</caption><thead><tr><th scope="col">신약</th><th scope="col">칠십인역</th></tr></thead><tbody>'
        for focus in group['focus_rows']:
            body += f'<tr><th colspan="2" scope="rowgroup">{E(focus["label"])}</th></tr><tr>'
            for side in ('nt', 'lxx'):
                body += f'<td><p>{E(focus[side]["ko"])}</p><p lang="grc">{focus[side]["grc_html"]}</p></td>'
            body += '</tr>'
        body += '</tbody></table>'
        if group['differences']:
            body += '<details class="reader-word-differences"><summary>어구별 차이</summary><dl>'
            for delta in group['differences']:
                body += f'<dt>{E(delta["relation"])}</dt><dd><span>신약</span><p lang="grc">{E(delta["nt"]) or "이 위치의 대응 어구 없음"}</p><span>칠십인역</span><p lang="grc">{E(delta["lxx"]) or "이 위치의 대응 어구 없음"}</p></dd>'
            body += '</dl></details>'
        if group.get('sources'):
            body += '<ul class="reader-source-links">' + ''.join(f'<li><a href="{E(s["url"])}" target="_blank" rel="noopener noreferrer">{E(s.get("label", s.get("title", s["url"])))}</a></li>' for s in group['sources']) + '</ul>'
    body += '</div></details>'

    body += '<details id="full-context" class="reader-disclosure reader-full-context"><summary>장 전체 문맥</summary><div>'
    body += '<div class="reader-context-controls reader-js-control" role="group" aria-label="전체 문맥을 읽을 본문">'
    for side, label in [('nt', '신약'), ('lxx', '칠십인역'), ('ot', '구약 개역한글'), ('parallel', '나란히 보기')]:
        body += f'<button type="button" id="tab-{side}" data-context="{side}" aria-pressed="{str(side == "nt").lower()}">{label}</button>'
    body += '</div><div class="reader-context-panels">'
    for side in ('nt', 'lxx', 'ot'):
        body += f'<details id="context-{side}" class="reader-context-panel"'+ (' open' if side == 'nt' else '') + f'><summary>{E(titles[side])} · {editions[side]}</summary><section><h3>{E(titles[side])} <span>{editions[side]}</span></h3>'
        body += ''.join(verse(row, side) for row in rows[side]) + '</section></details>'
    body += '</div></div></details>'

    body += '<details id="reader-source-notes" class="reader-disclosure"><summary>판본과 문맥 안내</summary><div>'
    if chapter.get('verse_map_note') and chapter['verse_map_note'] not in notes and all(note['text'] != chapter['verse_map_note'] for note in general_notes):
        body += f'<p>{E(chapter["verse_map_note"])}</p>'
    for note in general_notes:
        if note['text'] not in summaries:
            body += f'<section><h3>{E(note["title"])}</h3><p>{E(note["text"])}</p></section>'
    body += f'<p>신약 헬라어: SBLGNT · 칠십인역 헬라어: Swete</p><p><a href="{E(chapter["source_url"])}">신약 개역한글 출처</a> · <a href="{E(comp["ot_chapter"]["source_url"])}">구약 개역한글 출처</a> · <a href="/about/">판본과 이용 조건</a></p>'
    official = [{'book': book['code'], 'chapter': comp['nt_chapter'], 'title': nt_title}]
    official += comp['ot_chapter'].get('source_chapters') or [comp['ot_chapter']]
    body += '<p>' + ' · '.join(f'<a href="https://www.bskorea.or.kr/bible/korbibReadpage.php?version=GAE&amp;book={E(item["book"])}&amp;chap={item["chapter"]}">개역개정 {E(item["title"])}</a>' for item in official) + '</p></div></details>'
    body += '<details id="reader-neighbors" class="reader-disclosure"><summary>이 장의 다른 대조</summary><nav class="reader-neighbor-list" aria-label="이 장의 대조">'
    for item in neighbors:
        body += f'<a href="{item["url"]}"'+ (' aria-current="page"' if item['id'] == slug else '') + f'><span>{E(item["nt_ref"])}</span><strong>{E(item["lxx_title"])}</strong></a>'
    body += '</nav></details><nav class="reader-adjacent" aria-label="이전과 다음 대조">' + adjacent(-1, '이전 대조') + adjacent(1, '다음 대조') + '</nav>'
    body += '<p class="reader-catalog-link"><a href="/catalog/">전체 본문 목록</a></p></main>'
    pair_data = [{'id': p['id'], 'nt': [p['nt'][k] for k in ('ko_verse','ko_phrase','grc_verse','grc_phrase')], 'lxx': [p['lxx'][k] for k in ('ko_verse','ko_phrase','grc_verse','grc_phrase')], 'kind': p['relation']} for p in comp['pairs']]
    for ident, content in [('pair-data', pair_data), ('verse-comparison-data', groups), ('ot-mapping', comp['lxx_ot_verse_map'])]:
        body += f'<script type="application/json" id="{ident}">' + json.dumps(content, ensure_ascii=False).replace('<', '\\u003c') + '</script>'
    return body
