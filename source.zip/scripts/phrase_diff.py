"""Compare the displayed Greek phrases without changing either source text."""
from difflib import SequenceMatcher
import html
import re
import unicodedata


def words(text):
    return list(re.finditer(r'[^\W\d_]+(?:[\u0300-\u036f]+[^\W\d_]*)*', text))


def key(word):
    return ''.join(c for c in unicodedata.normalize('NFD', word).casefold()
                   if unicodedata.category(c) != 'Mn')


def compare(left, right):
    tokens = [words(left), words(right)]
    keys = [[key(m.group()) for m in row] for row in tokens]
    shared = [set(), set()]
    for a, b, size in SequenceMatcher(None, *keys, autojunk=False).get_matching_blocks():
        shared[0].update(range(a, a + size))
        shared[1].update(range(b, b + size))
    state = 'same' if keys[0] == keys[1] and keys[0] else 'partial' if shared[0] else 'different'
    rendered = []
    for side, text in enumerate([left, right]):
        parts = []
        position = 0
        runs = []
        for i, match in enumerate(tokens[side]):
            style = 'grc-shared' if i in shared[side] else 'grc-changed'
            if runs and runs[-1][2] == style:
                runs[-1][1] = match.end()
            else:
                runs.append([match.start(), match.end(), style])
        for start, end, style in runs:
            parts.append(html.escape(text[position:start]))
            parts.append(f'<span class="{style}">{html.escape(text[start:end])}</span>')
            position = end
        parts.append(html.escape(text[position:]))
        rendered.append(''.join(parts))
    return {'state': state, 'nt': rendered[0], 'lxx': rendered[1]}
