"""Acquire Luke and selected Swete/KRV OT chapters; preserve edition boundaries."""
import concurrent.futures,hashlib,json,re,sys,unicodedata,urllib.request
from pathlib import Path
from expand_sources import fetch_chapter
R=Path(__file__).resolve().parents[1];D=R/'data';sys.path.insert(0,str(D))
from luke_source_specs import SELECTIONS,NT_COUNTS

def main():
 sbl_url='https://raw.githubusercontent.com/morphgnt/sblgnt/master/63-Lk-morphgnt.txt'
 cache=D/'sbl-luke.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(sbl_url,timeout=60).read())
 raw=cache.read_bytes()
 text=json.loads((D/'texts.json').read_text());ot=json.loads((D/'krv-ot.json').read_text());prov=json.loads((D/'provenance.json').read_text())
 nt={}
 jobs=[(f'luke-{ch}','luk',ch,f'누가복음 {ch}장',count) for ch,count in enumerate(NT_COUNTS,1)]
 jobs += [(key,book,ch,title,count) for key,(_,book,ch,title,count) in SELECTIONS.items()]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):
   print(key,len(result['verses']),flush=True)
   if key.startswith('luke-'):nt[key.split('-')[1]]=result
   else:ot[key]=result
 for c in nt.values():c['grc']={}
 for line in raw.decode().splitlines():
  a=line.split();ch=str(int(a[0][2:4]));vn=str(int(a[0][4:6]));w=unicodedata.normalize('NFC',re.sub('[⸀-⸇]','',a[3]));g=nt[ch]['grc'];g[vn]=(g.get(vn,'')+' '+w).strip()
 for ch,c in nt.items():
  missing=set(c['verses'])-set(c['grc']);print('NT boundary',ch,sorted(missing),c['source_ranges'],flush=True)
  c['grc_status']={n:'absent_in_SBLGNT' for n in missing}
  c['grc']={n:c['grc'].get(n,'') for n in c['verses']}
 nt['20']['verse_map_note']='개역한글 20:43의 “내 우편에 앉았으라”는 SBLGNT 20:42 끝에 있습니다. 이어지는 원수와 발등상 표현은 두 판본 모두 20:43에 있습니다.'
 words={int(n):unicodedata.normalize('NFC',w) for n,w in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0]+':' for v in SELECTIONS.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if any(ref.startswith(p) for p in prefixes):text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 ot.pop('1samuel-21',None)
 known={(p['url'],p['sha256']) for p in prov}
 records=[dict(file='sbl-luke.source',url=sbl_url,sha256=hashlib.sha256(raw).hexdigest())]
 for c in [*nt.values(),*ot.values()]:records.append(dict(file=f'krv-{c["book"]}-{c["chapter"]}.source',url=c['source_url'],sha256=c['sha256']))
 for p in records:
  if (p['url'],p['sha256']) not in known:prov.append(p);known.add((p['url'],p['sha256']))
 for name,obj in [('nt-luke.json',nt),('texts.json',text),('krv-ot.json',ot),('provenance.json',prov)]: (D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 for slug,(prefix,*_) in SELECTIONS.items():
  rows=[(k,v) for k,v in text['lxx'].items() if k.startswith(prefix+':')];print(slug,len(rows),[k for k,v in rows if not v],flush=True)
if __name__=='__main__':main()
