"""Acquire Romans and selected Swete/KRV OT chapters; preserve edition boundaries."""
import concurrent.futures,hashlib,json,re,sys,unicodedata,urllib.request
from pathlib import Path
from expand_sources import fetch_chapter
R=Path(__file__).resolve().parents[1];D=R/'data';sys.path.insert(0,str(D))
from romans_source_specs import SELECTIONS,NT_COUNTS,EXTRA_OT

def verify_official(nt):
 url='https://raw.githubusercontent.com/Faithlife/SBLGNT/master/data/sblgnt/text/Rom.txt'
 cache=D/'sbl-romans-official.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(url,timeout=60).read())
 def lexical(s):return ''.join(c.lower() for c in unicodedata.normalize('NFD',s) if unicodedata.category(c) in ['Lu','Ll'])
 official={}
 for line in cache.read_text(encoding='utf-8-sig').splitlines():
  match=re.match(r'Rom (\d+):(\d+)\s+(.*)',line)
  if match:official[match[1],match[2]]=lexical(match[3])
 extracted={(ch,n):lexical(v) for ch,c in nt.items() for n,v in c['grc'].items() if v}
 assert official==extracted,'Romans differs lexically from the publisher SBLGNT text'
 print('Publisher SBLGNT lexical check:',len(official),'verses',flush=True)
 return dict(file=cache.name,url=url,sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),note='Romans MorphGNT lexical cross-check; official SBLGNT also ends at 16:24, without 16:25–27.')

def main():
 sbl_url='https://raw.githubusercontent.com/morphgnt/sblgnt/master/66-Ro-morphgnt.txt'
 cache=D/'sbl-romans.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(sbl_url,timeout=60).read())
 raw=cache.read_bytes()
 text=json.loads((D/'texts.json').read_text());ot=json.loads((D/'krv-ot.json').read_text());prov=json.loads((D/'provenance.json').read_text())
 nt={}
 jobs=[(f'romans-{ch}','rom',ch,f'로마서 {ch}장',count) for ch,count in enumerate(NT_COUNTS,1)]
 jobs += [(key,book,ch,title,count) for key,(_,book,ch,title,count) in SELECTIONS.items()] + EXTRA_OT
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):
   print(key,len(result['verses']),flush=True)
   if key.startswith('romans-'):nt[key.split('-')[1]]=result
   else:ot[key]=result
 for c in nt.values():c['grc']={}
 for line in raw.decode().splitlines():
  a=line.split();ch=str(int(a[0][2:4]));vn=str(int(a[0][4:6]));w=unicodedata.normalize('NFC',re.sub('[⸀-⸇]','',a[3]));g=nt[ch]['grc'];g[vn]=(g.get(vn,'')+' '+w).strip()
 for ch,c in nt.items():
  missing=set(c['verses'])-set(c['grc']);print('NT boundary',ch,sorted(missing),c['source_ranges'],flush=True)
  c['grc_status']={n:'absent_in_SBLGNT' for n in missing}
  c['grc']={n:c['grc'].get(n,'') for n in c['verses']}
 nt['9']['verse_map_note']='대한성서공회 개역한글은 9:1–2를 결합하여 표시합니다. 결합 본문을 1절에 수록하고 2절은 별도 중복하지 않았습니다. SBLGNT는 두 절을 나눕니다.'
 nt['16']['verse_map_note']='개역한글 16:24는 (없음)이며 SBLGNT는 축복 문장을 싣습니다. 반대로 개역한글 16:25–27의 송영은 SBLGNT에 없습니다. MorphGNT 전자본문을 발행처 Faithlife의 SBLGNT 파일과 어휘 대조하여 확인했습니다.'
 words={int(n):unicodedata.normalize('NFC',w) for n,w in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0]+':' for v in SELECTIONS.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if any(ref.startswith(p) for p in prefixes):text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 known={(p['url'],p['sha256']) for p in prov}
 records=[dict(file='sbl-romans.source',url=sbl_url,sha256=hashlib.sha256(raw).hexdigest()),verify_official(nt)]
 for c in [*nt.values(),*ot.values()]:records.append(dict(file=f'krv-{c["book"]}-{c["chapter"]}.source',url=c['source_url'],sha256=c['sha256']))
 for p in records:
  if (p['url'],p['sha256']) not in known:prov.append(p);known.add((p['url'],p['sha256']))
 for name,obj in [('nt-romans.json',nt),('texts.json',text),('krv-ot.json',ot),('provenance.json',prov)]: (D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 for slug,(prefix,*_) in SELECTIONS.items():
  rows=[(k,v) for k,v in text['lxx'].items() if k.startswith(prefix+':')];print(slug,len(rows),[k for k,v in rows if not v],flush=True)
if __name__=='__main__':main()
