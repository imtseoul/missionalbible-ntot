"""Validate the public NT/OT reader artifact before GitHub Pages publication."""
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
from zipfile import ZipFile

ORIGIN = 'https://ntot.missionalbible.org'
PARENT = 'https://www.missionalbible.org/'
ROOT_FILES = {'CNAME', '.nojekyll', 'README.md', 'LICENSE.txt', 'robots.txt',
              'sitemap.xml', 'llms.txt', 'source.zip', 'index.html', '404.html'}
PUBLIC_EXTENSIONS = {'.html', '.css', '.js', '.svg', '.png', '.ico', '.jpg', '.jpeg',
                     '.webp', '.woff', '.woff2', '.json', '.md', '.zip', '.txt'}


def route(path):
    return '/' + (path[:-10] if path.endswith('index.html') else path)


def public_path(path):
    p = PurePosixPath(path)
    if p.is_absolute() or '..' in p.parts:
        return False
    if path in ROOT_FILES:
        return True
    if any(part.startswith('.') for part in p.parts):
        return False
    if p.name.lower() in {'auth.json', 'credentials.json', 'secrets.json'}:
        return False
    if p.parts[0] in {'assets', 'data'}:
        return p.suffix in PUBLIC_EXTENSIONS
    return p.name == 'index.html' and (p.parts[0] in {'about', 'catalog'} or
                                      re.fullmatch(r'[a-z0-9]+-\d+', p.parts[0]) is not None)


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links, self.canonical = set(), [], []
        self.parent_links = []
        self.base = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a:
            assert a['id'] not in self.ids, a['id']
            self.ids.add(a['id'])
        self.links.extend(a[k] for k in ['href', 'src', 'data-source'] if k in a)
        if tag == 'link' and a.get('rel') == 'canonical':
            self.canonical.append(a.get('href'))
        if tag == 'a' and 'mb-parent-link' in a.get('class', '').split():
            self.parent_links.append(a.get('href'))
        if tag == 'meta' and a.get('name') == 'site-base':
            self.base = a.get('content')


def validate(root):
    root = Path(root).resolve()
    paths = list(root.rglob('*'))
    assert not any(p.is_symlink() for p in paths), 'Public artifacts cannot contain symlinks.'
    files = sorted(p for p in paths if p.is_file())
    for path in files:
        rel = path.relative_to(root).as_posix()
        assert not path.is_symlink() and public_path(rel), ('Non-public file', rel)
        assert path.stat().st_size <= 20_000_000, ('Oversized file', rel)
        if path.suffix in {'.html', '.css', '.js', '.json', '.md', '.txt', '.xml'}:
            text = path.read_text()
            assert '/ntuseofot/' not in text, ('Legacy mount', rel)
            assert 'https://imtarchive.webflow.io/ntuseofot' not in text, ('Legacy origin', rel)
    assert (root / 'CNAME').read_text().strip() == 'ntot.missionalbible.org'
    assert (root / '.nojekyll').is_file()
    robots = (root / 'robots.txt').read_text()
    assert f'Sitemap: {ORIGIN}/sitemap.xml' in robots
    pages = {}
    for path in root.rglob('*.html'):
        page = Page()
        page.feed(path.read_text())
        assert page.base == '/', path
        assert page.canonical == [ORIGIN + route(path.relative_to(root).as_posix())], path
        assert page.parent_links == [PARENT], path
        assert 'https://imt.or.kr/' in page.links, path
        pages[path] = page

    def link(value, source):
        url = urlsplit(value)
        if url.scheme and url.scheme not in {'http', 'https'}:
            return
        if url.netloc and url.netloc != 'ntot.missionalbible.org':
            return
        raw = unquote(url.path)
        target = root / raw.lstrip('/') if raw.startswith('/') else source.parent / raw if raw else source
        target = target.resolve()
        assert target.is_relative_to(root), (source, value)
        if target.is_dir():
            target /= 'index.html'
        assert target.exists(), (source, value)
        if url.fragment and target in pages:
            assert unquote(url.fragment) in pages[target].ids, (source, value)

    for path, page in pages.items():
        for value in page.links:
            link(value, path)

    def json_links(value, source):
        if isinstance(value, dict):
            for item in value.values():
                json_links(item, source)
        elif isinstance(value, list):
            for item in value:
                json_links(item, source)
        elif isinstance(value, str) and value.startswith('/') and not value.startswith('//'):
            link(value, source)

    for path in (root / 'data').rglob('*.json'):
        json_links(json.loads(path.read_text()), path)
    for path in (root / 'data').rglob('*.md'):
        for value in re.findall(r'\]\((/[^\s)]+)\)', path.read_text()):
            link(value, path)
    manifest = json.loads((root / 'data/reader.json').read_text())
    parts = []
    for book in manifest['books']:
        raw = (root / book['url'].lstrip('/')).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == book['sha256'], book['book']
        parts.append(json.loads(raw))
    with ZipFile(root / 'data/reader.zip') as archive:
        assert archive.testzip() is None
        full = json.loads(archive.read('reader.json'))
        assert '/ntuseofot/' not in archive.read('reader.md').decode()
        json_links(full, root / 'data/reader.json')
        assert b''.join(p.read_bytes() for p in sorted((root / 'data/markdown').glob('*.md'))) == archive.read('reader.md')
        assert [c for part in parts for c in part['nt_chapters']] == full['nt_chapters']
        assert [c for part in parts for c in part['comparisons']] == full['comparisons']
    assert len(parts) == 27 and manifest['scope']['nt_chapters'] == 260
    with ZipFile(root / 'source.zip') as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert not any(part.startswith('.') for part in path.parts), name
            assert not path.name.startswith(('.env', 'auth.json')) and path.suffix not in {'.pem', '.key', '.p12', '.pfx'}, name
    locs = [node.text for node in ET.parse(root / 'sitemap.xml').iter('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')]
    expected = {ORIGIN + route(path.relative_to(root).as_posix()) for path in pages if path.name != '404.html'}
    assert len(locs) == len(set(locs)) and set(locs) == expected
    return {'files': len(files), 'html_pages': len(pages), 'sitemap_urls': len(locs),
            'books': len(parts), 'comparisons': manifest['scope']['comparisons']}


if __name__ == '__main__':
    print(json.dumps(validate(sys.argv[1]), ensure_ascii=False))
