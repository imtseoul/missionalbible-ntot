#!/usr/bin/env python3
"""Dependency-free static publication; all biblical text is server-readable HTML."""
import json, sys, shutil, html
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'data'))
from editorial import CHAPTERS, TRANSLATIONS, PAIRS
TEXT = json.loads((ROOT/'data/texts.json').read_text())
OT = json.loads((ROOT/'data/krv-ot.json').read_text())
INDEX_POLICY = json.loads((ROOT/'data/index-policy.json').read_text())
OUT = ROOT/'dist'
OUT.mkdir(exist_ok=True)
shutil.copytree(ROOT/'assets',OUT/'assets',dirs_exist_ok=True)
E = html.escape
INDEX_SOURCE = 'https://matthewbarron.org/places-quoted-or-alluded-to-in-the-new-testament/'
SOURCES = [
 ('개역한글 · 대한성서공회','https://www.bskorea.or.kr/bible/korbibReadpage.php?version=HAN&book=act&chap=2'),
 ('개역한글 이용 안내','https://www.bskorea.or.kr/bbs/board.php?bo_table=copyright_faq&wr_id=5'),
 ('Swete 칠십인역 전자본문 · GPL-3.0','https://github.com/eliranwong/LXX-Swete-1930'),
 ('Swete 시편 인쇄본','https://archive.org/details/oldtestamenting02swet'),
 ('Swete 예언서 인쇄본','https://archive.org/details/oldtestgreek00unknuoft'),
 ('SBLGNT · CC BY 4.0','https://sblgnt.com/'),
 ('SBLGNT 전자본문 출처','https://github.com/morphgnt/sblgnt'),
 ('SBLGNT 발행처 전자본문','https://github.com/Faithlife/SBLGNT/tree/master/data/sblgnt/text'),
 ('SBLGNT 마태복음 · 발행처 전자본문 대조','https://github.com/Faithlife/SBLGNT/blob/master/data/sblgnt/text/Matt.txt'),
 ('SBLGNT 마가복음 · 발행처 전자본문 대조','https://github.com/Faithlife/SBLGNT/blob/master/data/sblgnt/text/Mark.txt'),
 ('SBLGNT 고린도전서 · 발행처 전자본문 대조','https://github.com/Faithlife/SBLGNT/blob/master/data/sblgnt/text/1Cor.txt'),
 ('SBLGNT 로마서 · 발행처 전자본문 대조','https://github.com/Faithlife/SBLGNT/blob/master/data/sblgnt/text/Rom.txt'),
 ('사도행전 항목 선정 자료 · NA27 부록 온라인 전사본',INDEX_SOURCE),
 ('NA28 부록 III 스캔 · 836–869쪽',INDEX_POLICY['na28_scan']),
 ('NA28 · 독일성서공회 판본 안내',INDEX_POLICY['na28_publisher']),
 ('NA28 부록 III 안내 · Seattle Pacific University 도서관',INDEX_POLICY['na28_appendix_reference']),
 ('UBS6 공식 미리보기 · 목차 VI쪽, 서문 VIII쪽',INDEX_POLICY['supplementary_edition']['publisher_sample']),
 ('일부 인용·비영리 사용에 관한 대한성서공회 안내','https://www.bskorea.or.kr/bbs/board.php?bo_table=copyright_faq&wr_id=8'),
 ('온라인 성경읽기 서비스 이용 안내','https://www.bskorea.or.kr/bbs/board.php?bo_table=copyright_faq&wr_id=9'),
 ('저작권법 제28조 · 공표된 저작물의 인용','https://www.law.go.kr/법령/저작권법/제28조'),
 ('저작권법 제35조의5 · 공정한 이용','https://www.law.go.kr/법령/저작권법/제35조의5')]
SOURCES += list(dict.fromkeys((f'개역한글 {v["title"]} · 대한성서공회',v['source_url']) for c in OT.values() for v in c.get('source_chapters',[c])))

from publication import publish
publish(ROOT, TEXT, OT, INDEX_POLICY, SOURCES)
