"""Acquire 1 Corinthians and selected Swete/KRV OT chapters; preserve edition boundaries."""
import concurrent.futures,hashlib,json,re,sys,unicodedata,urllib.request
from pathlib import Path
from expand_sources import fetch_chapter
R=Path(__file__).resolve().parents[1];D=R/'data';sys.path.insert(0,str(D))
from corinthians_source_specs import SELECTIONS,NT_COUNTS,EXTRA_OT

def verify_official(nt):
 url='https://raw.githubusercontent.com/Faithlife/SBLGNT/master/data/sblgnt/text/1Cor.txt'
 cache=D/'sbl-1corinthians-official.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(url,timeout=60).read())
 def lexical(s):return ''.join(c.lower() for c in unicodedata.normalize('NFD',s) if unicodedata.category(c) in ['Lu','Ll'])
 official={}
 for line in cache.read_text(encoding='utf-8-sig').splitlines():
  match=re.match(r'1Cor (\d+):(\d+)\s+(.*)',line)
  if match:official[match[1],match[2]]=lexical(match[3])
 extracted={(ch,n):lexical(v) for ch,c in nt.items() for n,v in c['grc'].items() if v}
 assert official==extracted,'1 Corinthians differs lexically from the publisher SBLGNT text'
 print('Publisher SBLGNT lexical check:',len(official),'verses',flush=True)
 return dict(file=cache.name,url=url,sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),note='1 Corinthians MorphGNT lexical cross-check against the publisher SBLGNT text.')

def main():
 sbl_url='https://raw.githubusercontent.com/morphgnt/sblgnt/master/67-1Co-morphgnt.txt'
 cache=D/'sbl-1corinthians.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(sbl_url,timeout=60).read())
 raw=cache.read_bytes()
 text=json.loads((D/'texts.json').read_text());ot=json.loads((D/'krv-ot.json').read_text());prov=json.loads((D/'provenance.json').read_text())
 nt={}
 jobs=[(f'1corinthians-{ch}','1co',ch,f'고린도전서 {ch}장',count) for ch,count in enumerate(NT_COUNTS,1)]
 jobs += [(key,book,ch,title,count) for key,(_,book,ch,title,count) in SELECTIONS.items()] + EXTRA_OT
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):
   print(key,len(result['verses']),flush=True)
   if key.startswith('1corinthians-'):nt[key.split('-')[1]]=result
   else:ot[key]=result
 for c in nt.values():c['grc']={}
 for line in raw.decode().splitlines():
  a=line.split();ch=str(int(a[0][2:4]));vn=str(int(a[0][4:6]));w=unicodedata.normalize('NFC',re.sub('[⸀-⸇]','',a[3]));g=nt[ch]['grc'];g[vn]=(g.get(vn,'')+' '+w).strip()
 for ch,c in nt.items():
  missing=set(c['verses'])-set(c['grc']);print('NT boundary',ch,sorted(missing),c['source_ranges'],flush=True)
  c['grc_status']={n:'absent_in_SBLGNT' for n in missing}
  c['grc']={n:c['grc'].get(n,'') for n in c['verses']}
 nt['14']['verse_map_note']='개역한글 14:34의 “모든 성도의 교회에서 함과 같이”는 SBLGNT 14:33 끝의 ὡς ἐν πάσαις ταῖς ἐκκλησίαις τῶν ἁγίων에 해당합니다. 두 판본의 절 구분을 각각 보존했습니다.'
 words={int(n):unicodedata.normalize('NFC',w) for n,w in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0]+':' for v in SELECTIONS.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if any(ref.startswith(p) for p in prefixes):text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 p114=ot.pop('psalm-114-krv');p115=ot['psalm-113']
 combined=dict(p114,title='시편 114–115편',source_chapters=[p114,p115])
 combined['verses']={str(i):v for i,v in enumerate([*p114['verses'].values(),*p115['verses'].values()],1)}
 combined['verse_refs']={str(i):(f'114:{i}' if i<=8 else f'115:{i-8}') for i in range(1,27)}
 combined['sha256']=hashlib.sha256((p114['sha256']+p115['sha256']).encode()).hexdigest()
 combined['source_hash_note']='SHA256 of the concatenated SHA256 strings for Psalms 114 and 115; individual source hashes retained in source_chapters.'
 ot['psalm-113']=combined
 lev6=ot['leviticus-6'];lev7=ot.pop('leviticus-7')
 combined=dict(lev6,title='레위기 6–7장',source_chapters=[lev6,lev7])
 combined['verses']={str(i):v for i,v in enumerate([*lev6['verses'].values(),*lev7['verses'].values()],1)}
 combined['verse_refs']={str(i):(f'6:{i}' if i<=30 else f'7:{i-30}') for i in range(1,69)}
 combined['sha256']=hashlib.sha256((lev6['sha256']+lev7['sha256']).encode()).hexdigest()
 combined['source_hash_note']='SHA256 of the concatenated SHA256 strings for Leviticus 6 and 7; individual source hashes retained in source_chapters.'
 ot['leviticus-6']=combined
 known={(p['url'],p['sha256']) for p in prov}
 records=[dict(file='sbl-1corinthians.source',url=sbl_url,sha256=hashlib.sha256(raw).hexdigest()),verify_official(nt)]
 for c in [*nt.values(),*[o for o in ot.values() if not o.get('source_chapters')],p114,p115,lev6,lev7]:records.append(dict(file=f'krv-{c["book"]}-{c["chapter"]}.source',url=c['source_url'],sha256=c['sha256']))
 for p in records:
  if (p['url'],p['sha256']) not in known:prov.append(p);known.add((p['url'],p['sha256']))
 for name,obj in [('nt-1corinthians.json',nt),('texts.json',text),('krv-ot.json',ot),('provenance.json',prov)]: (D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 for slug,(prefix,*_) in SELECTIONS.items():
  rows=[(k,v) for k,v in text['lxx'].items() if k.startswith(prefix+':')];print(slug,len(rows),[k for k,v in rows if not v],flush=True)
if __name__=='__main__':main()
