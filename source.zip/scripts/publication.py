"""Chapter-aware HTML, Markdown and JSON publication."""
import html, json, shutil, hashlib
from collections import Counter
from editorial import CHAPTERS, TRANSLATIONS, PAIRS
from reader_layout import render_reader
from verse_comparison import build as build_verse_comparisons
E=html.escape

def publish(root,text,ot,policy,sources):
    out=root/'dist'; out.mkdir(exist_ok=True)
    asset_version=hashlib.sha256(b''.join((root/'assets'/name).read_bytes() for name in ['reader.js','home.js','navigation.js','style.css','reader.css','imt-credit.css'])).hexdigest()[:12]
    fingerprint=hashlib.sha256()
    for folder in ['assets','data','scripts']:
        for source in sorted((root/folder).glob('*')):
            if source.is_file() and source.suffix in ['.py','.json','.js','.css','.html','.svg']:
                fingerprint.update(source.name.encode());fingerprint.update(source.read_bytes())
    site_version=fingerprint.hexdigest()[:16]
    from nt_books import BOOKS
    books={key:{**meta,'chapters':json.loads((root/'data'/meta['file']).read_text())} for key,meta in BOOKS.items()}
    nt={f'{b}:{n}':c for b,v in books.items() for n,c in v['chapters'].items()}
    def bookof(slug):return CHAPTERS[slug].get('nt_book','Acts')
    def bmeta(slug):return books[bookof(slug)]
    def ntname(slug):return bmeta(slug)['name']
    def ntkey(slug):return f'{bookof(slug)}:{CHAPTERS[slug]["nt_chapter"]}'

    unique_ot={(c['book'],c['chapter']):c for ctx in ot.values() for c in ctx.get('source_chapters',[ctx])}
    counts={'nt_chapters':len(nt),'nt_verse_slots':sum(len(c['verses']) for c in nt.values()),'nt_verses':sum(bool(v) and v!='(없음)' for c in nt.values() for v in c['verses'].values()),'lxx_chapters':len(TRANSLATIONS),'lxx_verse_slots':sum(len(v) for v in TRANSLATIONS.values()),'lxx_translated_slots':sum(v is not None for rows in TRANSLATIONS.values() for v in rows),'ot_verses':sum(len(c['verses']) for c in unique_ot.values()),'comparisons':len(CHAPTERS),'phrase_pairs':sum(map(len,PAIRS.values()))}
    scope_label='신약 27권 260장'
    counts['nt_books']=len(books)
    counts['ot_chapters']=len(unique_ot)
    kind_counts=Counter(c['kind'].split(' · ')[0] for c in CHAPTERS.values())
    kinds=', '.join(f'{k.replace("복합 인용","복합 인용의 구성 본문")} {v}건' for k,v in kind_counts.items())
    def lxxid(slug):return CHAPTERS[slug].get('lxx_chapter_id',slug)
    def otid(slug):return CHAPTERS[slug].get('ot_chapter_id',slug)
    def translations(slug):return TRANSLATIONS[lxxid(slug)]
    def otdata(slug):return ot[otid(slug)]
    index_source=policy['previous_entry_source']
    sources=[(t.replace('기존 세 연결의 출처','항목 선정 자료'),u) for t,u in sources]
    sources += [(c['title']+' · 개역한글',c['source_url']) for ch,c in nt.items() if ch!='Acts:2']
    sources += [('Swete 오경 인쇄본','https://archive.org/details/theoldtestamenti00unknuoft')]
    def ko_status(c,n):
        return c.get('ko_status',{}).get(str(n),'absent_in_KRV' if c['verses'][str(n)]=='(없음)' else 'present')
    def grc_note(c,n):
        status=c.get('grc_status',{}).get(str(n))
        if status=='verse_number_absent_content_in_40': return 'SBLGNT는 이 내용까지 19:40에 수록합니다. 절 구분의 차이입니다.'
        if status=='verse_number_absent_content_in_8': return '개역한글 이 절의 내용은 SBLGNT 24:8 앞부분에 있습니다. 절 구분의 차이입니다.'
        if status=='verse_number_absent_content_in_15': return '개역한글 이 절의 내용은 SBLGNT 7:15 뒷부분에 있습니다. 절 구분의 차이입니다.'
        return 'SBLGNT 본문 없음' if not c['grc'][str(n)] else ''
    def korean_note(c,n):
        status=ko_status(c,n)
        if status.startswith('content_in_'):return f'개역한글 결합 본문은 {status.rsplit("_",1)[-1]}절 위치에 수록했습니다.'
        if status.startswith('combined_range_'):return '개역한글 '+status.removeprefix('combined_range_').replace('_','–')+'절 결합 본문'
        return ''
    def chapter_nav(book,num):
        meta=books[book]; links=''.join(f'<a href="/{meta["slug"]}-{n}/"'+(' aria-current="page"' if int(n)==int(num) else '')+f'>{n}장</a>' for n in meta['chapters'])
        home_target=f'{meta["slug"]}-{num}' if any(c.get("nt_book","Acts")==book and c["nt_chapter"]==int(num) for c in CHAPTERS.values()) else meta["slug"]
        return f'<a class="book-switch" href="/#{home_target}">← 책·장 선택</a><details class="chapter-picker"><summary>{meta["name"]} {num}장 · 장 선택</summary><nav class="chapter-nav" aria-label="장 선택">{links}</nav></details>'
    def path(slug):return f'/{bmeta(slug)["slug"]}-{CHAPTERS[slug]["nt_chapter"]}/{slug}/'
    def ntdata(slug):return nt[ntkey(slug)]
    def otlabel(slug,n):return otdata(slug).get('verse_refs',{}).get(str(n),str(n))
    def otverses_for(slug,n):
        c=CHAPTERS[slug]
        if n in c.get('unmapped_lxx',[]): return []
        return c.get('ot_map_overrides',{}).get(n,[n+c.get('ot_offset',27 if slug=='joel-3' else 0)])
    def otverse(slug,n):return next(iter(otverses_for(slug,n)),None)
    def mapping(slug):
        return [{'lxx_verse':n,'ot_verse':o} for n in range(1,len(translations(slug))+1) for o in otverses_for(slug,n)]
    def selected(slug,side):
        c=CHAPTERS[slug]
        a,b=c['nt_range'] if side=='nt' else c['lxx_range']
        return c.get(side+'_selected',list(range(a,b+1)))
    def greek(slug,side,n):
        return ntdata(slug)['grc'][str(n)] if side=='nt' else text['lxx'][CHAPTERS[slug]['source_refs'][n-1]]
    def korean(slug,side,n):
        return ntdata(slug)['verses'][str(n)] if side=='nt' else translations(slug)[n-1]
    def official(book,ch,label='개역개정으로 읽기 ↗'):
        return f'<a href="https://www.bskorea.or.kr/bible/korbibReadpage.php?version=GAE&amp;book={book}&amp;chap={ch}" target="_blank" rel="noopener noreferrer">{E(label)}</a>'
    def head(title,desc,reader=False):
        page_title=title if title=='신약의 구약 사용' else f'{title} · 신약의 구약 사용'
        script=''.join(f'<script src="/assets/{name}.js?v={asset_version}" defer></script>' for name in ['reader','home','navigation'])
        return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(page_title)}</title><meta name="description" content="{E(desc)}"><meta name="theme-color" content="#142b40"><meta name="site-version" content="{site_version}"><link rel="stylesheet" href="/assets/style.css?v={asset_version}"><link rel="stylesheet" href="/assets/reader.css?v={asset_version}"><link rel="stylesheet" href="/assets/imt-credit.css"><link rel="alternate" type="application/json" href="/data/reader.json" title="본문과 대응 표현 데이터"><link rel="icon" href="/assets/icon.svg" type="image/svg+xml">{script}</head><body><a class="skip" href="#main">본문으로 이동</a><header class="masthead"><a class="brand" href="/"><span class="brand-symbol" aria-hidden="true">α<span>א</span></span><span>신약의 구약 사용</span></a><nav aria-label="주요 메뉴"><a href="/catalog/">본문 목록</a></nav></header><div id="site-content">'''
    def foot():
        return f'</div><p id="route-status" class="route-status" role="status" aria-live="polite" hidden></p><footer>신약의 구약 사용 <a class="footer-about" href="/about/">판본과 자료</a><a class="imt-credit" href="https://imt.or.kr/" target="_blank" rel="noopener noreferrer">Powered by 미셔널신학연구소</a></footer></body></html>'
    verse_details={slug:build_verse_comparisons(slug,c,PAIRS[slug],ntdata(slug),translations(slug),[text['lxx'][ref] for ref in c['source_refs']]) for slug,c in CHAPTERS.items()}
    def compact_selection(slug):
        nums=selected(slug,'lxx');runs=[];a=b=nums[0]
        for n in nums[1:]:
            if n==b+1:b=n
            else:runs.append(str(a) if a==b else f'{a}–{b}');a=b=n
        runs.append(str(a) if a==b else f'{a}–{b}')
        return CHAPTERS[slug]['title'].removesuffix('장').removesuffix('편')+':'+', '.join(runs)
    def citation_rows(items,with_subject=False):
        rows=[]
        for k,c in items:
            subject=f'<span class="passage-subject">{E(c["lead"])}</span>' if with_subject else ''
            rows.append(f'<a class="index-row" href="{path(k)}"><span class="nt-ref">{E(c["nt"].replace("마태복음","마").replace("마가복음","막").replace("누가복음","눅").replace("히브리서","히").replace("로마서","롬").replace("고린도전서","고전").replace("사도행전","행"))}</span><span class="ot-ref">{E(compact_selection(k))}{subject}</span><span class="relation">{E(c["kind"])}</span></a>')
        return ''.join(rows)
    def home_chapter(meta,num,local):
        return f'<section class="home-chapter" data-home-chapter="{meta["slug"]}-{num}" aria-labelledby="heading-{meta["slug"]}-{num}"><header class="home-chapter-heading"><div><h3 id="heading-{meta["slug"]}-{num}">{meta["name"]} {num}장</h3></div><a href="/{meta["slug"]}-{num}/">장 전체 읽기</a></header><div class="home-row-head" aria-hidden="true"><span>신약 본문</span><span>칠십인역 본문</span><span>구분</span></div><div class="index-rows">{citation_rows(local,with_subject=True)}</div></section>'
    home=head('신약의 구약 사용','신약의 구약 인용·암시 본문. 칠십인역 한국어 번역과 헬라어, 한글 구약 대조.')
    home+='<main id="main" class="passage-home home-browser home-enhanced"><h1 class="visually-hidden">신약의 구약 사용</h1><details class="home-book-picker"><summary><span id="current-book-name">마태복음</span><span class="book-picker-label">책 선택</span></summary><nav class="home-book-nav" aria-label="책 선택">'
    for book,meta in books.items():
        home+=f'<a id="book-tab-{meta["slug"]}" href="/catalog/#{meta["slug"]}" data-home-book="{meta["slug"]}"><span>{meta["name"]}</span></a>'
    home+='</nav></details><div class="home-books">'
    catalog=head('본문 목록',scope_label+' 인용·암시 대조')+'<main class="about catalog" id="main"><h1>본문 목록</h1><nav class="book-shortcuts">'+''.join(f'<a href="#{m["slug"]}">{m["name"]}</a>' for m in books.values())+'</nav>'
    home_dir=out/'data/home';home_dir.mkdir(parents=True,exist_ok=True)
    for previous in home_dir.glob('*.json'):previous.unlink()
    first_book=next(iter(books))
    for book,meta in books.items():
        items=[(k,c) for k,c in CHAPTERS.items() if bookof(k)==book]
        chapter_nums=[num for num in meta['chapters'] if any(c['nt_chapter']==int(num) for k,c in items)]
        if not items:chapter_nums=list(meta['chapters'])
        chapter_links=[];initial=''
        catalog+=f'<section id="{meta["slug"]}"><h2>{meta["name"]}</h2>'
        for num in chapter_nums:
            local=[(k,c) for k,c in items if c['nt_chapter']==int(num)]
            payload={'id':f'{meta["slug"]}-{num}','book':meta['slug'],'name':meta['name'],'chapter':int(num),'rows':[{'url':path(k),'nt':c['nt'].replace(meta['name'],meta['short']),'ot':compact_selection(k),'lead':c['lead'],'kind':c['kind']} for k,c in local]}
            raw=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
            version=hashlib.sha256(raw.encode()).hexdigest()[:12]
            filename=f'{meta["slug"]}-{num}-{version}.json';(home_dir/filename).write_text(raw)
            current=' aria-current="location"' if book==first_book and num==chapter_nums[0] else ''
            chapter_links.append(f'<a id="{meta["slug"]}-{num}" href="/{meta["slug"]}-{num}/" data-home-chapter-link="{meta["slug"]}-{num}" data-book="{meta["slug"]}" data-source="/data/home/{filename}" aria-label="{meta["name"]} {num}장"{current}>{num}</a>')
            if book==first_book and num==chapter_nums[0]:initial=home_chapter(meta,num,local)
            catalog+=f'<section id="{meta["slug"]}-{num}"><div class="book-heading"><h3>{num}장</h3><a href="/{meta["slug"]}-{num}/">장 전체 읽기</a></div>{citation_rows(local)}</section>'
        hidden='' if book==first_book else ' hidden'
        home+=f'<section class="home-book" id="{meta["slug"]}" data-home-panel data-name="{meta["name"]}" aria-labelledby="book-tab-{meta["slug"]}"{hidden}><aside class="home-chapters"><h2>{meta["name"]}</h2><p class="chapter-label">장 선택</p><nav class="home-chapter-grid" aria-label="{meta["name"]} 장 선택">{"".join(chapter_links)}</nav></aside><div class="home-chapter-list">{initial}</div></section>'
        catalog+='</section>'
        for num,c in meta['chapters'].items():
            local=[(k,v) for k,v in items if v['nt_chapter']==int(num)]
            links=citation_rows(local)
            body=''
            for n,value in c['verses'].items():
                notes=' · '.join(x for x in [korean_note(c,n),grc_note(c,n)] if x)
                body+=f'<article class="verse" id="nt-{n}"><a class="verse-no" href="#nt-{n}">{n}</a><div class="verse-body"><p>{E(value)}</p><p lang="grc" class="chapter-greek">{E(c["grc"][n])}</p>'+ (f'<p class="textual-status">{E(notes)}</p>' if notes else '')+'</div></article>'
            previous=f'<a href="/{meta["slug"]}-{int(num)-1}/">← {int(num)-1}장</a>' if int(num)>1 else '<span></span>'
            following=f'<a href="/{meta["slug"]}-{int(num)+1}/">{int(num)+1}장 →</a>' if int(num)<len(meta['chapters']) else '<a href="/">본문 목록 →</a>'
            content=head(f'{meta["name"]} {num}장',f'{meta["name"]} {num}장 개역한글·SBLGNT')
            content+=f'<main id="main" class="chapter-page"><h1>{meta["name"]} {num}장</h1>{chapter_nav(book,num)}<p>개역한글 · SBLGNT | {official(meta["code"],num)}</p><p>{E(c.get("verse_map_note",""))}</p>'
            if local:content+=f'<section class="chapter-comparisons"><h2>인용·암시</h2>{links}</section>'
            content+=f'<div class="reader-bottom">{previous}{following}</div><section aria-label="장 전체 본문">{body}</section><div class="reader-bottom">{previous}{following}</div></main>'+foot()
            target=out/f'{meta["slug"]}-{num}';target.mkdir(exist_ok=True);(target/'index.html').write_text(content)
    home+=f'</div><noscript><p><a href="/catalog/">모든 책의 본문 목록</a></p></noscript></main>'+foot()
    (out/'index.html').write_text(home)
    catalog+='</main>'+foot()
    (out/'catalog').mkdir(exist_ok=True);(out/'catalog/index.html').write_text(catalog)

    about=(root/'data/about-template.html').read_text()
    for key,value in counts.items():about=about.replace('{{'+key+'}}',f'{value:,}')
    about=head('판본과 자료','본문의 판본, 번역 상태, 출처, 이용 조건과 기계 판독용 자료입니다.')+about
    about_sources=[(t,u) for t,u in sources if u in {sources[0][1],sources[1][1],sources[2][1],sources[5][1],policy['na28_scan'],policy['previous_entry_source']}]
    about+=''.join(f'<li><a href="{E(u)}" target="_blank" rel="noopener noreferrer">{E(t)} ↗</a></li>' for t,u in about_sources)
    about+='</ul></section></main>'+foot()
    (out/'about').mkdir(exist_ok=True);(out/'about/index.html').write_text(about)

    dataset={'schema_version':'3.0','title':f'신약의 구약 사용: {scope_label} 선정 대조','translation_status':'AI-assisted draft; no independent scholarly review','scope':counts,'index_basis':policy,'editions':{'nt_ko':'개역한글, 대한성서공회','ot_ko':'개역한글, 대한성서공회','nt_grc':'SBLGNT, Michael W. Holmes, 2010; CC BY 4.0','lxx_grc':'Swete; eliranwong/LXX-Swete-1930; GPL-3.0','lxx_ko':'Original Korean research draft; GPL-3.0'},'sources':[{'title':t,'url':u} for t,u in sources],'nt_chapters':[],'comparisons':[]}
    def ntmarkdown(book,num):
        c=books[book]['chapters'][str(num)]
        return f'## {books[book]["name"]} {num}장 전체\n\n개역한글 / SBLGNT\n\n'+(c.get('verse_map_note','')+'\n\n' if c.get('verse_map_note') else '')+''.join(f'### {num}:{n}\n\n{v}\n\n{korean_note(c,n)}\n\n{c["grc"][n] or '['+grc_note(c,n)+']'}\n\n' for n,v in c['verses'].items())
    md=f'# 신약의 구약 사용\n\n{scope_label} 선정 대조 {counts["comparisons"]}건. 칠십인역 한국어 연구용 초안이며 독립 교열 전입니다.\n\n판본과 출처: /about/\n\n'
    for key,c in nt.items():
        book,num=key.split(':');meta=books[book]
        dataset['nt_chapters'].append({'ref':f'{book} {num}','book':book,'chapter':int(num),'source_url':c['source_url'],'source_sha256':c['sha256'],'verse_map_note':c.get('verse_map_note'),'source_ranges':c.get('source_ranges',{}),'verses':[{'verse':int(n),'ko':v,'grc':c['grc'][n],'ko_status':ko_status(c,n),'grc_status':c.get('grc_status',{}).get(n,'present')} for n,v in c['verses'].items()]})
        md+=ntmarkdown(book,num)
        (out/'data'/f'{meta["slug"]}-{num}.md').write_text(ntmarkdown(book,num)+'\n출처와 이용 조건: /about/\n')
    for slug,c in CHAPTERS.items():
        comp={'id':slug,'lxx_chapter_id':lxxid(slug),'ot_chapter_id':otid(slug),'url':path(slug),'kind':c['kind'],'nt_book':bookof(slug),'nt_chapter':c['nt_chapter'],'nt_ref':c['nt'],'nt_selected_verses':selected(slug,'nt'),'lxx_ref':c['ot_ref'],'lxx_title':c['title'],'lxx_selected_verses':selected(slug,'lxx'),'verses':[],'pairs':[],'notes':[{'title':a,'text':b} for a,b in c['notes']],'related_comparisons':c.get('related',[]),'related_references':c.get('related_references',[]),'boundary_notes':c.get('boundary_notes',[]),'lxx_text_form':c.get('lxx_text_form','Swete selected text')}
        for n,v in enumerate(translations(slug),1):
            comp['verses'].append({'verse':n,'source_ref':c['source_refs'][n-1],'ko':v,'grc':greek(slug,'lxx',n),'text_status':c.get('source_status',{}).get(n,'present'),'verse_kind':'superscription' if n in c.get('superscription_verses',[]) else 'verse','textual_note':c.get('textual_notes',{}).get(n)})
        for ident,np,lp,kind in PAIRS[slug]:
            ep=lambda p:{'ko_verse':p[0],'ko_phrase':p[1],'grc_verse':p[2],'grc_phrase':p[3]}
            comp['pairs'].append({'id':ident,'nt':ep(np),'lxx':ep(lp),'relation':kind})
        comp['index_verification']={'na28':'pending','ubs6':'pending','verified_source':index_source,'verified_source_edition':'NA27 online transcription','source_entry':c.get('source_entry',{'nt':c['nt'],'ot':c['ot_ref']}),'classification':'editorial; source row marks may cover multiple NT references','reviewed_on':('2026-09-22' if bookof(slug) not in ['Matthew','Mark','Luke','Acts','Romans','1Corinthians','Hebrews'] else '2026-09-19' if bookof(slug) in ['Romans','1Corinthians','Hebrews'] else '2026-09-18')}
        if c.get('na28_verified'):
            comp['index_verification'].update(na28=('reference_verified_from_scan_ocr' if c['na28_verified']['method']=='reference_pairs_checked_in_OCR_of_primary_scan' else 'verified_against_scan'),verification_method=c['na28_verified']['method'],verified_source=c['na28_verified']['url'],verified_source_edition='NA28',page=c['na28_verified']['page'],source_typography=c['na28_verified']['typography'])
        comp['verse_comparisons']=verse_details[slug]
        o=otdata(slug)
        comp['ot_chapter']={'title':o['title'],'book':o['book'],'chapter':o['chapter'],'edition':'개역한글','source_url':o['source_url'],'source_sha256':o['sha256'],'source_chapters':o.get('source_chapters',[]),'verse_refs':o.get('verse_refs',{}),'verses':[{'verse':int(n),'ko':v} for n,v in o['verses'].items()]}
        if o.get('source_hash_note'):comp['ot_chapter']['source_hash_note']=o['source_hash_note']
        comp['lxx_ot_verse_map']=mapping(slug)
        dataset['comparisons'].append(comp)
        cm=f'# {c["nt"]} ↔ 칠십인역 {c["title"]}\n\n분류: {c["kind"]}\n\n{c["other"]}\n\n칠십인역: 한국어 연구용 번역 초안 / Swete.\n\n'
        for v in comp['verses']:
            body=v['ko'] if v['ko'] is not None else '[본문 상태: '+v['textual_note']+']'
            cm+=f'## {c["title"]} {v["verse"]}절\n\n{body}\n\n{v["grc"]}\n\n원자료: {v["source_ref"]}; 상태: {v["text_status"]}\n\n'
        cm+=f'## 한글 구약 · {o["title"]} 전체 (개역한글)\n\n'+''.join(f'### {o.get("verse_refs",{}).get(n,str(o["chapter"])+":"+n)}\n\n{v}\n\n' for n,v in o['verses'].items())
        cm+='## 칠십인역–한글 구약 절 대응\n\n'+''.join(f'- 칠십인역 {m["lxx_verse"]}절 ↔ 한글 구약 {otlabel(slug,m["ot_verse"])}절\n' for m in mapping(slug))+'\n'
        cm+='## 대응 표현\n\n'
        for p in comp['pairs']:
            a=p['nt'];b=p['lxx'];cm+=f'- {p["id"]} ({p["relation"]}): 신약 {c["nt_chapter"]}:{a["ko_verse"]} “{a["ko_phrase"]}” ({a["grc_phrase"]}; 그리스어 {c["nt_chapter"]}:{a["grc_verse"]}) ↔ 칠십인역 {b["ko_verse"]}절 “{b["ko_phrase"]}” ({b["grc_phrase"]})\n'
        cm+='\n## 대조 메모\n\n'+'\n\n'.join(f'### {a}\n\n{b}' for a,b in c['notes'])+'\n\n'
        if c.get('related'):cm+='함께 읽기: '+', '.join(f'[{CHAPTERS[k]["title"]}]({path(k)})' for k in c['related'])+'\n\n'
        md+=cm.replace('# ','## ',1)
        (out/'data'/f'{slug}.md').write_text(cm+ntmarkdown(bookof(slug),c['nt_chapter'])+'\n출처와 이용 조건: /about/\n')
    md+='## 출처와 이용 조건\n\n'+'\n'.join(f'- [{t}]({u})' for t,u in sources)+'\n\n새 코드·한국어 번역·연결 자료와 Swete 전자자료: GPL-3.0. SBLGNT: CC BY 4.0. 개역한글: 대한성서공회 이용 안내.\n'
    chapters_by_key={(c['book'],c['chapter']):c for c in dataset['nt_chapters']}
    comparisons_by_chapter={}
    for comp in dataset['comparisons']:
        comparisons_by_chapter.setdefault((comp['nt_book'],comp['nt_chapter']),[]).append(comp)
    for comp in dataset['comparisons']:
        key=(comp['nt_book'],comp['nt_chapter'])
        body=render_reader(comp,chapters_by_key[key],books[comp['nt_book']],comparisons_by_chapter[key],chapter_nav(*key))
        page=head(comp['nt_ref']+' · '+comp['lxx_title'],CHAPTERS[comp['id']]['description'],reader=True)+body+foot()
        target=out/comp['url'].lstrip('/')
        target.mkdir(parents=True,exist_ok=True)
        (target/'index.html').write_text(page)
    # Book-sized JSON keeps every static asset below the hosting file limit.
    from zipfile import ZipFile,ZIP_DEFLATED
    whole_json=json.dumps(dataset,ensure_ascii=False,indent=2)+'\n'
    with ZipFile(out/'data/reader.zip','w',ZIP_DEFLATED) as archive:
        archive.writestr('reader.json',whole_json)
        archive.writestr('reader.md',md)
    manifest={k:v for k,v in dataset.items() if k not in ['nt_chapters','comparisons']}
    manifest.update(schema_version='3.1',format='book_manifest',full_archive='/data/reader.zip',books=[])
    book_dir=out/'data/books';book_dir.mkdir(exist_ok=True)
    for book,meta in books.items():
        comparisons=[c for c in dataset['comparisons'] if c['nt_book']==book]
        chapters=[c for c in dataset['nt_chapters'] if c['book']==book]
        lxx_contexts={c['lxx_chapter_id']:c['verses'] for c in comparisons}
        ot_contexts={(raw['book'],raw['chapter']):raw for c in comparisons for raw in (c['ot_chapter'].get('source_chapters') or [c['ot_chapter']])}
        local_counts={'nt_books':1,'nt_chapters':len(chapters),'nt_verse_slots':sum(len(c['verses']) for c in chapters),'nt_verses':sum(bool(v['ko']) and v['ko']!='(없음)' for c in chapters for v in c['verses']),'lxx_chapters':len(lxx_contexts),'lxx_verse_slots':sum(map(len,lxx_contexts.values())),'lxx_translated_slots':sum(v['ko'] is not None for vs in lxx_contexts.values() for v in vs),'ot_chapters':len(ot_contexts),'ot_verses':sum(len(c['verses']) for c in ot_contexts.values()),'comparisons':len(comparisons),'phrase_pairs':sum(len(c['pairs']) for c in comparisons)}
        part={**dataset,'title':meta['name']+'의 구약 사용','scope':local_counts,'site_scope':counts,'nt_chapters':chapters,'comparisons':comparisons}
        filename=meta['slug']+'.json';payload=json.dumps(part,ensure_ascii=False,indent=2)+'\n'
        (book_dir/filename).write_text(payload)
        manifest['books'].append({'book':book,'name':meta['name'],'url':'/data/books/'+filename,'sha256':hashlib.sha256(payload.encode()).hexdigest()})
    (out/'data/reader.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (out/'data/reader.md').write_text(md)
    shutil.copyfile(root/'data/provenance.json',out/'data/provenance.json')
    shutil.copyfile(root/'LICENSE',out/'LICENSE.txt')
    (out/'llms.txt').write_text(f'''# 신약의 구약 사용

{scope_label} 전체와 선정 대조 {counts["comparisons"]}건. 칠십인역 {counts["lxx_chapters"]}개 장·편의 새 한국어 번역 초안 및 Swete 그리스어, 오른쪽 한글 구약은 개역한글 장 전체입니다. 독립적인 전문가 교열 전입니다. 목록 기준은 NA28 부록 III입니다. 각 비교의 index_verification에서 NA28 성구 확인 방법(스캔 OCR 또는 육안 확인), 페이지, 출처 URL을 확인하십시오. 기존 NA27 전사본 기반 항목과 NA28 부록에서 확인한 항목을 구별합니다. NA28 부록의 서체 구분은 전사하지 않았으며 인용·암시 분류는 편집 판단입니다. UBS6 개별 항목 검증은 대기 중입니다. 완전한 인용·암시 목록이 아닙니다.

JSON 진입점 /data/reader.json은 schema 3.1의 book_manifest입니다. books 배열의 url을 따라 필요한 책의 JSON을 읽으십시오. 각 책 파일은 schema 3.0이며 scope는 해당 책의 수량, site_scope는 사이트 전체 수량입니다. /data/reader.zip에는 기존 전체 schema 3.0 reader.json과 전체 Markdown이 들어 있습니다. 책별 대조의 구약 장들은 중복될 수 있으므로 전체 수량을 구할 때 site_scope를 사용하십시오.\n\n각 comparisons의 verse_comparisons에는 대응하는 절 전체와 헬라어 차이, 어휘·구문·문맥 설명이 있습니다. pair_ids로 대응 표현과 연결합니다. 여러 신약 절이 칠십인역 한 절에 연결되면 함께 비교합니다. grc_html은 그리스어 원문을 바꾸지 않고 대응 단어에 표시만 붙인 HTML이며, grc가 원문입니다.\n\nJSON schema 3.0: nt_chapters의 book(영문 책 식별자)과 chapter 두 값을 comparisons의 nt_book과 nt_chapter에 함께 연결합니다. 장 번호만으로 결합하면 다른 책이 섞입니다. lxx_chapter_id와 ot_chapter_id는 반복 사용되는 장의 식별자입니다. 비교별 본문은 재수록되므로 고유 장 수는 scope를 사용하거나 이 식별자로 중복을 제거합니다. nt_verse_slots는 본문 없는 번호까지, nt_verses는 실제 한국어 본문이 있는 절만 셉니다. Matthew 17:21, 18:11, 23:14와 Mark 9:44, 9:46, 11:26, 15:28과 Luke 17:36, 23:17과 Acts 8:37, 15:34, 28:29는 ko="(없음)", ko_status=absent_in_KRV, grc="", grc_status=absent_in_SBLGNT입니다.

lxx_selected_verses는 비연속 범위를 지원합니다. lxx_ot_verse_map은 다대다 관계이며 하나의 절에 여러 행이 있을 수 있습니다. Exodus 18:18은 한글 구약 17·18절에, Exodus 32:8·9는 한글 구약 8절에 대응합니다. 한글 구약 Exodus 32:9에는 선택한 Swete 대응 절이 없습니다. Acts 15:25–26은 개역한글 결합 본문입니다. 25절에 한 번 수록하고 26절은 ko="", ko_status=content_in_25로 표시합니다. Acts 19:41은 SBLGNT 19:40에 내용이 포함되며 grc_status=verse_number_absent_content_in_40입니다. Acts 24:7의 한국어 내용은 SBLGNT 24:8 앞부분에 있으며 grc_status=verse_number_absent_content_in_8입니다. Romans 9:1–2도 개역한글 결합 본문으로, 1절에 한 번 싣고 2절은 ko="", ko_status=content_in_1입니다. Romans 16:24는 개역한글만 (없음)이고 SBLGNT에는 본문이 있습니다. Romans 16:25–27은 개역한글에는 있으나 SBLGNT에는 없어 grc_status=absent_in_SBLGNT입니다. Mark 7:16의 개역한글 본문은 SBLGNT 7:15 뒷부분이며 grc_status=verse_number_absent_content_in_15입니다. Mark 10:7의 SBLGNT에는 개역한글에 없는 아내와의 결합 구절이 있습니다. Mark 16:8은 SBLGNT의 이중 대괄호 안 짧은 결말을 함께 수록하여 grc_status=present_with_bracketed_shorter_ending이며, 16:9–20은 긴 결말로 grc_status=present_in_double_brackets입니다. 절 결합·경계 차이를 본문 누락으로 해석하지 마십시오. source_ranges와 verse_map_note를 확인하십시오.

Psalm 6:1, 8:1, 21:1, 30:1, 39:1, 44:1, 68:1, 88:1, 101:1은 표제이며 OT 본문 절과 대응하지 않습니다. Psalm 43:8, 115:5, 117:4, 1 Samuel 13:1, Deuteronomy 25:16, Jeremiah 7:1·27, Proverbs 4:7은 선택한 Swete 본문에 없어 ko=null, grc="", text_status=absent_in_selected_swete_text입니다. 이 상태를 번역 누락이나 완성된 번역으로 해석하지 마십시오.

Jonah의 한글 구약 1:17은 Swete 2:1에 해당합니다. Ezekiel 2:1과 1 Samuel 13:23은 한글 구약의 다른 장에도 걸치며 boundary_notes를 확인하십시오. Daniel 2·7·9·10·11·12는 Old Greek이며 Theodotion과 혼동하지 마십시오. 각 장은 /책슬러그-N/ HTML과 /data/책슬러그-N.md에서 읽을 수 있습니다. 책은 신약 정경 순서로 수록됩니다. 빌레몬서·요한삼서는 본문을 수록하며 선정 대조가 없습니다. Malachi 4의 Swete 4·5·6절은 개역한글 4:5·6·4에 대응합니다. Exodus 20의 십계명 순서와 Jeremiah 38의 후반 절 순서도 다르므로 lxx_ot_verse_map을 사용하십시오. Luke 20:43의 개역한글 “내 우편에 앉았으라”는 SBLGNT 20:42에 있습니다. Hebrews 3:9의 사십 년 표현은 SBLGNT 3:10에 있습니다. Psalm 94:8은 개역한글 Psalm 95:7–8과 연결되며 Exodus 25는 절 합침과 반복이 있으므로 단순한 일괄 오프셋을 적용하지 마십시오. Genesis 2·5·6, Numbers 12, Hosea 14, Haggai 2의 boundary_notes도 확인하십시오. Romans 대조에서는 Psalm 9:22–39가 한글 Psalm 10장에, Psalm 115가 한글 Psalm 116:10–19에 해당합니다. Job 41:2는 한글 Job 41:10–11의 경계를 포함합니다. Hosea 1:10과 2:23은 NA28의 히브리어 번호 2:1과 2:25에 해당합니다. 주석의 번역 난점과 절 경계 설명도 함께 읽으십시오. 1 Corinthians 14:34의 개역한글 “모든 성도의 교회에서 함과 같이”는 SBLGNT 14:33 끝에 있습니다. Swete Leviticus 6:31–40은 개역한글 7:1–10, Swete 7:1–28은 개역한글 7:11–38입니다. 이 두 대조의 ot_chapter_id는 leviticus-6으로 같고 한글 6–7장을 합친 68개 위치를 사용합니다. Psalm 113은 한글 114–115편을 합친 26개 위치입니다. 실제 한글 장·절은 ot_chapter.verse_refs를 확인하십시오. source_hash_note가 있으면 source_sha256는 원본 HTML 해시가 아니라 개별 해시 문자열을 연결한 값의 해시이며 source_chapters에 개별 출처가 있습니다. Hosea 13:16의 한글 본문은 Swete 14:1입니다. Jeremiah 23:30–31은 선택한 Swete에 본문이 없습니다.

- [본문 목록](/catalog/)
- [전체 Markdown](/data/reader.md)
- [책별 JSON 목록](/data/reader.json)\n- [전체 JSON·Markdown 압축 파일](/data/reader.zip)
- [판본과 출처](/about/)
- [소스](/source.zip)
''')
    (out/'robots.txt').write_text('User-agent: *\nAllow: /\n')
    print(json.dumps(counts,ensure_ascii=False))
