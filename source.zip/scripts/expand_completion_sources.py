"""Acquire chapter contexts for the remaining New Testament books."""
import concurrent.futures,hashlib,importlib,json,re,sys,unicodedata
from pathlib import Path
from expand_sources import fetch_chapter
R=Path(__file__).resolve().parents[1];D=R/'data';sys.path.insert(0,str(D))
MODULES=['john','paul_remaining','pastorals','catholic','revelation','completion']
def specifications():
 result={}
 for name in MODULES:
  path=D/f'{name}_source_specs.py'
  if path.exists():
   for key,value in importlib.import_module(name+'_source_specs').SELECTIONS.items():
    assert key not in result or result[key]==value,(key,result.get(key),value)
    result[key]=value
 return result

def main():
 specs=specifications();text=json.loads((D/'texts.json').read_text());ot=json.loads((D/'krv-ot.json').read_text());prov=json.loads((D/'provenance.json').read_text())
 words={int(n):unicodedata.normalize('NFC',w) for n,w in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0] for v in specs.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if ref.split(':')[0] in prefixes:text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 (D/'texts.json').write_text(json.dumps(text,ensure_ascii=False,indent=2)+'\n')
 jobs=[(key,book,ch,title,count) for key,(_,book,ch,title,count) in specs.items() if key not in ot]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):ot[key]=result;print(key,len(result['verses']),flush=True)
 known={(p['url'],p['sha256']) for p in prov}
 for key in specs:
  c=ot[key];p=dict(file=f'krv-{c["book"]}-{c["chapter"]}.source',url=c['source_url'],sha256=c['sha256'])
  if (p['url'],p['sha256']) not in known:prov.append(p);known.add((p['url'],p['sha256']))
 for name,obj in [('krv-ot.json',ot),('provenance.json',prov)]: (D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 print('Acquired',len(specs),'chapter contexts',flush=True)
if __name__=='__main__':main()
