"""Extract Acts 1–28 and selected LXX chapters; retain source hashes."""
import concurrent.futures, hashlib, html, json, re, unicodedata, urllib.request
from pathlib import Path
R=Path(__file__).resolve().parents[1]; D=R/'data'
SELECTIONS={
 'psalm-68':('Psa.68','psa',69,'시편 69편',36),
 'psalm-108':('Psa.108','psa',109,'시편 109편',31),
 'deuteronomy-18':('Deu.18','deu',18,'신명기 18장',22),
 'leviticus-23':('Lev.23','lev',23,'레위기 23장',44),
 'genesis-22':('Gen.22','gen',22,'창세기 22장',24),
 'psalm-117':('Psa.117','psa',118,'시편 118편',29),
 'psalm-2':('Psa.2','psa',2,'시편 2편',12),
 'deuteronomy-21':('Deu.21','deu',21,'신명기 21장',23),
 'genesis-12':('Gen.12','gen',12,'창세기 12장',20),
 'genesis-15':('Gen.15','gen',15,'창세기 15장',21),
 'exodus-1':('Exo.1','exo',1,'출애굽기 1장',22),
 'exodus-2':('Exo.2','exo',2,'출애굽기 2장',25),
 'exodus-3':('Exo.3','exo',3,'출애굽기 3장',22),
 'exodus-18':('Exo.18','exo',18,'출애굽기 18장',27),
 'exodus-32':('Exo.32','exo',32,'출애굽기 32장',35),
 'amos-5':('Amo.5','amo',5,'아모스 5장',27),
 'isaiah-66':('Isa.66','isa',66,'이사야 66장',24),
 'isaiah-53':('Isa.53','isa',53,'이사야 53장',12),
 '1samuel-3':('1Sa.3','1sa',3,'사무엘상 3장',21),
 '1samuel-13':('1Sa.13','1sa',13,'사무엘상 13장',23),
 'psalm-88':('Psa.88','psa',89,'시편 89편',52),
 'isaiah-44':('Isa.44','isa',44,'이사야 44장',28),
 'isaiah-45':('Isa.45','isa',45,'이사야 45장',25),
 'isaiah-55':('Isa.55','isa',55,'이사야 55장',13),
 'habakkuk-1':('Hab.1','hab',1,'하박국 1장',17),
 'isaiah-49':('Isa.49','isa',49,'이사야 49장',26),
 'psalm-145':('Psa.145','psa',146,'시편 146편',10),
 'amos-9':('Amo.9','amo',9,'아모스 9장',15),
 'exodus-22':('Exo.22','exo',22,'출애굽기 22장',31),
 'isaiah-6':('Isa.6','isa',6,'이사야 6장',13),
 'isaiah-42':('Isa.42','isa',42,'이사야 42장',25),
 'jeremiah-1':('Jer.1','jer',1,'예레미야 1장',19),
 'ezekiel-2':('Eze.2','ezk',2,'에스겔 2장',10),
 'ezekiel-4':('Eze.4','ezk',4,'에스겔 4장',17),
 'numbers-6':('Num.6','num',6,'민수기 6장',27),
 'daniel-12':('Dan.12','dan',12,'다니엘 12장',13),
 'jonah-1':('Jon.1','jnh',1,'요나 1장',17),
 'leviticus-17':('Lev.17','lev',17,'레위기 17장',16),
 'psalm-73':('Psa.73','psa',74,'시편 74편',23),
}
def fetch_chapter(job):
 key,book,chapter,title,count=job
 url=f'https://www.bskorea.or.kr/bible/korbibReadpage.php?version=HAN&book={book}&chap={chapter}'
 cache=D/f'krv-{book}-{chapter}.source'
 if not cache.exists():
  with urllib.request.urlopen(url,timeout=90) as response: cache.write_bytes(response.read())
 raw=cache.read_bytes(); s=raw.decode('utf-8')
 s=re.sub(r'<div\b[^>]*class=D2.*?</div>','',s,flags=re.S)
 s=re.sub(r'<a\b[^>]*class=comment.*?</a>','',s,flags=re.S)
 verses={n:re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>','',v))).strip() for n,v in re.findall(r'<span class="number">(\d+(?:-\d+)?).*?</span>(.*?)(?=</font></span>)',s,re.S)}
 ko_status={}; source_ranges={}; expanded={}
 for label,value in verses.items():
  if '-' in label:
   start,end=map(int,label.split('-'));source_ranges[str(start)]=[start,end]
   for number in range(start,end+1):
    expanded[str(number)]=value if number==start else ''
    ko_status[str(number)]=f'combined_range_{start}_{end}' if number==start else f'content_in_{start}'
  else:expanded[label]=value
 verses=expanded
 assert list(verses)==[str(n) for n in range(1,count+1)],(key,len(verses))
 assert all((v or n in ko_status) and '<' not in v and 'function' not in v for n,v in verses.items())
 return key,dict(book=book,chapter=chapter,title=title,source_url=url,verses=verses,ko_status=ko_status,source_ranges=source_ranges,sha256=hashlib.sha256(raw).hexdigest())
def main():
 text=json.loads((D/'texts.json').read_text()); ot=json.loads((D/'krv-ot.json').read_text())
 words={int(n):unicodedata.normalize('NFC',word) for n,word in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0]+':' for v in SELECTIONS.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if any(ref.startswith(p) for p in prefixes):
   text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 jobs=[(key,book,ch,title,count) for key,(_,book,ch,title,count) in SELECTIONS.items()]
 nt_counts=[26,47,26,37,42,15,60,40,43,48,30,25,52,28,41,40,34,28,41,38,40,30,35,27,27,32,44,31]
 jobs += [(f'acts-{ch}','act',ch,f'사도행전 {ch}장',count) for ch,count in enumerate(nt_counts,1)]
 nt={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):
   print(key,len(result['verses']),flush=True)
   if key.startswith('acts-'): nt[key.split('-')[1]]=result
   else: ot[key]=result
 for chapter in nt.values(): chapter['grc']={}
 for line in (D/'sbl.source').read_text().splitlines():
  parts=line.split(); ch=str(int(parts[0][2:4])); vn=str(int(parts[0][4:6]))
  if ch in nt:
   word=re.sub('[⸀⸁⸂⸃⸄⸅]','',parts[3]); current=nt[ch]['grc']
   current[vn]=(current.get(vn,'')+' '+word).strip()
 for ch,item in nt.items():
  missing=set(item['verses'])-set(item['grc'])
  expected={'8':{'37'},'15':{'34'},'19':{'41'},'24':{'7'},'28':{'29'}}
  assert missing==expected.get(ch,set()),(ch,missing)
  item['grc_status']={n:'absent_in_SBLGNT' for n in missing}
  if ch=='13':item['verse_map_note']='개역한글 13:19 끝의 약 사백오십 년은 SBLGNT 13:20 첫머리에 있습니다.'
  if ch=='24':
   item['grc_status']['7']='verse_number_absent_content_in_8'
   item['verse_map_note']='개역한글 24:7의 심문하라는 말은 SBLGNT 24:8 앞부분에 있습니다. 서로 다른 절 구분을 유지했습니다.'
  if ch=='15':item['verse_map_note']='개역한글은 15:25–26을 하나의 문장으로 수록합니다. 한국어는 25절 위치에 한 번 싣고, 26절 위치에는 결합 수록 상태를 표시합니다. SBLGNT는 두 절로 나뉩니다. 또한 개역한글 15:18의 주께서 말씀하신다는 표현은 SBLGNT 15:17 끝부분에 있습니다.'
  if ch=='19':
   item['grc_status']['41']='verse_number_absent_content_in_40'
   item['verse_map_note']='개역한글 19:40–41의 내용은 SBLGNT 19:40에 함께 들어 있습니다. 41절의 내용이 없는 것이 아니라 절 구분이 다릅니다.'
  item['grc']={n:item['grc'].get(n,'') for n in item['verses']}
 assert nt['2']['verses']==text['krv'] and nt['2']['grc']==text['gnt']
 (D/'nt-chapters.json').write_text(json.dumps(nt,ensure_ascii=False,indent=2)+'\n')
 (D/'krv-ot.json').write_text(json.dumps(ot,ensure_ascii=False,indent=2)+'\n')
 (D/'texts.json').write_text(json.dumps(text,ensure_ascii=False,indent=2)+'\n')
 prov=json.loads((D/'provenance.json').read_text())
 known={(p['url'],p['sha256']) for p in prov}
 for item in [*nt.values(),*ot.values()]:
  if (item['source_url'],item['sha256']) not in known:
   prov.append(dict(file=f'krv-{item["book"]}-{item["chapter"]}.source',url=item['source_url'],sha256=item['sha256']))
 (D/'provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 for slug,(prefix,*_) in SELECTIONS.items():
  selected=[(ref,s) for ref,s in text['lxx'].items() if ref.startswith(prefix+':')]
  print(slug,len(selected),selected[0][0],selected[-1][0],flush=True)
if __name__=='__main__': main()
