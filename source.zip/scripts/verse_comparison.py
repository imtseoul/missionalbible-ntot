"""Whole-verse alignment and source-grounded reading notes, built once per page."""
from collections import Counter
from difflib import SequenceMatcher
from html import escape
import re
from phrase_diff import key,words,compare
from verse_notes import PAIR_NOTES,VERSE_NOTES
from comparison_readings import READINGS

def tokens(value):return [key(m.group()) for m in words(value)]
def full_alignment(nt,lxx):
    sides=[nt,lxx];flat=[[(row['verse'],m) for row in rows for m in words(row['grc'])] for rows in sides]
    keys=[[key(m.group()) for _,m in row] for row in flat]
    matcher=SequenceMatcher(None,*keys,autojunk=False);shared=[set(),set()]
    for a,b,n in matcher.get_matching_blocks():
        shared[0].update(range(a,a+n));shared[1].update(range(b,b+n))
    for side,rows in enumerate(sides):
        index=0
        for row in rows:
            output=[];position=0;runs=[]
            for match in words(row['grc']):
                style='grc-shared' if index in shared[side] else 'grc-changed';index+=1
                if runs and runs[-1][2]==style:runs[-1][1]=match.end()
                else:runs.append([match.start(),match.end(),style])
            for start,stop,style in runs:
                output.extend([escape(row['grc'][position:start]),f'<span class="{style}">{escape(row["grc"][start:stop])}</span>']);position=stop
            output.append(escape(row['grc'][position:]));row['grc_html']=''.join(output)
    def excerpt(side,start,end):
        return ' '.join(m.group() for _,m in flat[side][start:end])
    differences=[]
    for tag,a,b,c,d in matcher.get_opcodes():
        if tag=='equal':continue
        left=excerpt(0,a,b);right=excerpt(1,c,d)
        # Reordered words can fall outside an LCS even when present in both verses.
        moved=bool(left or right) and all(Counter(keys[0][a:b])[w]<=Counter(keys[1])[w] for w in keys[0][a:b]) and all(Counter(keys[1][c:d])[w]<=Counter(keys[0])[w] for w in keys[1][c:d])
        differences.append({'nt':left,'lxx':right,'relation':'어순·배치' if moved else '표현 차이' if left and right else '신약 쪽 어구' if left else '칠십인역 쪽 어구'})
    return differences

def build(slug,meta,pairs,ntchapter,lxxko,lxxgrc):
    groups=[];remaining=set(range(len(pairs)))
    while remaining:
        seed=min(remaining);members={seed};ns=set();ls=set();changed=True
        while changed:
            changed=False
            for i,p in enumerate(pairs):
                pn={p[1][0],p[1][2]};pl={p[2][0],p[2][2]}
                if i in members or ns&pn or ls&pl:
                    before=(len(members),len(ns),len(ls));members.add(i);ns.update(pn);ls.update(pl)
                    changed|=before!=(len(members),len(ns),len(ls))
        remaining-=members;chosen=[pairs[i] for i in sorted(members)]
        nt=[{'verse':n,'ko':ntchapter['verses'][str(n)],'grc':ntchapter['grc'][str(n)]} for n in sorted(ns)]
        lxx=[{'verse':n,'ko':lxxko[n-1],'grc':lxxgrc[n-1]} for n in sorted(ls)]
        differences=full_alignment(nt,lxx);notes=[];seen=set()
        reading=READINGS.get(slug,{})
        relevant=lambda item:not item.get('nt_verses') or bool(ns&set(item['nt_verses']))
        close_notes=[n for n in reading.get('notes',[]) if relevant(n)]
        authored_texts={n['text'] for n in reading.get('notes',[])}
        def add(title,text,pair_id=None):
            if text in seen:return
            seen.add(text);notes.append({'title':title,'text':text,'pair_id':pair_id})
        for n in close_notes:add(n['title'],n['text'])
        for p in chosen:
            for title,text in PAIR_NOTES.get(p[0],[]):add(title,text,p[0])
        for number,title,text in VERSE_NOTES.get(slug,[]):
            if number in ns:add(title,text)
        # Existing notes are relevant only if they name a compared Greek expression
        # or a verse in this panel; unrelated chapter commentary stays below the reader.
        for title,text in meta['notes']:
            if title=='대조의 성격' or text in authored_texts or close_notes:continue
            numbered=[int(n) for n in re.findall(r'(\d+)(?:절|(?=의))',text)]
            greek=re.findall(r'[\u0370-\u03ff\u1f00-\u1fff][\u0370-\u03ff\u1f00-\u1fff\u0300-\u036f]+',text)
            exact=any(g in ' '.join(r['grc'] for r in nt+lxx) for g in greek)
            if (set(numbered)&ls or exact) and not re.search(r'전사|보존|별도로|수록|초안|화면|옮겼습니다|연결했습니다',text):add(title,text)
        for p in chosen:
            if p[0] in PAIR_NOTES or close_notes:continue
            if tokens(p[1][3])==tokens(p[2][3]):
                if p[1][1]!=p[2][1]:add('같은 헬라어와 한국어 번역',f'신약의 “{p[1][1]}”와 칠십인역의 “{p[2][1]}”에 해당하는 헬라어는 {p[1][3]}로, 낱말과 어순이 같습니다.',p[0])
        if not differences:add('헬라어 문장','두 본문의 헬라어 낱말과 어순이 같습니다.')
        if ntchapter.get('verse_map_note') and any(p[1][0]!=p[1][2] for p in chosen):add('신약의 절 구분',ntchapter['verse_map_note'])
        context=meta.get('description','')
        if context and not reading and context not in seen:add('구약과 신약의 문맥',context)
        if not notes and context:add('구약과 신약의 문맥',context)
        rows=[{k:v for k,v in r.items() if k!='nt_verses'} for r in reading.get('rows',[]) if relevant(r)]
        glosses=bool(rows)
        if not rows:
            rows=[{'label':p[3],'pair_id':p[0],'nt':{'ko':p[1][1],'grc':p[1][3]},'lxx':{'ko':p[2][1],'grc':p[2][3]}} for p in chosen]
        # These rows are lexical evidence; commentary above explains its meaning.
        for row in rows:
            row['nt']=dict(row['nt']);row['lxx']=dict(row['lxx'])
            aligned=compare(row['nt']['grc'],row['lxx']['grc'])
            for side in ['nt','lxx']:row[side]['grc_html']=aligned[side]
        groups.append({'id':f'{slug}-verse-{len(groups)+1}','pair_ids':[p[0] for p in chosen],'nt':nt,'lxx':lxx,'differences':differences,'notes':notes,'summary':reading.get('summary',''),'focus_rows':rows,'focus_text_kind':'gloss' if glosses else 'quotation','sources':reading.get('sources',[])})
    return groups
