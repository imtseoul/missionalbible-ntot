"""Acquire the remaining twenty NT books without mutating shared source datasets."""
import concurrent.futures
import hashlib
import json
import re
import sys
import unicodedata
import urllib.request
from pathlib import Path

from expand_sources import fetch_chapter

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
sys.path.insert(0, str(DATA))
from nt_books import REMAINING_BOOKS


def cached_source(name, url):
    cache = DATA / name
    if not cache.exists():
        raw = urllib.request.urlopen(url, timeout=90).read()
        cache.write_bytes(raw)
    return cache.read_bytes(), dict(file=name, url=url,
                                   sha256=hashlib.sha256(cache.read_bytes()).hexdigest())


def lexical(value):
    return ''.join(c.lower() for c in unicodedata.normalize('NFD', value)
                   if unicodedata.category(c) in ['Lu', 'Ll'])


def greek_source(key, book):
    morph, morph_record = cached_source(
        f'sbl-{book["slug"]}.source',
        f'https://raw.githubusercontent.com/morphgnt/sblgnt/master/{book["morph_file"]}')
    publisher, publisher_record = cached_source(
        f'sbl-{book["slug"]}-official.source',
        f'https://raw.githubusercontent.com/Faithlife/SBLGNT/master/data/sblgnt/text/{book["publisher_file"]}')
    greek = {}
    for line in morph.decode().splitlines():
        parts = line.split()
        chapter, verse = str(int(parts[0][2:4])), str(int(parts[0][4:6]))
        word = unicodedata.normalize('NFC', re.sub('[⸀-⸇]', '', parts[3]))
        greek[chapter, verse] = (greek.get((chapter, verse), '') + ' ' + word).strip()
    official = {}
    official_text = {}
    for line in publisher.decode('utf-8-sig').splitlines():
        match = re.match(r'\S+ (\d+):(\d+)\s+(.*)', line)
        if match:
            official[match[1], match[2]] = lexical(match[3])
            official_text[match[1], match[2]] = unicodedata.normalize(
                'NFC', re.sub('[⸀-⸇]', '', match[3])).strip()
    # MorphGNT excludes this bracketed passage. The publisher prints it.
    publisher_only = set(official) - set(greek)
    expected_publisher_only = ({('7', '53'), *(('8', str(n)) for n in range(1, 12))}
                               if key == 'John' else set())
    assert publisher_only == expected_publisher_only, (key, publisher_only)
    greek.update({position: official_text[position] for position in publisher_only})
    extracted = {position: lexical(value) for position, value in greek.items()}
    assert official == extracted, (key, 'MorphGNT differs from publisher SBLGNT',
                                   set(official.items()) ^ set(extracted.items()))
    publisher_record['note'] = f'{key} MorphGNT lexical cross-check against the publisher SBLGNT text.'
    if publisher_only:
        publisher_record['note'] += ' John 7:53–8:11, absent from MorphGNT, is taken directly from the publisher, retaining double brackets.'
    return greek, [morph_record, publisher_record]


def add_boundary_notes(key, nt):
    if key == 'John':
        nt['5']['verse_map_note'] = 'SBLGNT에는 5:4의 천사가 못의 물을 움직인다는 구절과 5:3 끝의 물이 움직이기를 기다렸다는 말이 없습니다.'
        nt['7']['verse_map_note'] = 'SBLGNT는 7:53–8:11의 간음한 여인 이야기를 이중 대괄호로 표시합니다.'
        nt['8']['verse_map_note'] = nt['7']['verse_map_note']
        nt['7']['grc_status']['53'] = 'present_in_double_brackets'
        nt['8']['grc_status'].update({str(n): 'present_in_double_brackets' for n in range(1, 12)})
    if key == '2Corinthians':
        nt['13']['verse_map_note'] = '개역한글 13:11 끝의 “거룩하게 입맞춤으로 서로 문안하라”는 SBLGNT 13:12 앞부분에 있습니다.'
    if key == '2Thessalonians':
        nt['1']['verse_map_note'] = 'SBLGNT 1:8 첫머리의 ἐν φλογὶ πυρός(“불꽃 가운데서”)는 개역한글 1:7의 “불꽃 중에”에 해당합니다.'
    if key == '1John':
        nt['5']['verse_map_note'] = '개역한글 5:7의 성령이 증언하며 진리라는 말은 SBLGNT 5:6 뒷부분에 있습니다. 개역한글 5:8 앞의 “증거하는 이가 셋이니”는 SBLGNT 5:7에 해당합니다.'
    if key == 'Revelation':
        nt['12']['verse_map_note'] = 'SBLGNT 12:18의 “바다의 모래 위에 섰다”는 개역한글 12:17 끝에 있습니다. 개역한글 12장은 17절로 끝납니다.'


def main():
    records = []
    summaries = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        # Chapters are fetched concurrently; each book is written as soon as complete.
        for key, book in REMAINING_BOOKS.items():
            greek_future = pool.submit(greek_source, key, book)
            jobs = [(f'{book["slug"]}-{chapter}', book['code'], chapter,
                     f'{book["name"]} {chapter}장', count)
                    for chapter, count in enumerate(book['source_counts'], 1)]
            results = list(pool.map(fetch_chapter, jobs))
            greek, greek_records = greek_future.result()
            records.extend(greek_records)
            nt = {str(chapter): result for chapter, (_, result) in enumerate(results, 1)}
            if key == 'Revelation':
                # The entire Korean phrase is already in 12:17. Keep the extra
                # publisher verse number without repeating the Korean text.
                nt['12']['verses']['18'] = ''
                nt['12']['ko_status']['18'] = 'content_in_17'
            all_slots = {(ch, n) for ch, content in nt.items() for n in content['verses']}
            assert not (set(greek) - all_slots), (key, 'Greek verses outside Korean verse slots', set(greek) - all_slots)
            for chapter, content in nt.items():
                content['grc'] = {verse: greek.get((chapter, verse), '') for verse in content['verses']}
                content['grc_status'] = {verse: 'absent_in_SBLGNT' for verse, value in content['grc'].items() if not value}
                records.append(dict(file=f'krv-{content["book"]}-{content["chapter"]}.source',
                                    url=content['source_url'], sha256=content['sha256']))
            add_boundary_notes(key, nt)
            (DATA / book['file']).write_text(json.dumps(nt, ensure_ascii=False, indent=2) + '\n')
            summary = dict(chapters=len(nt), slots=len(all_slots), greek_verses=len(greek),
                           missing={ch: c['grc_status'] for ch, c in nt.items() if c['grc_status']},
                           combined={ch: c['source_ranges'] for ch, c in nt.items() if c['source_ranges']})
            summaries[key] = summary
            print(key, json.dumps(summary, ensure_ascii=False), flush=True)
            (DATA / 'remaining_nt_provenance.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    print('TOTAL', sum(v['chapters'] for v in summaries.values()), 'chapters;',
          sum(v['slots'] for v in summaries.values()), 'verse slots', flush=True)


if __name__ == '__main__':
    main()
