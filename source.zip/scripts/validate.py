"""Publication checks: source integrity, numbering exceptions and static access."""
import json,re,sys
from html import unescape
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
from zipfile import ZipFile
R=Path(__file__).resolve().parents[1];D=R/'dist'
sys.path.insert(0,str(R/'data'))
from editorial import CHAPTERS,TRANSLATIONS,PAIRS
manifest=json.loads((D/'data/reader.json').read_text())
assert manifest['schema_version']=='3.1' and manifest['format']=='book_manifest'
with ZipFile(D/'data/reader.zip') as archive:
 assert archive.testzip() is None
 data=json.loads(archive.read('reader.json'))
 assert archive.read('reader.md')==(D/'data/reader.md').read_bytes()
assert manifest['scope']==data['scope']
import hashlib
parts=[]
for entry in manifest['books']:
 raw=(D/entry['url'].lstrip('/')).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==entry['sha256']
 part=json.loads(raw);assert part['schema_version']=='3.0' and part['site_scope']==data['scope']
 assert part['scope']['nt_books']==1
 assert part['scope']['nt_chapters']==len(part['nt_chapters'])
 assert part['scope']['comparisons']==len(part['comparisons'])
 assert all(c['book']==entry['book'] for c in part['nt_chapters'])
 assert all(c['nt_book']==entry['book'] for c in part['comparisons'])
 parts.append(part)
assert [c for p in parts for c in p['nt_chapters']]==data['nt_chapters']
assert [c for p in parts for c in p['comparisons']]==data['comparisons']
assert len(parts)==27
assert all(p.stat().st_size<=25*1024*1024 for p in D.rglob('*') if p.is_file())
from nt_books import BOOKS
books={book:json.loads((R/'data'/meta['file']).read_text()) for book,meta in BOOKS.items()}
book_names={book:meta['name'] for book,meta in BOOKS.items()}
nt={f'{b}:{n}':c for b,chapters in books.items() for n,c in chapters.items()}
ot=json.loads((R/'data/krv-ot.json').read_text())
text=json.loads((R/'data/texts.json').read_text())
assert data['schema_version']=='3.0'
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='Acts']==[26,47,26,37,42,15,60,40,43,48,30,25,52,28,41,40,34,28,41,38,40,30,35,27,27,32,44,31]
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='Hebrews']==[14,18,19,16,14,20,28,13,28,39,40,29,25]
assert data['scope']['nt_books']==27 and data['scope']['nt_chapters']==260
assert len(data['comparisons'])==len(CHAPTERS)>1000
for book,meta in BOOKS.items():
 assert [len(c['verses']) for c in data['nt_chapters'] if c['book']==book]==meta['counts'],book
assert data['index_basis']['edition']=='NA28'
assert nt['Acts:2']['verses']==text['krv'] and nt['Acts:2']['grc']==text['gnt']
pubnt={f'{c["book"]}:{c["chapter"]}':c for c in data['nt_chapters']}
for key,c in nt.items():
 book,ch=key.split(':')
 assert list(c['verses'])==list(c['grc'])==[str(i) for i in range(1,len(c['verses'])+1)]
 assert pubnt[key]['verses']==[{'verse':int(n),'ko':v,'grc':c['grc'][n],'ko_status':c.get('ko_status',{}).get(n,'absent_in_KRV' if v=='(없음)' else 'present'),'grc_status':c.get('grc_status',{}).get(n,'present')} for n,v in c['verses'].items()]
 for v in pubnt[key]['verses']:
  if not v['grc']:
   assert (key,v['verse']) in [('John:5',4),('Matthew:17',21),('Matthew:18',11),('Matthew:23',14),('Mark:7',16),('Mark:9',44),('Mark:9',46),('Mark:11',26),('Mark:15',28),('Acts:8',37),('Acts:15',34),('Acts:19',41),('Acts:24',7),('Acts:28',29),('Luke:17',36),('Luke:23',17),('Romans:16',25),('Romans:16',26),('Romans:16',27)]
   assert v['grc_status']==({'Mark:7':'verse_number_absent_content_in_15','Acts:19':'verse_number_absent_content_in_40','Acts:24':'verse_number_absent_content_in_8'}.get(key,'absent_in_SBLGNT'))
  if not v['ko']:assert (key,v['verse'],v['ko_status']) in [('Acts:15',26,'content_in_25'),('Romans:9',2,'content_in_1'),('Revelation:12',18,'content_in_17')]
 assert pubnt[key]['verse_map_note']==c.get('verse_map_note')
 assert pubnt[key]['source_ranges']==c.get('source_ranges',{})
 assert all(not re.search(r'<|>|javascript|\bfunction\b|ㄱ\)|ㄴ\)',v) for v in c['verses'].values())
pairids=[]
for c in data['comparisons']:
 slug=c['id']
 assert [v['ko'] for v in c['ot_chapter']['verses']]==list(ot[c['ot_chapter_id']]['verses'].values())
 assert [v['ko'] for v in c['verses']]==TRANSLATIONS[c['lxx_chapter_id']]
 assert c['nt_chapter']==CHAPTERS[slug]['nt_chapter']
 assert c['index_verification']['ubs6']=='pending'
 verification=CHAPTERS[slug].get('na28_verified')
 expected=('reference_verified_from_scan_ocr' if verification['method']=='reference_pairs_checked_in_OCR_of_primary_scan' else 'verified_against_scan') if verification else 'pending'
 assert c['index_verification']['na28']==expected
 assert c['nt_selected_verses'] and c['lxx_selected_verses']
 assert set(c['nt_selected_verses'])<=set(range(1,len(nt[f'{c["nt_book"]}:{c["nt_chapter"]}']["verses"])+1))
 assert set(c['lxx_selected_verses'])<=set(range(1,len(c['verses'])+1))
 for v in c['verses']:
  assert v['grc']==text['lxx'][v['source_ref']] and not re.search('[⸀-⸇]',v['grc'])
  if not v['grc']:
   assert (c['lxx_chapter_id'],v['verse']) in [('psalm-54',6),('jeremiah-11',7),('psalm-118',51),('proverbs-11',4),('ezekiel-1',14),('jeremiah-28',45),('jeremiah-28',46),('jeremiah-28',47),('jeremiah-28',48),('psalm-117',4),('1samuel-13',1),('deuteronomy-25',16),('jeremiah-7',1),('jeremiah-7',27),('proverbs-4',7),('psalm-43',8),('psalm-115',5),('jeremiah-23',30),('jeremiah-23',31)] and v['ko'] is None
   assert v['text_status']=='absent_in_selected_swete_text'
  else:assert v['ko'] and v['text_status']=='present'
 for m in c['lxx_ot_verse_map']:
  assert 1<=m['lxx_verse']<=len(c['verses']) and 1<=m['ot_verse']<=len(c['ot_chapter']['verses'])
 for p in c['pairs']:
  pairids.append(p['id'])
  for side in ['nt','lxx']:
   e=p[side];vs=pubnt[f'{c["nt_book"]}:{c["nt_chapter"]}']['verses'] if side=='nt' else c['verses']
   assert vs[e['ko_verse']-1]['ko'].count(e['ko_phrase'])==1,(slug,p['id'],side)
   assert e['grc_phrase'] in vs[e['grc_verse']-1]['grc'],(slug,p['id'],side)
 # The click-open comparison must preserve complete source verses, including
 # Korean/Greek verse-boundary differences, without duplicating linked phrases.
 groups=c['verse_comparisons']
 assert sorted(pid for group in groups for pid in group['pair_ids'])==sorted(p['id'] for p in c['pairs'])
 for group in groups:
  selected=[p for p in c['pairs'] if p['id'] in group['pair_ids']]
  assert selected and group['notes'] and all(n['title'] and n['text'].strip() for n in group['notes'])
  assert group['focus_rows'] and group['focus_text_kind'] in ['quotation','gloss']
  assert all('가 대응합니다.' not in n['text'] for n in group['notes'])
  for focus in group['focus_rows']:
   for side in ['nt','lxx']:
    assert focus[side]['grc'] in ' '.join(v['grc'] for v in group[side]),(slug,side,focus['label'])
    assert unescape(re.sub(r'<[^>]*>','',focus[side]['grc_html']))==focus[side]['grc']
    if group['focus_text_kind']=='quotation':
     assert any(focus[side]['ko'] in v['ko'] for v in group[side]),(slug,side)
  for side in ['nt','lxx']:
   expected=sorted({p[side][key] for p in selected for key in ['ko_verse','grc_verse']})
   assert [v['verse'] for v in group[side]]==expected,(slug,side)
   source=pubnt[f'{c["nt_book"]}:{c["nt_chapter"]}']['verses'] if side=='nt' else c['verses']
   for row in group[side]:
    original=source[row['verse']-1]
    assert all(row[key]==original[key] for key in ['ko','grc']),(slug,side,row['verse'])
    assert unescape(re.sub(r'<[^>]*>','',row['grc_html']))==row['grc'],(slug,side)
    spans=sorted((row['ko'].index(p[side]['ko_phrase']),len(p[side]['ko_phrase'])) for p in selected if p[side]['ko_verse']==row['verse'])
    assert all(start+length<=next_start for (start,length),(next_start,_) in zip(spans,spans[1:])),(slug,side)
 if slug=='psalm-68':
  assert c['verses'][0]['verse_kind']=='superscription'
  assert c['lxx_ot_verse_map']==[{'lxx_verse':n,'ot_verse':n-1} for n in range(2,38)]
 if slug=='joel-3':assert c['lxx_ot_verse_map']==[{'lxx_verse':n,'ot_verse':n+27} for n in range(1,6)]
 if slug=='deuteronomy-18':assert c['lxx_selected_verses']==[15,18,19]
 if slug=='exodus-3-call':assert c['lxx_selected_verses']==[5,7,8,10]
 if slug=='exodus-32':
  assert c['lxx_selected_verses']==[1,23]
  assert [m for m in c['lxx_ot_verse_map'] if m['ot_verse'] in [8,9]]==[{'lxx_verse':8,'ot_verse':8},{'lxx_verse':9,'ot_verse':8}]
 if slug=='exodus-18':
  assert [m for m in c['lxx_ot_verse_map'] if m['lxx_verse']==18]==[{'lxx_verse':18,'ot_verse':18},{'lxx_verse':18,'ot_verse':17}]
 if slug=='psalm-109':
  p=next(p for p in c['pairs'] if p['id']=='q-seat');assert p['nt']['ko_verse']==35 and p['nt']['grc_verse']==34
assert len(pairids)==len(set(pairids))==data['scope']['phrase_pairs'] and len(pairids)>1019
from comparison_readings import READINGS
for slug,reading in READINGS.items():
 comp=next(c for c in data['comparisons'] if c['id']==slug)
 assert all(any(n['text']==note['text'] for n in comp['notes']) for note in reading['notes'])
 for group in comp['verse_comparisons']:
  assert group['summary']==reading['summary']
  ns={v['verse'] for v in group['nt']}
  for note in reading['notes']:
   applicable=not note['nt_verses'] or bool(ns&set(note['nt_verses']))
   assert any(n['text']==note['text'] for n in group['notes'])==applicable,(slug,note['title'])
unique={c['lxx_chapter_id']:c['verses'] for c in data['comparisons']}
assert len(unique)==data['scope']['lxx_chapters']==len(TRANSLATIONS)
assert sum(map(len,unique.values()))==data['scope']['lxx_verse_slots']
for c in data['comparisons']:assert c['verses']==unique[c['lxx_chapter_id']]
class Page(HTMLParser):
 def __init__(self):
  super().__init__();self.ids=set();self.links=[];self.verses={};self.pairs={};self.slug=None;self.ntch=None
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:
   assert a['id'] not in self.ids,a['id'];self.ids.add(a['id'])
  for k in ['href','src']:
   if k in a:self.links.append(a[k])
  if tag=='article' and 'verse' in a.get('class','').split():self.verses[a['id']]=a['class']
  if 'data-pair' in a:self.pairs.setdefault(a['data-pair'],[]).append(a['data-side'])
  if 'data-slug' in a:self.slug=a['data-slug'];self.ntch=int(a['data-nt-chapter'])
pages={}
for f in D.rglob('*.html'):
 p=Page();p.feed(f.read_text());pages[f]=p
for f,p in pages.items():
 assert 'site-content' in p.ids and 'route-status' in p.ids
 assert '/assets/navigation.js?' in f.read_text()
 for link in p.links:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  raw=unquote(u.path);target=D/raw.lstrip('/') if raw.startswith('/') else f.parent/raw if raw else f
  if target.is_dir():target=target/'index.html'
  assert target.exists(),(f,link)
  if u.fragment and target in pages:assert u.fragment in pages[target].ids,(f,link)
 if p.slug:
  c=next(c for c in data['comparisons'] if c['id']==p.slug)
  assert p.ntch==c['nt_chapter']
  embedded=re.search(r'<script[^>]* id="verse-comparison-data"[^>]*>(.*?)</script>',f.read_text(),re.S)
  assert embedded and json.loads(embedded[1])==c['verse_comparisons'],f
  for side,count in [('nt',len(nt[f'{c["nt_book"]}:{p.ntch}']['verses'])),('lxx',len(c['verses'])),('ot',len(c['ot_chapter']['verses']))]:
   assert len([k for k in p.verses if k.startswith(side+'-')])==count
  assert sorted(p.pairs)==sorted(x['id'] for x in c['pairs'])
  assert all(sorted(v)==['lxx','nt'] for v in p.pairs.values())
  assert all('tab-'+side in p.ids for side in ['nt','lxx','ot'])
  assert [int(k[4:]) for k,v in p.verses.items() if k.startswith('lxx-') and 'quoted' in v]==c['lxx_selected_verses']
  full=(D/'data'/f'{p.slug}.md').read_text()
  assert full.split(f'## {book_names[c["nt_book"]]} {p.ntch}장 전체')[1].count(f'### {p.ntch}:')==len(nt[f'{c["nt_book"]}:{p.ntch}']['verses'])
assert len(pages)==len(CHAPTERS)+260+3
for book,chapters in books.items():
 for ch,c in chapters.items():
  num=int(ch);slug=book.lower();p=pages[D/f'{slug}-{num}'/'index.html']
  assert sorted(int(k[3:]) for k in p.verses)==list(range(1,len(c['verses'])+1))
  assert (D/'data'/f'{slug}-{num}.md').read_text().count(f'### {num}:')==len(c['verses'])
  assert all(f'/{slug}-{n}/' in p.links for n in range(1,len(chapters)+1))
assert pubnt['Acts:15']['source_ranges']=={'25':[25,26]}
assert 'αὐτὸς ἀνακρίνας' in pubnt['Acts:24']['verses'][7]['grc']
assert 'ἀπέλυσεν τὴν ἐκκλησίαν' in pubnt['Acts:19']['verses'][39]['grc']
for c in data['comparisons']:
 if c['lxx_chapter_id']=='psalm-88':
  assert c['verses'][0]['verse_kind']=='superscription'
  assert c['lxx_ot_verse_map']==[{'lxx_verse':n,'ot_verse':n-1} for n in range(2,54)]
 if c['lxx_chapter_id'] in ['ezekiel-2','1samuel-13','jonah-1']:assert c['boundary_notes']
 if c['lxx_chapter_id']=='jonah-1':assert len(c['verses'])==16 and len(c['ot_chapter']['verses'])==17
 if c['lxx_chapter_id']=='daniel-12':assert c['lxx_text_form']=='Old Greek (not Theodotion)'
assert not re.search(r'기존 세 연결|현재 세 연결|사도행전 2장 시제품',(D/'about/index.html').read_text())
assert (D/'catalog/index.html').read_text().count('class="index-row"')==len(CHAPTERS)
with ZipFile(D/'source.zip') as z:
 assert z.testzip() is None
 assert all(not p.endswith('.source') and '.git/' not in p for p in z.namelist())
 for required in ['LICENSE','data/editorial.py','data/expansion.py','data/acts_6_8.py','data/acts_6_8_metadata.py','data/acts_6_8_pairs.py','data/acts_9_28.py','data/acts_9_28_metadata.py','data/acts_9_28_pairs.py','data/about-template.html','scripts/publication.py','data/nt-chapters.json','data/nt-luke.json','data/luke_metadata.py','data/luke_translations.py','data/luke_pairs.py','data/nt-hebrews.json','data/hebrews_translations.py','data/hebrews_metadata.py','data/hebrews_pairs.py','data/hebrews_source_specs.py','scripts/expand_hebrews_sources.py','data/nt-romans.json','data/romans_translations.py','data/romans_metadata.py','data/romans_rows.py','data/romans_notes.py','data/romans_pairs.py','data/romans_source_specs.py','scripts/expand_romans_sources.py','data/nt-1corinthians.json','data/corinthians_translations.py','data/corinthians_metadata.py','data/corinthians_rows.py','data/corinthians_notes.py','data/corinthians_pairs.py','data/corinthians_source_specs.py','scripts/expand_corinthians_sources.py','data/nt-matthew.json','data/matthew_translations.py','data/matthew_metadata.py','data/matthew_rows.py','data/matthew_notes.py','data/matthew_pairs.py','data/matthew_source_specs.py','scripts/expand_matthew_sources.py','data/nt-mark.json','data/mark_translations.py','data/mark_metadata.py','data/mark_rows.py','data/mark_notes.py','data/mark_pairs.py','data/mark_source_specs.py','scripts/expand_mark_sources.py']:
  assert required in z.namelist()
 for name in z.namelist():assert z.read(name)==(R/name).read_bytes(),name
assert {c['nt_chapter'] for c in data['comparisons'] if c['nt_book']=='Luke'}==set(range(1,25))
assert {c['nt_chapter'] for c in data['comparisons'] if c['nt_book']=='Hebrews'}==set(range(1,14))
assert sum(c['nt_book']=='Hebrews' for c in data['comparisons'])==87
for c in data['comparisons']:
 m={n:[x['ot_verse'] for x in c['lxx_ot_verse_map'] if x['lxx_verse']==n] for n in range(1,len(c['verses'])+1)}
 if c['lxx_chapter_id']=='exodus-20':assert [m[n] for n in [13,14,15]]==[[14],[15],[13]]
 if c['lxx_chapter_id']=='malachi-4':assert [m[n] for n in [4,5,6]]==[[5],[6],[4]]
 if c['lxx_chapter_id']=='jeremiah-38':assert [m[n] for n in [35,36,37]]==[[37],[35],[36]]
 if c['lxx_chapter_id']=='1kings-10':assert all(not m[n] for n in [23,24,25,30])
 if c['lxx_chapter_id']=='daniel-7':assert c['lxx_text_form']=='Old Greek (not Theodotion)'
 if c['lxx_chapter_id']=='exodus-25':assert [m[n] for n in [6,23,24,25,26,35,40]]==[[7],[24,25],[25],[26,27],[27],[34],[40]]
 if c['lxx_chapter_id']=='psalm-94':assert [m[n] for n in [7,8,9]]==[[7],[7,8],[9]]
 if c['lxx_chapter_id']=='psalm-44':assert m[13]==[11,12]
 if c['lxx_chapter_id']=='genesis-47':assert m[5]==[5,6]
 if c['lxx_chapter_id'] in ['genesis-2','genesis-5','genesis-6','numbers-12','hosea-14','isaiah-8','haggai-2']:assert c['boundary_notes']
 if c['lxx_chapter_id']=='psalm-39':assert 'σῶμα' in c['verses'][6]['grc'] and '몸' in c['verses'][6]['ko']
 if c['id']=='hb8-pattern':assert c['lxx_selected_verses']==[40]
 if c['id']=='lk20-right-hand':
  seat=next(x for x in c['pairs'] if x['id']=='lk20-right-hand-p2');assert seat['nt']['ko_verse']==43 and seat['nt']['grc_verse']==42
assert pubnt['Luke:20']['verse_map_note']
assert pubnt['Hebrews:3']['verse_map_note']
assert 'τεσσεράκοντα ἔτη' in pubnt['Hebrews:3']['verses'][9]['grc']
assert '사십년' in pubnt['Hebrews:3']['verses'][8]['ko']
# Romans edition differences and chapter mappings.
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='Romans']==[32,29,31,25,21,23,25,39,33,21,36,21,14,23,33,27]
romans=[c for c in data['comparisons'] if c['nt_book']=='Romans']
assert len(romans)==115 and sum(len(c['pairs']) for c in romans)==156
assert {c['nt_chapter'] for c in romans}==set(range(1,17))-{6,16}
assert pubnt['Romans:9']['source_ranges']=={'1':[1,2]}
assert pubnt['Romans:9']['verses'][1]['ko_status']=='content_in_1'
assert pubnt['Romans:16']['verses'][23]['ko_status']=='absent_in_KRV'
assert 'Ἡ χάρις' in pubnt['Romans:16']['verses'][23]['grc']
assert all(v['ko'] and not v['grc'] and v['grc_status']=='absent_in_SBLGNT' for v in pubnt['Romans:16']['verses'][24:])
assert pubnt['Romans:16']['verse_map_note']
assert 'SBLGNT도 이 절의 문장을 싣지 않습니다.' not in (D/'romans-16/index.html').read_text()
for c in romans:
 m={n:[x['ot_verse'] for x in c['lxx_ot_verse_map'] if x['lxx_verse']==n] for n in range(1,len(c['verses'])+1)}
 if c['lxx_chapter_id']=='psalm-50':
  assert [v['verse'] for v in c['verses'] if v['verse_kind']=='superscription']==[1,2]
  assert [m[n] for n in [1,2,6]]==[[],[],[4]]
 if c['lxx_chapter_id']=='psalm-9':assert all(not m[n] for n in range(1,22)) and m[28]==[7] and m[39]==[18]
 if c['lxx_chapter_id']=='psalm-115':assert m[2]==[11] and m[10]==[19]
 if c['lxx_chapter_id']=='job-41':assert m[1]==[9,10] and m[2]==[10,11] and m[25]==[34]
 if c['id']=='rm10-call':assert m[5]==[32]
 if c['id']=='rm11-reject':assert c['lxx_selected_verses']==[35] and m[35]==[37]
 if c['lxx_chapter_id'] in ['genesis-3','psalm-9','psalm-115','job-41']:assert c['boundary_notes']
home=(D/'index.html').read_text()
assert '인용을, 장의 문맥 안에서.' not in ''.join(f.read_text() for f in D.rglob('*.html'))
initial=[c for c in data['comparisons'] if c['nt_book']=='Matthew' and c['nt_chapter']==1]
assert home.count('class="index-row"')==len(initial)
home_chunks=[json.loads(f.read_text()) for f in (D/'data/home').glob('*.json')]
home_urls=[row['url'] for chunk in home_chunks for row in chunk['rows']]
assert sorted(home_urls)==sorted(c['url'] for c in data['comparisons'])
assert len(home.encode())<80000
assert 'class="home-book-picker"' in home
assert home.count('data-home-book=')==27
for chunk in home_chunks:
 assert f'id="{chunk["id"]}"' in home
 assert all((D/row['url'].strip('/')/'index.html').exists() for row in chunk['rows'])
for c in data['comparisons']:
 assert all(note['text'].strip() for note in c['notes'])
 for note in c['notes']:
  for removed in ['이 낱말 하나로 후대 교회 직제','이 대조만으로','확정하지 않습니다','단정하지 않습니다','전제하지 않습니다','고치지 않았습니다','바꾸지 않았습니다']:
   assert removed not in note['text'],(c['id'],removed)
assert all(f'id="{b}"' in home for b in ['matthew','mark','luke','acts','romans','1corinthians','hebrews']) and '{{' not in (D/'about/index.html').read_text()
# 1 Corinthians: edition identity, combined OT contexts and selected indices.
corinthians=[c for c in data['comparisons'] if c['nt_book']=='1Corinthians']
assert len(corinthians)==100 and sum(len(c['pairs']) for c in corinthians)==116
assert {c['nt_chapter'] for c in corinthians}==set(range(1,17))-{7}
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='1Corinthians']==[31,16,23,21,13,20,40,13,27,33,34,31,13,40,58,24]
assert all(v['ko'] and v['grc'] for c in data['nt_chapters'] if c['book']=='1Corinthians' for v in c['verses'])
assert pubnt['1Corinthians:14']['verse_map_note']
assert 'ὡς ἐν πάσαις ταῖς ἐκκλησίαις τῶν ἁγίων' in pubnt['1Corinthians:14']['verses'][32]['grc']
for c in corinthians:
 m={n:[x['ot_verse'] for x in c['lxx_ot_verse_map'] if x['lxx_verse']==n] for n in range(1,len(c['verses'])+1)}
 if c['lxx_chapter_id']=='leviticus-6':assert m[36]==[36] and c['ot_chapter']['verse_refs']['36']=='7:6'
 if c['lxx_chapter_id']=='leviticus-7':assert m[5]==[45] and c['ot_chapter']['verse_refs']['45']=='7:15' and c['ot_chapter_id']=='leviticus-6'
 if c['lxx_chapter_id']=='psalm-113':assert m[13]==[13] and c['ot_chapter']['verse_refs']['13']=='115:5'
 if c['lxx_chapter_id'] in ['leviticus-6','leviticus-7','psalm-113']:
  raw=c['ot_chapter']['source_chapters'];assert len(raw)==2
  assert len(c['ot_chapter']['verses'])==sum(len(x['verses']) for x in raw)
  assert c['ot_chapter']['source_hash_note']
  page=(D/c['url'].strip('/')/'index.html').read_text()
  assert all('version=GAE&amp;book='+x['book']+'&amp;chap='+str(x['chapter'])+'"' in page for x in raw)
 if c['lxx_chapter_id']=='numbers-16':assert m[37]==[37,38]
 if c['lxx_chapter_id']=='hosea-13':assert len(c['verses'])==15 and len(c['ot_chapter']['verses'])==16 and c['boundary_notes']
 if c['lxx_chapter_id']=='daniel-2':assert c['lxx_text_form']=='Old Greek (not Theodotion)'
 if c['id']=='c1-boast':assert c['lxx_selected_verses']==[23,24]
 if c['id']=='c2-unseen':assert c['lxx_selected_verses']==[4]
 if c['id']=='c13-face':assert c['lxx_selected_verses']==[30]
 if c['id']=='c15-victory':assert '죽음이 힘을 떨치며 삼켰다' in c['verses'][7]['ko']
assert 'id="1corinthians-7"' not in home
# Matthew: publisher-verified chapter lengths and new edition boundaries.
from matthew_source_specs import NT_COUNTS
matthew=[c for c in data['comparisons'] if c['nt_book']=='Matthew']
assert len(matthew)==144 and sum(len(c['pairs']) for c in matthew)==187
assert {c['nt_chapter'] for c in matthew}==set(range(1,29))
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='Matthew']==NT_COUNTS
for ch,v in [(17,21),(18,11),(23,14)]:
 assert pubnt[f'Matthew:{ch}']['verses'][v-1]['ko']=='(없음)'
 assert pubnt[f'Matthew:{ch}']['verses'][v-1]['grc_status']=='absent_in_SBLGNT'
for c in matthew:
 m={n:[x['ot_verse'] for x in c['lxx_ot_verse_map'] if x['lxx_verse']==n] for n in range(1,len(c['verses'])+1)}
 if c['lxx_chapter_id']=='exodus-21':assert m[16]==[17] and m[17]==[16]
 if c['lxx_chapter_id'] in ['psalm-41','psalm-47']:
  assert c['verses'][0]['verse_kind']=='superscription' and m[1]==[]
  assert all(m[n]==[n-1] for n in range(2,len(c['verses'])+1))
 if c['lxx_chapter_id']=='jonah-2':
  assert len(c['verses'])==11 and len(c['ot_chapter']['verses'])==27
  assert m[1]==[17] and m[11]==[27]
  assert c['ot_chapter']['verse_refs']['17']=='1:17' and c['ot_chapter']['verse_refs']['27']=='2:10'
 if c['lxx_chapter_id'] in ['daniel-9','daniel-11']:assert c['lxx_text_form']=='Old Greek (not Theodotion)'
 if c['lxx_chapter_id']=='micah-5':assert c['boundary_notes'] and m[2]==[2]
 if c['lxx_chapter_id']=='isaiah-9':assert m[14]==[14,15]
 if c['lxx_chapter_id']=='jeremiah-6':assert m[7]==[7,8]
 if c['lxx_chapter_id']=='daniel-9':assert m[26]==[25,26] and m[27]==[25,27]
unique_ot={(c['book'],c['chapter']):c for ctx in ot.values() for c in ctx.get('source_chapters',[ctx])}
assert len(unique_ot)==data['scope']['ot_chapters']
assert sum(len(c['verses']) for c in unique_ot.values())==data['scope']['ot_verses']
# Mark: edition differences, selected ranges and new chapter mappings.
from mark_source_specs import NT_COUNTS as MARK_COUNTS, SELECTIONS as MARK_LXX
mark=[c for c in data['comparisons'] if c['nt_book']=='Mark']
assert len(mark)==108 and sum(len(c['pairs']) for c in mark)==132
assert {c['nt_chapter'] for c in mark}==set(range(1,17))
assert [len(c['verses']) for c in data['nt_chapters'] if c['book']=='Mark']==MARK_COUNTS
for ch,v in [(9,44),(9,46),(11,26),(15,28)]:
 assert pubnt[f'Mark:{ch}']['verses'][v-1]['ko']=='(없음)'
 assert pubnt[f'Mark:{ch}']['verses'][v-1]['grc_status']=='absent_in_SBLGNT'
assert sum(len(unique[key]) for key in MARK_LXX)==287
assert pubnt['Mark:7']['verses'][15]['ko'].startswith('사람 안에서')
assert pubnt['Mark:7']['verses'][15]['grc_status']=='verse_number_absent_content_in_15'
assert 'ἀλλὰ τὰ ἐκ τοῦ ἀνθρώπου ἐκπορευόμενά' in pubnt['Mark:7']['verses'][14]['grc']
assert pubnt['Mark:7']['verse_map_note']
assert pubnt['Mark:10']['verse_map_note']
assert 'προσκολληθήσεται' in pubnt['Mark:10']['verses'][6]['grc']
assert pubnt['Mark:16']['verse_map_note']
assert pubnt['Mark:16']['verses'][7]['grc_status']=='present_with_bracketed_shorter_ending'
assert '⟦' in pubnt['Mark:16']['verses'][7]['grc'] and '⟧' in pubnt['Mark:16']['verses'][7]['grc']
assert all(v['grc_status']=='present_in_double_brackets' for v in pubnt['Mark:16']['verses'][8:])
for c in mark:
 m={n:[x['ot_verse'] for x in c['lxx_ot_verse_map'] if x['lxx_verse']==n] for n in range(1,len(c['verses'])+1)}
 assert all(pubnt[f'Mark:{c["nt_chapter"]}']['verses'][n-1]['ko']!='(없음)' for n in c['nt_selected_verses'])
 if c['lxx_chapter_id']=='psalm-40':
  assert c['verses'][0]['verse_kind']=='superscription' and m[1]==[] and m[10]==[9]
 if c['lxx_chapter_id']=='joel-4':
  assert c['ot_chapter']['chapter']==3 and c['verses'][12]['source_ref']=='Joe.3:13'
 if c['lxx_chapter_id']=='ezekiel-12':assert m[5]==[4,5] and c['boundary_notes']
 if c['lxx_chapter_id']=='2kings-1':assert c['boundary_notes']
 page=(D/c['url'].strip('/')/'index.html').read_text()
 assert 'id="reader-ot" type="checkbox"' in page
 assert 'id="reader-ot-excerpts" class="reader-disclosure"' in page
 assert 'id="full-context"' in page and 'id="context-ot"' in page
 for removed in ['목록 근거','NA28 확인 대기','NA27 전사본 선정','이 대조의 텍스트']:
  assert removed not in page
assert list(books)==list(BOOKS) and len(books)==27
print('PASS:',data['scope'],str(len(pages))+' static pages; local links, exact phrase spans, Markdown, edition boundaries and source archive verified.')
