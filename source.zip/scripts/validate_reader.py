"""Verify static reading content independently of the browser controller."""
import json
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1] / 'dist'
with ZipFile(root / 'data/reader.zip') as archive:
    data = json.loads(archive.read('reader.json'))
chapters = {(c['book'], c['chapter']): c for c in data['nt_chapters']}


class Reader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.verses = {}
        self.current = None
        self.capture = None
        self.paragraph = None
        self.paragraphs = []
        self.paragraph_in_verse = False
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids
            self.ids.add(attrs['id'])
        if tag == 'article':
            self.current = attrs.get('id')
            self.verses[self.current] = {}
        if tag == 'p':
            self.paragraph = ''
            self.paragraph_in_verse = self.current is not None
            if self.current:
                for field in ['ko', 'greek']:
                    if 'reader-' + field in attrs.get('class', '').split():
                        self.capture = field
                        self.verses[self.current][field] = ''

    def handle_data(self, text):
        if self.paragraph is not None:
            self.paragraph += text
        if self.capture:
            self.verses[self.current][self.capture] += text

    def handle_endtag(self, tag):
        if tag == 'p':
            self.capture = None
            if self.paragraph is not None and not self.paragraph_in_verse:
                self.paragraphs.append(self.paragraph)
            self.paragraph = None
        if tag == 'article':
            self.current = None


for comparison in data['comparisons']:
    path = root / comparison['url'].strip('/') / 'index.html'
    html = path.read_text()
    parsed = Reader()
    parsed.feed(html)
    full = {'nt': chapters[(comparison['nt_book'], comparison['nt_chapter'])]['verses'],
            'lxx': comparison['verses'], 'ot': comparison['ot_chapter']['verses']}
    for side, rows in full.items():
        for row in rows:
            actual = parsed.verses[f'{side}-{row["verse"]}']
            if row['ko']:
                assert actual['ko'] == row['ko'], (path, side, row['verse'])
            if row.get('grc'):
                assert actual['greek'] == row['grc'], (path, side, row['verse'])
        if side in ['nt', 'lxx']:
            expected = set(comparison[side + '_selected_verses'])
            for pair in comparison['pairs']:
                expected.update([pair[side]['ko_verse'], pair[side]['grc_verse']])
            displayed = {int(key.rsplit('-', 1)[1]) for key in parsed.verses if key.startswith('quote-' + side + '-')}
            assert displayed == expected, (path, side, displayed, expected)
            for n in displayed:
                row = rows[n - 1]
                actual = parsed.verses[f'quote-{side}-{n}']
                if row['ko']:
                    assert actual['ko'] == row['ko'], (path, side, n, 'excerpt')
                if row.get('grc'):
                    assert actual['greek'] == row['grc'], (path, side, n, 'excerpt')
    paragraphs = Counter(parsed.paragraphs)
    notes = {note['text'] for note in comparison['notes']}
    notes.update(note['text'] for group in comparison['verse_comparisons'] for note in group['notes'])
    for note in notes:
        assert paragraphs[note] == 1, (path, note[:70], paragraphs[note])
    assert 'reader-copy' in parsed.ids and 'reader-share' in parsed.ids and 'full-context' in parsed.ids
    assert 'Powered by 미셔널신학연구소' in html and 'https://imt.or.kr/' in html
print(f'PASS: {len(data["comparisons"])} detail pages; complete chapters and selected verses; Greek and Korean text; unique notes; institutional credit.')
