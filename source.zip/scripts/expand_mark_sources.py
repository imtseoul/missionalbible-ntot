"""Acquire Mark and selected Swete/KRV OT chapters; preserve edition boundaries."""
import concurrent.futures,hashlib,json,re,sys,unicodedata,urllib.request
from pathlib import Path
from expand_sources import fetch_chapter
R=Path(__file__).resolve().parents[1];D=R/'data';sys.path.insert(0,str(D))
from mark_source_specs import SELECTIONS,NT_COUNTS,EXTRA_OT

def verify_official(nt):
 url='https://raw.githubusercontent.com/Faithlife/SBLGNT/master/data/sblgnt/text/Mark.txt'
 cache=D/'sbl-mark-official.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(url,timeout=60).read())
 def lexical(s):return ''.join(c.lower() for c in unicodedata.normalize('NFD',s) if unicodedata.category(c) in ['Lu','Ll'])
 official={}
 for line in cache.read_text(encoding='utf-8-sig').splitlines():
  match=re.match(r'Mark (\d+):(\d+)\s+(.*)',line)
  if match:official[match[1],match[2]]=lexical(match[3])
 extracted={(ch,n):lexical(v) for ch,c in nt.items() for n,v in c['grc'].items() if v}
 assert official==extracted,'Mark differs lexically from the publisher SBLGNT text'
 print('Publisher SBLGNT lexical check:',len(official),'verses',flush=True)
 return dict(file=cache.name,url=url,sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),note='Mark MorphGNT lexical cross-check against the publisher SBLGNT text.')

def main():
 sbl_url='https://raw.githubusercontent.com/morphgnt/sblgnt/master/62-Mk-morphgnt.txt'
 cache=D/'sbl-mark.source'
 if not cache.exists():cache.write_bytes(urllib.request.urlopen(sbl_url,timeout=60).read())
 raw=cache.read_bytes()
 text=json.loads((D/'texts.json').read_text());ot=json.loads((D/'krv-ot.json').read_text());prov=json.loads((D/'provenance.json').read_text())
 nt={}
 jobs=[(f'mark-{ch}','mrk',ch,f'마가복음 {ch}장',count) for ch,count in enumerate(NT_COUNTS,1)]
 jobs += [(key,book,ch,title,count) for key,(_,book,ch,title,count) in SELECTIONS.items()] + EXTRA_OT
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for key,result in pool.map(fetch_chapter,jobs):
   print(key,len(result['verses']),flush=True)
   if key.startswith('mark-'):nt[key.split('-')[1]]=result
   else:ot[key]=result
 for c in nt.values():c['grc']={}
 for line in raw.decode().splitlines():
  a=line.split();ch=str(int(a[0][2:4]));vn=str(int(a[0][4:6]));w=unicodedata.normalize('NFC',re.sub('[⸀-⸇]','',a[3]));g=nt[ch]['grc'];g[vn]=(g.get(vn,'')+' '+w).strip()
 for ch,c in nt.items():
  missing=set(c['verses'])-set(c['grc']);print('NT boundary',ch,sorted(missing),c['source_ranges'],flush=True)
  c['grc_status']={n:'absent_in_SBLGNT' for n in missing}
  c['grc']={n:c['grc'].get(n,'') for n in c['verses']}
 words={int(n):unicodedata.normalize('NFC',w) for n,w in (line.split('\t',1) for line in (D/'swete.source').read_text().splitlines())}
 bounds=[(int(n),ref) for n,ref in (line.split('\t',1) for line in (D/'swete-verses.source').read_text().splitlines())]
 prefixes={v[0]+':' for v in SELECTIONS.values()}
 for (start,ref),(end,_) in zip(bounds,bounds[1:]):
  if any(ref.startswith(p) for p in prefixes):text['lxx'][ref]=re.sub(r'\s+',' ',re.sub('[⸀-⸇]','',' '.join(words[i] for i in range(start,end)))).strip()
 nt['7']['verse_map_note']='개역한글 7:16의 “사람 안에서 나오는 것이…”는 SBLGNT 7:15 뒷부분에 있습니다. 절 구분의 차이입니다.'
 nt['7']['grc_status']['16']='verse_number_absent_content_in_15'
 nt['10']['verse_map_note']='7절 SBLGNT에는 “자기 아내와 결합하여”라는 말이 있으며, 개역한글 7절에는 이 구절이 없습니다.'
 nt['16']['verse_map_note']='SBLGNT는 16:8 뒤의 짧은 결말과 16:9–20의 긴 결말을 이중 대괄호로 표시합니다. 8절 헬라어의 ⟦…⟧는 개역한글에 없는 짧은 결말입니다.'
 nt['16']['grc_status'].update({'8':'present_with_bracketed_shorter_ending',**{str(n):'present_in_double_brackets' for n in range(9,21)}})
 known={(p['url'],p['sha256']) for p in prov}
 records=[dict(file='sbl-mark.source',url=sbl_url,sha256=hashlib.sha256(raw).hexdigest()),verify_official(nt)]
 for c in [*nt.values(),*[o for o in ot.values() if not o.get('source_chapters')]]:records.append(dict(file=f'krv-{c["book"]}-{c["chapter"]}.source',url=c['source_url'],sha256=c['sha256']))
 for p in records:
  if (p['url'],p['sha256']) not in known:prov.append(p);known.add((p['url'],p['sha256']))
 for name,obj in [('nt-mark.json',nt),('texts.json',text),('krv-ot.json',ot),('provenance.json',prov)]: (D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 for slug,(prefix,*_) in SELECTIONS.items():
  rows=[(k,v) for k,v in text['lxx'].items() if k.startswith(prefix+':')];print(slug,len(rows),[k for k,v in rows if not v],flush=True)
if __name__=='__main__':main()
