"""Prepare the validated static publication for a Webflow mount path."""
import argparse
import hashlib
import io
import json
import re
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
LIMIT = 20_000_000
ATTR = re.compile(r'''(\b(?:href|src|data-source)=["'])(/(?!/)[^"']*)''')
MD_LINK = re.compile(r'(\]\()(/(?!/)[^\s)]*)')

CREDIT_CSS = '''footer { flex-wrap: wrap; }
footer .imt-credit { display: flex; flex-basis: 100%; align-items: center; width: fit-content; min-height: 32px; margin: 8px 0 0; color: inherit; font: 500 12px/1.5 system-ui, sans-serif; text-decoration: none; }
footer .imt-credit:hover { text-decoration: underline; text-underline-offset: 3px; }
footer .imt-credit:focus-visible { outline: 2px solid currentColor; outline-offset: 3px; }
'''


def add_institute_credit(content, mount):
    if 'class="imt-credit"' in content:
        return content
    credit = '<a class="imt-credit" href="https://imt.or.kr/" target="_blank" rel="noopener noreferrer">Powered by 미셔널신학연구소</a>'
    content = content.replace('</footer>', credit + '</footer>')
    return content.replace('</head>', f'<link rel="stylesheet" href="{mount}assets/imt-credit.css"></head>', 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mount-path', default='/')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--move-build', action='store_true', help='Move a disposable validated build instead of copying it.')
    args = parser.parse_args()
    mount = '/' + args.mount_path.strip('/') + '/' if args.mount_path.strip('/') else '/'
    if not re.fullmatch(r'/(?:[a-zA-Z0-9_-]+/)*', mount):
        parser.error('Mount path must contain only path segments made of letters, digits, _ or -.')
    out = args.output.resolve()
    if out.exists():
        parser.error('Output directory already exists; choose a new directory.')
    source = ROOT / 'dist'
    if args.move_build:
        shutil.move(source, out)
    else:
        shutil.copytree(source, out)

    def url(value):
        return mount + value[1:] if value.startswith('/') and not value.startswith('//') else value

    def markup(value):
        return ATTR.sub(lambda m: m[1] + url(m[2]), value)

    def markdown(value):
        value = MD_LINK.sub(lambda m: m[1] + url(m[2]), value)
        # Plain paths in the machine-readable guide and Markdown footer.
        return re.sub(r'(?<![\w/:])/(?:data/|about/|catalog/|source\.zip|책슬러그-N/)',
                      lambda m: url(m[0]), value) if mount != '/' else value

    def data(value):
        if isinstance(value, dict):
            return {k: data(v) for k, v in value.items()}
        if isinstance(value, list):
            return [data(v) for v in value]
        if isinstance(value, str):
            return markup(url(value))
        return value

    navigation = (out / 'assets/navigation.js').read_text()
    navigation = navigation.replace("  const route=", "  const basePath=document.querySelector('meta[name=\"site-base\"]').content;\n  const route=", 1)
    navigation = navigation.replace('route.test(url.pathname)', "url.pathname.startsWith(basePath) && route.test('/'+url.pathname.slice(basePath.length))")
    (out / 'assets/navigation.js').write_text(navigation)
    version = hashlib.sha256((navigation + mount).encode()).hexdigest()[:12]
    for path in out.rglob('*'):
        if not path.is_file():
            continue
        if path.suffix == '.html':
            content = markup(path.read_text())
            content = content.replace('<head>', f'<head><meta name="site-base" content="{mount}">', 1)
            content = re.sub(r'(name="site-version" content="[^"]+)', lambda m: m[1] + '-' + version, content)
            content = re.sub(r'(navigation\.js\?v=)[a-f0-9]+', lambda m: m[1] + version, content)
            path.write_text(add_institute_credit(content, mount))
        elif path.suffix == '.json':
            path.write_text(json.dumps(data(json.loads(path.read_text())), ensure_ascii=False, indent=2) + '\n')
        elif path.suffix == '.md' or path.name == 'llms.txt':
            path.write_text(markdown(path.read_text()))

    # Retain complete downloadable data, including mount-aware comparison URLs.
    archive_path = out / 'data/reader.zip'
    payload = io.BytesIO()
    with ZipFile(archive_path) as original, ZipFile(payload, 'w', ZIP_DEFLATED) as archive:
        for name in original.namelist():
            raw = original.read(name)
            if name.endswith('.json'):
                raw = (json.dumps(data(json.loads(raw)), ensure_ascii=False, indent=2) + '\n').encode()
            elif name.endswith('.md'):
                raw = markdown(raw.decode()).encode()
            archive.writestr(name, raw)
    archive_path.write_bytes(payload.getvalue())

    # Split on line boundaries and prove concatenation preserves the full document.
    reader = out / 'data/reader.md'
    complete = reader.read_bytes()
    parts = []
    chunk = bytearray()
    for line in complete.splitlines(keepends=True):
        if len(chunk) + len(line) > 8_000_000 and chunk:
            parts.append(bytes(chunk))
            chunk.clear()
        chunk.extend(line)
    if chunk:
        parts.append(bytes(chunk))
    assert b''.join(parts) == complete
    part_dir = out / 'data/markdown'
    part_dir.mkdir()
    links = []
    for number, content in enumerate(parts, 1):
        name = f'part-{number:02d}.md'
        (part_dir / name).write_bytes(content)
        links.append(f'- [{number}부]({mount}data/markdown/{name})')
    reader.write_text('# 신약의 구약 사용: 전체 텍스트\n\n'
                      '아래 파일을 순서대로 읽으면 전체 본문입니다.\n\n' + '\n'.join(links)
                      + f'\n\n[전체 JSON과 Markdown 다운로드]({mount}data/reader.zip)\n')

    manifest_path = out / 'data/reader.json'
    manifest = json.loads(manifest_path.read_text())
    for entry in manifest['books']:
        entry['sha256'] = hashlib.sha256((out / entry['url'][len(mount):]).read_bytes()).hexdigest()
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    (out / 'webflow.json').write_text('{"cloud":{"framework":"static"}}\n')
    (out / '.gitignore').write_text('.env\n.env.*\n.tmp/\nnode_modules/\n.DS_Store\n')
    (out / 'assets/imt-credit.css').write_text(CREDIT_CSS)
    files = [p for p in out.rglob('*') if p.is_file()]
    oversized = [str(p.relative_to(out)) for p in files if p.stat().st_size > LIMIT]
    assert not oversized, oversized
    print(json.dumps({'mount_path': mount, 'files': len(files), 'markdown_parts': len(parts),
                      'largest_file_bytes': max(p.stat().st_size for p in files)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
