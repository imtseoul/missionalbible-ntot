from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
R=Path(__file__).resolve().parents[1]
files=[R/'README.md',R/'LICENSE',R/'AGENTS.md']
for folder in ['scripts','assets','data']:
    files += [p for p in (R/folder).rglob('*') if p.is_file() and p.suffix in ['.py','.json','.css','.js','.svg','.html'] and '__pycache__' not in str(p) and p.name!='prepare.py']
with ZipFile(R/'dist/source.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p,p.relative_to(R))
print('Source archive written with',len(files),'files.')
