"""Build, review, and publish the reader to its GitHub Pages repository."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile
from validate_pages import ORIGIN, PARENT, public_path, route, validate

SOURCE = Path(__file__).resolve().parents[1]
DEVELOPMENT = SOURCE.parent if SOURCE.name == '.source' else SOURCE
STATE = DEVELOPMENT / '.github/ntot-pages-state.json'
REPOSITORY = 'imtseoul/missionalbible-ntot'
PROTECTED = ['CNAME', '.nojekyll', 'robots.txt', 'README.md', 'sitemap.xml']
PARENT_STYLE = '.mb-parent-link{display:inline-block;margin:12px 0;padding:8px 0;color:inherit;font-size:13px;line-height:1.5}'


def run(args, cwd=None, quiet=False):
    result = subprocess.run([str(arg) for arg in args], cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        message = result.stderr.strip() or result.stdout.strip() or str(args)
        if len(message) > 6000:
            message = message[:1000] + '\n...\n' + message[-4000:]
        raise RuntimeError(message)
    if not quiet and result.stdout.strip():
        print(result.stdout.strip(), flush=True)
    return result.stdout.strip()


def git(repo, *args):
    return run(['git', '-C', repo, *args], quiet=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def state():
    return json.loads(STATE.read_text()) if STATE.exists() else {}


def identity(repo):
    values = []
    for key in ['user.name', 'user.email']:
        value = ''
        for directory in [repo, DEVELOPMENT]:
            result = subprocess.run(['git', '-C', str(directory), 'config', '--get', key], text=True, capture_output=True)
            if result.returncode == 0 and result.stdout.strip():
                value = result.stdout.strip()
                break
        if not value:
            raise RuntimeError('Configure Git ' + key + ' before publication.')
        values.extend(['-c', key + '=' + value])
    return values


def target_head(repo, require_clean=False):
    remote = git(repo, 'remote', 'get-url', 'origin').removesuffix('.git')
    if remote not in {f'https://github.com/{REPOSITORY}', f'git@github.com:{REPOSITORY}'}:
        raise RuntimeError('The deployment checkout has an unexpected origin.')
    if git(repo, 'branch', '--show-current') != 'main':
        raise RuntimeError('The deployment checkout must be on main.')
    if require_clean and git(repo, 'status', '--porcelain'):
        raise RuntimeError('Deployment checkout has uncommitted changes; they were left untouched.')
    git(repo, 'fetch', 'origin', 'main')
    head, remote_head = git(repo, 'rev-parse', 'HEAD'), git(repo, 'rev-parse', 'origin/main')
    if head != remote_head:
        raise RuntimeError('Deployment HEAD differs from origin/main. Review and fast-forward separately; no files were overwritten.')
    return head


def same_archive(a, b):
    if not a.exists() or not b.exists():
        return False
    with ZipFile(a) as left, ZipFile(b) as right:
        return left.namelist() == right.namelist() and all(left.read(name) == right.read(name) for name in left.namelist())


def add_site_settings(output, repo):
    urls = []
    for path in sorted(output.rglob('*.html')):
        canonical = ORIGIN + route(path.relative_to(output).as_posix())
        text = re.sub(r'<link\b(?=[^>]*\brel=["\']canonical["\'])[^>]*>', '', path.read_text(), flags=re.I)
        text = text.replace('</head>', f'<link rel="canonical" href="{canonical}"></head>', 1)
        if 'class="mb-parent-link"' not in text:
            text = text.replace('</footer>', f'<a class="mb-parent-link" href="{PARENT}">미셔널 바이블</a></footer>', 1)
            text = text.replace('</head>', f'<style>{PARENT_STYLE}</style></head>', 1)
        path.write_text(text)
        if path.name != '404.html':
            urls.append(canonical)
    for name in ['CNAME', '.nojekyll', 'robots.txt', 'README.md']:
        if not (repo / name).is_file():
            raise RuntimeError(f'Missing protected deployment file: {name}')
        shutil.copyfile(repo / name, output / name)
    sitemap = repo / 'sitemap.xml'
    tree = ET.parse(sitemap)
    ns = '{http://www.sitemaps.org/schemas/sitemap/0.9}'
    existing = {node.find(ns + 'loc').text: node for node in tree.getroot().findall(ns + 'url')}
    if set(existing) == set(urls):
        shutil.copyfile(sitemap, output / 'sitemap.xml')
    else:
        ET.register_namespace('', ns[1:-1])
        element = ET.Element(ns + 'urlset')
        for url in urls:
            node = existing.get(url)
            if node is None:
                node = ET.Element(ns + 'url')
                ET.SubElement(node, ns + 'loc').text = url
            element.append(node)
        ET.ElementTree(element).write(output / 'sitemap.xml', encoding='utf-8', xml_declaration=True)
    for name in ['data/reader.zip', 'source.zip']:
        if same_archive(repo / name, output / name):
            shutil.copyfile(repo / name, output / name)
    previous_parts = sorted((repo / 'data/markdown').glob('*.md'))
    with ZipFile(output / 'data/reader.zip') as archive:
        full_markdown = archive.read('reader.md')
    if previous_parts and b''.join(p.read_bytes() for p in previous_parts) == full_markdown:
        if [p.name for p in previous_parts] == [p.name for p in sorted((output / 'data/markdown').glob('*.md'))]:
            for path in previous_parts:
                shutil.copyfile(path, output / 'data/markdown' / path.name)


def make_plan(output, repo, head, checks):
    files = {p.relative_to(output).as_posix(): digest(p) for p in sorted(output.rglob('*')) if p.is_file()}
    prior = state()
    managed = set(prior.get('managed_paths', []))
    changes = {'added': [], 'changed': [], 'removed': []}
    for rel, sha in files.items():
        path = repo / rel
        if not path.exists():
            changes['added'].append(rel)
        elif digest(path) != sha:
            changes['changed'].append(rel)
    changes['removed'] = sorted(rel for rel in managed - files.keys() if (repo / rel).exists() and public_path(rel))
    report = {'repository': REPOSITORY, 'origin': ORIGIN, 'target_head': head,
              'baseline_head': prior.get('deployment_commit'), 'checks': checks,
              'protected_hashes': {name: digest(repo / name) for name in PROTECTED},
              'files': files, 'changes': changes}
    write_json(output.with_suffix('.plan.json'), report)
    print(json.dumps({'checks': checks, 'changes': {key: len(value) for key, value in changes.items()},
                      'target_head': head, 'plan': str(output.with_suffix('.plan.json'))}, ensure_ascii=False), flush=True)
    return report


def build(output, repo, python):
    if output.exists():
        raise RuntimeError('Output already exists. Choose a fresh staging directory.')
    head = target_head(repo)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.ntot-build-', dir=output.parent) as temp:
        workspace = Path(temp) / 'source'
        workspace.mkdir()
        for name in ['README.md', 'LICENSE', 'AGENTS.md']:
            if (SOURCE / name).is_symlink():
                raise RuntimeError('Source symlinks are not included in the build.')
            shutil.copyfile(SOURCE / name, workspace / name)
        for name in ['scripts', 'assets', 'data']:
            directory = SOURCE / name
            for path in directory.rglob('*'):
                if path.is_symlink():
                    raise RuntimeError('Source symlinks are not included in the build.')
            shutil.copytree(directory, workspace / name, ignore=shutil.ignore_patterns('__pycache__', '.*', '*.pyc'))
        for script in ['build.py', 'source_archive.py', 'validate.py', 'validate_reader.py']:
            run([python, workspace / 'scripts' / script], cwd=workspace)
        run([python, workspace / 'scripts/prepare_webflow.py', '--mount-path', '/', '--output', output, '--move-build'], cwd=workspace)
    for name in ['webflow.json', '.gitignore']:
        (output / name).unlink(missing_ok=True)
    add_site_settings(output, repo)
    checks = validate(output)
    return make_plan(output, repo, head, checks)


def publish(output, repo, reviewed_head=None):
    report = json.loads(output.with_suffix('.plan.json').read_text())
    if report['repository'] != REPOSITORY or report['origin'] != ORIGIN:
        raise RuntimeError('Prepared artifact targets a different repository or origin.')
    head = target_head(repo, require_clean=True)
    if head != report['target_head']:
        raise RuntimeError('Remote changed after preparation. Review it and build a new staging directory.')
    if head != report['baseline_head'] and reviewed_head != head:
        raise RuntimeError('Remote changed since the last recorded publication. Review it before passing --reviewed-head with the exact commit.')
    for name, sha in report['protected_hashes'].items():
        if digest(repo / name) != sha:
            raise RuntimeError('A protected deployment file changed: ' + name)
    actual = {p.relative_to(output).as_posix(): digest(p) for p in output.rglob('*') if p.is_file()}
    if actual != report['files']:
        raise RuntimeError('Prepared files changed after verification. Build a fresh artifact.')
    validate(output)
    author = identity(repo) if any(report['changes'].values()) else []
    for rel in report['changes']['added'] + report['changes']['changed']:
        path = repo / rel
        if not public_path(rel):
            raise RuntimeError('Refusing a non-public path: ' + rel)
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(output / rel, path)
    for rel in report['changes']['removed']:
        if not public_path(rel) or rel not in state().get('managed_paths', []):
            raise RuntimeError('Refusing to remove an unmanaged path: ' + rel)
        (repo / rel).unlink()
    changed = report['changes']['added'] + report['changes']['changed'] + report['changes']['removed']
    if changed:
        # Stage only reviewed publication paths, including reviewed removals.
        for start in range(0, len(changed), 100):
            git(repo, 'add', '--', *changed[start:start + 100])
        git(repo, *author, 'commit', '-m', 'Publish NT/OT reader from the maintained source')
        git(repo, 'push', 'origin', 'HEAD:main')
    published = git(repo, 'rev-parse', 'HEAD')
    write_json(STATE, {'repository': REPOSITORY, 'origin': ORIGIN,
                       'deployment_commit': published, 'managed_paths': sorted(report['files'])})
    print(json.dumps({'published_commit': published, 'changed_files': len(changed), 'url': ORIGIN + '/'}, ensure_ascii=False), flush=True)
    return published


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['build', 'publish', 'deploy'])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--deployment-repo', type=Path, required=True)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--reviewed-head')
    args = parser.parse_args()
    output, repo = args.output.resolve(), args.deployment_repo.resolve()
    if output == repo or output.is_relative_to(repo) or repo.is_relative_to(output) or output.is_relative_to(DEVELOPMENT):
        parser.error('Staging must be separate from the deployment checkout and source tree.')
    try:
        if args.action in {'build', 'deploy'}:
            build(output, repo, args.python)
        if args.action in {'publish', 'deploy'}:
            publish(output, repo, args.reviewed_head)
    except (AssertionError, RuntimeError, ValueError) as error:
        raise SystemExit(str(error)) from error


if __name__ == '__main__':
    main()
