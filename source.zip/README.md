# 신약의 구약 사용

신약 27권 260장의 구약 인용·암시를 선정해 대조하는 무료 정적 사이트입니다. 신약 개역한글과 SBLGNT, 새 칠십인역 한국어 번역과 Swete 헬라어, 구약 개역한글을 장 전체의 문맥 안에서 읽습니다. 구약 개역한글 열은 켜거나 끌 수 있습니다.

## 범위와 출처

목록 기준은 NA28 부록 III입니다. 선정 항목의 성구와 쪽수는 원본 스캔 및 OCR로 확인하고 각 항목에 보존합니다. 부록 전체의 전사본은 아니며 인용·암시 분류는 본문 비교에 따른 편집 판단입니다. 사도행전 57개 항목은 이전 NA27 온라인 전사본 출처를 유지하고, 요나 1:5 / 사도행전 27:19는 NA28 원본을 육안 확인했습니다. UBS6 개별 항목 검증은 진행하지 않았습니다.

칠십인역 번역은 Swete 전자본문에서 옮긴 AI 보조 연구용 초안이며 독립적인 전문가 교열 전입니다. 실제 본문이 없는 번호는 원문·번역 상태에 표시합니다. 이문이나 전사 오류가 의심되는 읽기는 원문을 보존하고 구체적인 주석을 붙입니다. 다니엘은 Old Greek이며 Theodotion과 구별합니다.

신약의 모든 장은 개역한글 공식 전자본문과 SBLGNT에서 수록합니다. 이번에 추가한 20권의 헬라어 어휘는 발행처 전자본문 전체와 대조했습니다. MorphGNT에서 빠진 요한복음 7:53–8:11은 발행처 SBLGNT의 이중 대괄호 본문에서 가져왔습니다. 원자료 URL과 해시는 `data/provenance.json`에 있습니다.

## 읽기와 데이터

- `/`: 접히는 책 선택 메뉴와 장별 인용·암시 목록입니다. 선택한 책·장은 URL에 남습니다. 선정 항목이 없는 장은 목록에서 생략하며, 선정 대조가 없는 빌레몬서와 요한삼서는 장 본문으로 연결합니다.
- `/catalog/`: 선정 대조 전체 목록입니다.
- `/책슬러그-N/`: 신약 장 전체의 정적 HTML입니다. 책 슬러그는 `data/nt_books.py`에 있습니다.
- `/data/reader.json`: 책별 JSON의 목록입니다. 각 책은 `/data/books/책슬러그.json`에 있습니다.
- `/data/reader.zip`: 전체 JSON과 Markdown 압축 파일입니다. `/data/reader.md`에서는 전체 텍스트를 바로 읽을 수 있습니다.
- `/data/책슬러그-N.md`, `/data/대조ID.md`: 장별·항목별 Markdown입니다.
- `/llms.txt`: 기계 판독용 연결·판본 안내입니다.

자료 수량은 배포된 JSON의 `scope`에 있습니다. 홈과 책명에는 개수나 검증 상태를 표시하지 않습니다. 각 본문은 JavaScript 없이도 읽을 수 있으며 회원가입·유료 API·유료 데이터베이스가 필요하지 않습니다.

JSON 진입점은 schema 3.1의 `book_manifest`이며 `books`의 URL로 각 책에 접근합니다. 각 책과 ZIP 안의 전체 JSON은 schema 3.0입니다. 책별 파일의 `scope`는 해당 책, `site_scope`는 사이트 전체의 수량입니다.

JSON schema 3.0에서 신약은 `book`과 `chapter`를 함께 키로 사용합니다. `lxx_chapter_id`와 `ot_chapter_id`는 반복 수록된 장을 식별합니다. `lxx_ot_verse_map`은 여러 절 사이의 대응을 지원하며 단순한 일괄 오프셋을 전제하지 않습니다.

`source_ranges`, `verse_map_note`, `ko_status`, `grc_status`, `boundary_notes`, `lxx_text_form`에 판본과 번호의 예외를 기록합니다. 요한계시록 12:18은 SBLGNT의 절이며 한국어 내용은 개역한글 12:17 끝에 있습니다. 따라서 별도 위치에 헬라어를 수록하고 한국어 상태를 `content_in_17`로 표시합니다. 시편 표제, 구약 장의 합침과 경계 차이도 대응표에 보존합니다.

## 코드와 재현

Python 3.12+ 표준 라이브러리만 사용합니다.

```sh
python scripts/build.py
python scripts/source_archive.py
python scripts/validate.py
python scripts/validate_reader.py
```

`dist/`를 정적 파일로 제공합니다. `data/editorial.py`와 `data/canonical_expansion.py`가 책별 번역·대조·구문 대응을 합칩니다. `data/nt_books.py`가 신약 27권의 순서, 출처 코드, 원자료 절 수와 출판 위치 수를 정의합니다. 마지막 확장의 데이터는 `john_*`, `paul_remaining_*`, `pastorals_*`, `catholic_*`, `revelation_*`, `completion_*`에 있습니다.

`scripts/expand_remaining_nt.py`는 추가 20권의 신약을, `scripts/expand_completion_sources.py`는 새 칠십인역·한글 구약 장을 수집합니다. 앞선 확장의 추출 스크립트도 `scripts/`에 보존합니다. 재수집에는 출처 URL에서 받은 Swete 원자료가 필요합니다. 원본 HTML과 헬라어 자료는 `.source`로 캐시하며 공개 소스 압축에는 포함하지 않습니다.

홈은 선택한 장의 작은 JSON만 불러옵니다. `navigation.js`는 사이트 내부 이동에서 본문 영역을 교체하고 최근 16개 페이지를 보관합니다. 가까운 두 항목을 차례로 미리 불러오며 데이터 절약 모드에서는 자동 미리 읽기를 끕니다. 자료 버전이 바뀌거나 요청이 실패하면 일반 페이지 이동으로 전환합니다.

`phrase_diff.py`는 선정된 헬라어 구문의 단어 순서를 비교합니다. 같은 순서로 이어지는 말은 파란 실선, 달라지거나 옮겨진 말은 황갈색 점선입니다. 대소문자·악센트·기식·문장부호의 차이는 색상에서 제외하며 원문 문자열은 보존합니다. 의미상의 동일성이나 직접 인용 여부를 자동 판정하지 않습니다.

## 이용 조건

본문은 개역한글을 사용하며 개역개정은 대한성서공회 공식 사이트의 해당 장으로 연결합니다. Swete 전자자료와 새 코드·한국어 번역·연결 자료는 GPL-3.0, SBLGNT는 CC BY 4.0입니다. SBLGNT는 Michael W. Holmes 편, © 2010 Society of Biblical Literature and Logos Bible Software입니다. 구성 요소별 출처와 대한성서공회의 이용 안내는 `/about/`에 있습니다.

상세 페이지는 선정 구절을 신약과 칠십인역으로 나란히 보여 줍니다. `reader_layout.py`가 본문과 해설을 정적 HTML로 만들고, `reader.js`와 `reader.css`가 표시 설정과 펼침 동작을 담당합니다. 밑줄을 선택하면 관련 해설이 본문 아래에서 열립니다. 헬라어·구약 개역한글·글자 크기 설정을 저장하며, 본문 복사와 해설 링크 공유를 지원합니다. 장 전체는 별도 영역에서 본문별로 선택하거나 나란히 읽을 수 있습니다. 한국어의 선택 표현을 강조하고, 헬라어는 절 전체의 단어 배열을 비교합니다. 동일한 절에 걸친 대응 표현은 하나의 구절 묶음으로 합칩니다. `verse_notes.py`의 어구별 주석과 `comparison_readings.py`의 본문별 상세 해설을 읽을 수 있습니다. 상세 해설은 실제 달라지는 말의 뜻, 문장 구조, 구약의 문맥과 신약에서 인용이 하는 역할을 설명합니다. 히브리어 본문을 참조한 항목에는 확인한 출처를 기록합니다.

JSON `verse_comparisons`의 `focus_rows`는 핵심 어구 표, `summary`는 주요 차이, `notes`는 해설입니다. `focus_text_kind`가 `quotation`이면 표의 한국어는 해당 성경 번역의 인용이고, `gloss`이면 헬라어 어구의 뜻풀이입니다. 둘 다 `grc`는 본문에 실제로 있는 어구입니다. `sources`는 추가 참조 본문입니다. 새 해설의 `nt_verses`는 대조창에 표시할 신약 절 범위를 제한하며, HTML 하단 주석과 Markdown·책별 JSON에도 본문별 해설이 포함됩니다. 어구를 단순히 나열하는 자동 문장은 분석으로 생성하지 않습니다.

## 정식 사이트와 GitHub Pages 배포

정식 주소는 https://ntot.missionalbible.org/ 이며, 공개 저장소는 `imtseoul/missionalbible-ntot`입니다. 모든 공개 링크는 도메인 루트를 기준으로 생성합니다.

`pages.py`는 개발 원본의 복사본을 임시 폴더에서 빌드하고 검증한 뒤 별도 공개 출력 폴더를 만듭니다. CNAME, HTTPS용 도메인, 대표 주소, robots.txt, sitemap.xml, 미셔널 바이블 링크를 유지합니다. 원격 변경과 배포 저장소의 미커밋 변경을 확인하며, 인증 정보와 작업 폴더는 공개 파일에 포함하지 않습니다.

```sh
python3 scripts/pages.py build --deployment-repo /path/to/missionalbible-ntot --output /path/to/new-publication
python3 scripts/pages.py publish --deployment-repo /path/to/missionalbible-ntot --output /path/to/new-publication
```

검토와 배포를 한 번에 실행할 때는 `build` 대신 `deploy`를 사용합니다. `build`와 `deploy`의 출력 폴더는 새 경로여야 합니다. 변경 목록은 출력 폴더 옆의 `.plan.json`에 저장합니다. 기존 공개 파일에 원격 변경이 있으면 해당 변경을 원본에 반영한 뒤 새로 빌드합니다. 검토한 원격 수정본만 `--reviewed-head`로 명시할 수 있습니다. 강제 푸시는 사용하지 않습니다.
